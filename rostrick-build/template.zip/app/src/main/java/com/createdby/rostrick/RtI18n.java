package com.createdby.rostrick;

import java.util.Locale;

/** لغة واجهة التطبيق: عربي إن كانت لغة الجهاز عربية، وإلا إنجليزي. */
public final class RtI18n {
	private RtI18n() {}

	/** true عندما لا تكون لغة الجهاز عربية (تُعرض الإنجليزية). */
	public static boolean en() {
		return !"ar".equalsIgnoreCase(Locale.getDefault().getLanguage());
	}

	/** يرجع النص العربي أو الإنجليزي حسب لغة الجهاز. */
	public static String t(String ar, String en) {
		return en() ? en : ar;
	}
}
