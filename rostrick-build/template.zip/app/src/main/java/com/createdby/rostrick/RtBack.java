package com.createdby.rostrick;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebView;

/**
 * RosTrick: جسر زر الرجوع — window.RosTrickBack (يعمل دائماً، بلا أذونات).
 *  - canGoBack()/goBack(): نفس منطق الرجوع الأصلي للتطبيق (سجل الصفحات الذكي) بلا خروج تلقائي.
 *  - اعتراض زر الرجوع: حين تسجّل الصفحة معالجًا (RosTrickBack.onBack) يُسلَّم لها الضغط أولاً؛ إن لم تعالجه
 *    (أو لم ترد خلال 400ms) يُنفَّذ السلوك الافتراضي. لا يعرض هذا الجسر أي Toast إطلاقاً — الصفحة تعرض ما تريد.
 *  - exit()/minimize(): إغلاق التطبيق أو إرساله للخلفية. exitMode: ما يحدث عند الرجوع بلا صفحة سابقة.
 */
public final class RtBack {
	public interface Host {
		boolean canGoBack();
		/** يرجع خطوة؛ true إن تنقّل فعلاً. exitIfNone=false: لا يخرج ولا يفعل شيئًا إن لم توجد صفحة سابقة. */
		boolean goBack(boolean exitIfNone);
	}

	private static final long ACK_MS = 400;
	private final Activity act;
	private final WebView web;
	private final Host host;
	private final Handler ui = new Handler(Looper.getMainLooper());
	private volatile boolean intercept = false;
	private String exitMode = "exit"; // exit | minimize | none
	private int seq = 0;
	private int pending = 0;

	public RtBack(Activity a, WebView w, Host h) { act = a; web = w; host = h; }

	/** يُستدعى من onBackPressed: true = سلّمنا الضغط للصفحة (لا تكمل). */
	public boolean dispatch() {
		if (!intercept) return false;
		final int id = ++seq;
		pending = id;
		try {
			web.evaluateJavascript("(function(){try{if(window.__rtBackPress){window.__rtBackPress(" + id + ");return 1}}catch(e){}return 0})()", new ValueCallback<String>() {
				@Override public void onReceiveValue(String v) { if (!"1".equals(v)) fallback(id); }
			});
		} catch (Throwable t) { pending = 0; return false; }
		ui.postDelayed(new Runnable() { @Override public void run() { fallback(id); } }, ACK_MS);
		return true;
	}

	private void fallback(int id) {
		if (pending != id) return;
		pending = 0;
		host.goBack(true);
	}

	/** السلوك عند الرجوع بلا صفحة سابقة (تستدعيه MainActivity بدل finish()). */
	public void leave() {
		if ("none".equals(exitMode)) return;
		if ("minimize".equals(exitMode)) { try { act.moveTaskToBack(true); return; } catch (Throwable ignore) {} }
		act.finish();
	}

	@JavascriptInterface public boolean canGoBack() { try { return host.canGoBack(); } catch (Throwable t) { return false; } }

	@JavascriptInterface public void setIntercept(boolean on) { intercept = on; if (!on) pending = 0; }

	/** تردّ بها الصفحة على __rtBackPress: handled=true يعني أنها عالجت الضغط. */
	@JavascriptInterface public void result(final int id, final boolean handled) {
		ui.post(new Runnable() { @Override public void run() {
			if (pending != id) return;
			pending = 0;
			if (!handled) host.goBack(true);
		} });
	}

	/** رجوع خطوة بالمنطق الأصلي؛ يرجع false (بلا خروج) إن لم توجد صفحة سابقة. */
	@JavascriptInterface public void goBackAsync(final boolean exitIfNone) {
		ui.post(new Runnable() { @Override public void run() { host.goBack(exitIfNone); } });
	}

	/** يحاكي ضغط زر الرجوع كاملاً (يمرّ على معالجات الصفحة أيضاً). */
	@JavascriptInterface public void press() {
		ui.post(new Runnable() { @Override public void run() { try { act.onBackPressed(); } catch (Throwable ignore) {} } });
	}

	@JavascriptInterface public void exit() { ui.post(new Runnable() { @Override public void run() { try { act.finish(); } catch (Throwable ignore) {} } }); }

	@JavascriptInterface public boolean minimize() {
		ui.post(new Runnable() { @Override public void run() { try { act.moveTaskToBack(true); } catch (Throwable ignore) {} } });
		return true;
	}

	@JavascriptInterface public void setExitMode(String m) {
		String k = m == null ? "exit" : m.toLowerCase(java.util.Locale.ROOT);
		exitMode = (k.equals("minimize") || k.equals("none")) ? k : "exit";
	}
	@JavascriptInterface public String getExitMode() { return exitMode; }
}
