package com.createdby.rostrick;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONObject;

import java.util.Locale;

/**
 * RosTrick: أدوات الإحساس الأصلي — window.RosTrickApp (يعمل دائماً، بلا أذونات).
 *  - دورة حياة التطبيق (pause/resume)، حالة الكيبورد وارتفاعه + إظهاره/إخفاؤه.
 *  - تعطيل قائمة الضغط المطوّل (النظام)، معلومات التطبيق، فتح إعدادات التطبيق/رابط خارجي.
 *  - الحافظة وإبقاء الشاشة مضاءة موجودتان أصلاً بأسمائهما القياسية (navigator.clipboard / navigator.wakeLock) عبر RtWebApi.
 * لا يعرض هذا الجسر أي Toast ولا نافذة؛ كل ما يُعرض للمستخدم تصنعه الصفحة.
 * الأحداث تصل للصفحة عبر window.__rtApp(type, json).
 */
public final class RtApp {
	private final Activity act;
	private final WebView web;
	private final Handler ui = new Handler(Looper.getMainLooper());
	private final float density;
	private boolean fg = true;
	private int kbPx = 0;
	private boolean noContextMenu = false;

	public RtApp(Activity a, WebView w) {
		act = a; web = w;
		density = Math.max(0.5f, a.getResources().getDisplayMetrics().density);
	}

	private void emit(final String type, final JSONObject data) {
		final String json = data == null ? "{}" : data.toString();
		act.runOnUiThread(new Runnable() {
			@Override public void run() {
				try { web.evaluateJavascript("window.__rtApp&&window.__rtApp(" + JSONObject.quote(type) + "," + JSONObject.quote(json) + ")", null); } catch (Throwable ignore) {}
			}
		});
	}

	// ---------- دورة الحياة (تُستدعى من MainActivity) ----------
	public void onPause() { fg = false; emit("pause", null); }
	public void onResume() { fg = true; emit("resume", null); }
	public void onDestroy() { try { web.setOnLongClickListener(null); } catch (Throwable ignore) {} }

	/** من مستمع هوامش الحاوية: imeBottomPx = ارتفاع الكيبورد بالبكسل (0 إن كان مغلقاً). */
	public void onInsets(int imeBottomPx) {
		int px = Math.max(0, imeBottomPx);
		if (px == kbPx) return;
		kbPx = px;
		try {
			JSONObject o = new JSONObject();
			o.put("open", px > 0); o.put("height", Math.round(px / density));
			emit("keyboard", o);
		} catch (Throwable ignore) {}
	}

	// ---------- الكيبورد ----------
	@JavascriptInterface public String keyboardState() {
		try { JSONObject o = new JSONObject(); o.put("open", kbPx > 0); o.put("height", Math.round(kbPx / density)); return o.toString(); } catch (Throwable t) { return "{\"open\":false,\"height\":0}"; }
	}
	@JavascriptInterface public boolean keyboardShow() {
		ui.post(new Runnable() { @Override public void run() {
			try { web.requestFocus(); InputMethodManager im = (InputMethodManager) act.getSystemService(Context.INPUT_METHOD_SERVICE); if (im != null) im.showSoftInput(web, InputMethodManager.SHOW_IMPLICIT); } catch (Throwable ignore) {}
		} });
		return true;
	}
	@JavascriptInterface public boolean keyboardHide() {
		ui.post(new Runnable() { @Override public void run() {
			try { InputMethodManager im = (InputMethodManager) act.getSystemService(Context.INPUT_METHOD_SERVICE); if (im != null) im.hideSoftInputFromWindow(web.getWindowToken(), 0); } catch (Throwable ignore) {}
		} });
		return true;
	}

	// ---------- النافذة ----------
	/** true = يمنع قائمة الضغط المطوّل الأصلية (حفظ الصورة/نسخ الرابط/تحديد النص بالضغط المطوّل). يؤثر على كل الصفحة بما فيها حقول الإدخال. */
	@JavascriptInterface public boolean contextMenu(final boolean allow) {
		noContextMenu = !allow;
		act.runOnUiThread(new Runnable() { @Override public void run() {
			try {
				if (allow) { web.setOnLongClickListener(null); web.setHapticFeedbackEnabled(true); }
				else { web.setOnLongClickListener(new View.OnLongClickListener() { @Override public boolean onLongClick(View v) { return true; } }); web.setHapticFeedbackEnabled(false); }
			} catch (Throwable ignore) {}
		} });
		return true;
	}
	@JavascriptInterface public boolean contextMenuGet() { return !noContextMenu; }

	// ---------- معلومات وإجراءات ----------
	@JavascriptInterface public String info() {
		JSONObject o = new JSONObject();
		try {
			PackageInfo pi = act.getPackageManager().getPackageInfo(act.getPackageName(), 0);
			o.put("package", act.getPackageName());
			o.put("versionName", pi.versionName == null ? "" : pi.versionName);
			long vc = Build.VERSION.SDK_INT >= 28 ? pi.getLongVersionCode() : pi.versionCode;
			o.put("versionCode", vc);
			o.put("installTime", pi.firstInstallTime); o.put("updateTime", pi.lastUpdateTime);
		} catch (Throwable ignore) {}
		try {
			o.put("foreground", fg);
			o.put("sdk", Build.VERSION.SDK_INT);
			o.put("locale", Locale.getDefault().toLanguageTag());
			o.put("rtl", act.getResources().getConfiguration().getLayoutDirection() == View.LAYOUT_DIRECTION_RTL);
			int ui = act.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
			o.put("darkMode", ui == Configuration.UI_MODE_NIGHT_YES);
			o.put("density", density);
			o.put("tablet", act.getResources().getConfiguration().smallestScreenWidthDp >= 600);
		} catch (Throwable ignore) {}
		return o.toString();
	}

	@JavascriptInterface public boolean openSettings() {
		try {
			Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + act.getPackageName()));
			i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); act.startActivity(i); return true;
		} catch (Throwable t) { return false; }
	}

	/** يفتح رابطًا بتطبيق خارجي (http/https/mailto/tel/sms/geo فقط). */
	@JavascriptInterface public boolean openExternal(String url) {
		try {
			if (url == null) return false;
			String u = url.trim(); String l = u.toLowerCase(Locale.ROOT);
			if (!(l.startsWith("http://") || l.startsWith("https://") || l.startsWith("mailto:") || l.startsWith("tel:") || l.startsWith("sms:") || l.startsWith("geo:"))) return false;
			Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(u)); i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); act.startActivity(i); return true;
		} catch (Throwable t) { return false; }
	}
}
