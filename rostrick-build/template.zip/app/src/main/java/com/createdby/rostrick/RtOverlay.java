package com.createdby.rostrick;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * RosTrick: نوافذ عائمة فوق كل التطبيقات — window.RosTrickOverlay.
 *  - كل نافذة = WebView شفاف يعرض صفحة HTML (رابط أو نص HTML) داخل WindowManager (TYPE_APPLICATION_OVERLAY).
 *  - تحتاج إذن "العرض فوق التطبيقات" (SYSTEM_ALERT_WINDOW)؛ يضيفه البناء فقط إن اختار صاحب التطبيق الإذن overlay.
 *  - الرسائل بين الصفحة الرئيسية والنافذة عبر post/onMessage؛ الأحداث تصل الرئيسية عبر window.__rtOverlay(type, json).
 *  - لا يعرض هذا الجسر أي Toast ولا حوار؛ كل ما يراه المستخدم من صنع صفحتك.
 */
public final class RtOverlay {
	static final int MAX_OVERLAYS = 6;

	/** النسخة الحالية (تستعملها RtScreen لإخفاء النوافذ لحظة الالتقاط كي لا تظهر في اللقطة). */
	static volatile RtOverlay sInstance;

	private final Activity act;
	private final Context app;
	private final WebView main;
	private final WindowManager wm;
	private final Handler ui = new Handler(Looper.getMainLooper());
	private final float density;
	private final Map<String, Ov> map = new LinkedHashMap<String, Ov>();
	private int seq = 0;
	private boolean permPending = false;
	private boolean tempHidden = false;

	private static final class Ov {
		String id;
		FrameLayout root;
		WebView web;
		WindowManager.LayoutParams lp;
		boolean keep, shown = true, full;
	}

	public RtOverlay(Activity a, WebView mainWeb) {
		act = a; app = a.getApplicationContext(); main = mainWeb;
		wm = (WindowManager) app.getSystemService(Context.WINDOW_SERVICE);
		density = Math.max(0.5f, a.getResources().getDisplayMetrics().density);
		sInstance = this;
	}

	// ---------- الأذونات ----------
	static boolean declared(Context c) {
		try {
			PackageInfo pi = c.getPackageManager().getPackageInfo(c.getPackageName(), android.content.pm.PackageManager.GET_PERMISSIONS);
			if (pi.requestedPermissions != null) for (String p : pi.requestedPermissions) if ("android.permission.SYSTEM_ALERT_WINDOW".equals(p)) return true;
		} catch (Throwable ignore) {}
		return false;
	}

	boolean canDrawNow() {
		if (Build.VERSION.SDK_INT < 23) return true;
		try { return Settings.canDrawOverlays(app); } catch (Throwable t) { return false; }
	}

	// ---------- مساعدات ----------
	private void emit(final String type, final JSONObject data) {
		final String json = data == null ? "{}" : data.toString();
		act.runOnUiThread(new Runnable() {
			@Override public void run() {
				try { main.evaluateJavascript("window.__rtOverlay&&window.__rtOverlay(" + JSONObject.quote(type) + "," + JSONObject.quote(json) + ")", null); } catch (Throwable ignore) {}
			}
		});
	}

	private static JSONObject obj(String s) {
		try { return s == null || s.length() == 0 ? new JSONObject() : new JSONObject(s); } catch (Throwable t) { return new JSONObject(); }
	}

	private int dp(double v) { return (int) Math.round(v * density); }

	private int[] realSize() {
		DisplayMetrics dm = new DisplayMetrics();
		try { wm.getDefaultDisplay().getRealMetrics(dm); } catch (Throwable t) { dm = act.getResources().getDisplayMetrics(); }
		return new int[] { dm.widthPixels, dm.heightPixels };
	}

	/** تشغيل على خيط الواجهة وانتظار النتيجة (تُستدعى دوال الجسر من خيط JS). */
	private String onUi(final java.util.concurrent.Callable<String> c) {
		if (Looper.myLooper() == Looper.getMainLooper()) {
			try { return c.call(); } catch (Throwable t) { return err(String.valueOf(t.getMessage())); }
		}
		final String[] res = new String[1];
		final CountDownLatch l = new CountDownLatch(1);
		ui.post(new Runnable() {
			@Override public void run() {
				try { res[0] = c.call(); } catch (Throwable t) { res[0] = err(String.valueOf(t.getMessage())); }
				l.countDown();
			}
		});
		try { l.await(4, TimeUnit.SECONDS); } catch (InterruptedException ignore) {}
		return res[0] == null ? err("timeout") : res[0];
	}

	private static String err(String e) {
		try { return new JSONObject().put("ok", false).put("error", e).toString(); } catch (Throwable t) { return "{\"ok\":false}"; }
	}

	private static String ok(JSONObject extra) {
		try { JSONObject o = extra == null ? new JSONObject() : extra; o.put("ok", true); return o.toString(); } catch (Throwable t) { return "{\"ok\":true}"; }
	}

	// ---------- الإنشاء ----------
	private static int gravityOf(String g) {
		if (g == null) return Gravity.TOP | Gravity.LEFT;
		switch (g) {
			case "tr": return Gravity.TOP | Gravity.RIGHT;
			case "bl": return Gravity.BOTTOM | Gravity.LEFT;
			case "br": return Gravity.BOTTOM | Gravity.RIGHT;
			case "center": return Gravity.CENTER;
			default: return Gravity.TOP | Gravity.LEFT;
		}
	}

	private int flagsFor(boolean touchable, boolean focusable) {
		int f = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED;
		if (!focusable) f |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
		if (!touchable) f |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
		return f;
	}

	private String create(JSONObject o) throws Exception {
		if (!declared(app)) return err("not_declared");
		if (!canDrawNow()) return err("no_permission");
		String id = o.optString("id", "");
		if (id.length() == 0) id = "ov" + (++seq);
		if (!id.matches("[A-Za-z0-9_.-]{1,40}")) return err("bad_id");
		if (map.containsKey(id)) return err("exists");
		if (map.size() >= MAX_OVERLAYS) return err("too_many");
		String url = o.optString("url", "");
		String html = o.optString("html", "");
		if (url.length() == 0 && html.length() == 0) return err("no_content");
		if (url.length() > 0) {
			String low = url.toLowerCase(java.util.Locale.ROOT);
			if (!(low.startsWith("http://") || low.startsWith("https://") || low.startsWith("file://"))) return err("bad_url");
		}
		final Ov ov = new Ov();
		ov.id = id;
		ov.keep = o.optBoolean("keep", false);
		ov.full = o.optBoolean("fullscreen", false);
		boolean touchable = o.optBoolean("touchable", true);
		boolean focusable = o.optBoolean("focusable", false);

		WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
		lp.type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
		lp.format = PixelFormat.TRANSLUCENT;
		lp.flags = flagsFor(touchable, focusable);
		lp.gravity = gravityOf(o.optString("gravity", "tl"));
		if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
		if (focusable) lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN;
		if (ov.full) {
			int[] s = realSize();
			lp.width = s[0]; lp.height = s[1]; lp.gravity = Gravity.TOP | Gravity.LEFT; lp.x = 0; lp.y = 0;
		} else {
			lp.width = sizeOf(o, "w", 200);
			lp.height = sizeOf(o, "h", 120);
			lp.x = dp(o.optDouble("x", 0));
			lp.y = dp(o.optDouble("y", 0));
		}
		float a = (float) o.optDouble("alpha", 1.0);
		if (a >= 0f && a < 1f) lp.alpha = a;
		ov.lp = lp;

		FrameLayout root = new FrameLayout(app);
		WebView web = new WebView(app);
		ov.web = web; ov.root = root;
		String bg = o.optString("bg", "");
		int bgc = Color.TRANSPARENT;
		if (bg.length() > 0) { try { bgc = Color.parseColor(bg); } catch (Throwable ignore) {} }
		web.setBackgroundColor(bgc);
		WebSettings ws = web.getSettings();
		ws.setJavaScriptEnabled(true);
		ws.setDomStorageEnabled(true);
		ws.setAllowFileAccess(true);
		ws.setAllowContentAccess(false);
		ws.setMediaPlaybackRequiresUserGesture(false);
		ws.setSupportZoom(false);
		ws.setBuiltInZoomControls(false);
		if (Build.VERSION.SDK_INT >= 21) ws.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
		web.setOverScrollMode(View.OVER_SCROLL_NEVER);
		web.setVerticalScrollBarEnabled(false);
		web.setHorizontalScrollBarEnabled(false);
		final String fid = id;
		web.addJavascriptInterface(new Host(fid), "RosTrickOverlayHost");
		web.setWebViewClient(new WebViewClient() {
			@Override public void onPageStarted(WebView v, String u, android.graphics.Bitmap f) { inject(v); }
			@Override public void onPageFinished(WebView v, String u) {
				inject(v);
				try { emit("ready", new JSONObject().put("id", fid).put("url", u)); } catch (Throwable ignore) {}
			}
			@Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
				String s = r.getUrl().toString().toLowerCase(java.util.Locale.ROOT);
				return !(s.startsWith("http://") || s.startsWith("https://") || s.startsWith("file://") || s.startsWith("about:") || s.startsWith("data:"));
			}
		});
		root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
		wm.addView(root, lp);
		map.put(id, ov);
		if (tempHidden) root.setVisibility(View.INVISIBLE);
		if (html.length() > 0 && url.length() == 0) {
			String base = o.optString("baseUrl", "");
			web.loadDataWithBaseURL(base.length() > 0 ? base : "https://rostrick.overlay/", html, "text/html", "utf-8", null);
		} else {
			web.loadUrl(url);
		}
		return ok(new JSONObject().put("id", id));
	}

	/** w/h بوحدة dp؛ "full" أو -1 = ملء الشاشة. */
	private int sizeOf(JSONObject o, String k, double def) {
		Object v = o.opt(k);
		if (v == null) return dp(def);
		if (v instanceof String) {
			String s = (String) v;
			if (s.equals("full") || s.equals("match")) return ViewGroup.LayoutParams.MATCH_PARENT;
			try { return dp(Double.parseDouble(s)); } catch (Throwable t) { return dp(def); }
		}
		double d = o.optDouble(k, def);
		if (d < 0) return ViewGroup.LayoutParams.MATCH_PARENT;
		return Math.max(1, dp(d));
	}

	private static final String OV_JS =
		"(function(){try{var H=window.RosTrickOverlayHost;if(!H)return;if(window.RosTrickOverlay&&window.RosTrickOverlay.__v)return;"
		+ "var hs=[],I={};try{I=JSON.parse(H.info())}catch(e){}"
		+ "window.__rtOvMsg=function(s){var d;try{d=JSON.parse(s)}catch(e){d=s}hs.slice().forEach(function(f){try{f(d)}catch(e){setTimeout(function(){throw e})}})};"
		+ "function pt(e){var t=(e.touches&&e.touches[0])||(e.changedTouches&&e.changedTouches[0])||e;return{x:t.screenX,y:t.screenY}}"
		+ "window.RosTrickOverlay={__v:1,id:I.id,"
		+ "post:function(m){H.post(JSON.stringify(m===undefined?null:m))},"
		+ "onMessage:function(f){if(typeof f!=='function')return function(){};hs.push(f);return function(){hs=hs.filter(function(x){return x!==f})}},"
		+ "close:function(){H.close()},moveBy:function(dx,dy){H.moveBy(+dx||0,+dy||0)},move:function(x,y){H.setPos(+x||0,+y||0)},resize:function(w,h){H.setSize(+w||0,+h||0)},"
		+ "snap:function(){H.snap()},touchable:function(b){H.setTouchable(!!b)},info:function(){try{return JSON.parse(H.info())}catch(e){return {}}},"
		+ "drag:function(el,o){o=o||{};var s=null,moved=false;"
		+ "function down(e){var p=pt(e);s={x:p.x,y:p.y};moved=false}"
		+ "function move(e){if(!s)return;var p=pt(e),dx=p.x-s.x,dy=p.y-s.y;if(!moved&&Math.abs(dx)+Math.abs(dy)<6)return;moved=true;s={x:p.x,y:p.y};H.moveBy(dx,dy);if(e.cancelable)e.preventDefault()}"
		+ "function up(e){if(!s)return;var was=moved;s=null;if(was){if(o.snap)H.snap();if(o.onDrop)try{o.onDrop()}catch(x){}}else if(o.onTap)try{o.onTap(e)}catch(x){}}"
		+ "el.addEventListener('touchstart',down,{passive:true});el.addEventListener('touchmove',move,{passive:false});el.addEventListener('touchend',up);el.addEventListener('touchcancel',function(){s=null});"
		+ "el.addEventListener('mousedown',function(e){down(e);var mm=function(ev){move(ev)},mu=function(ev){document.removeEventListener('mousemove',mm);document.removeEventListener('mouseup',mu);up(ev)};document.addEventListener('mousemove',mm);document.addEventListener('mouseup',mu)});"
		+ "}};"
		+ "try{window.dispatchEvent(new CustomEvent('rtoverlay-ready'))}catch(e){}"
		+ "}catch(e){}})();";

	private void inject(WebView v) {
		try { v.evaluateJavascript(OV_JS, null); } catch (Throwable ignore) {}
	}

	// ---------- واجهة تستدعيها صفحة النافذة نفسها ----------
	public final class Host {
		private final String id;
		Host(String id) { this.id = id; }
		@JavascriptInterface public void post(String json) {
			try { emit("message", new JSONObject().put("id", id).put("json", json == null ? "null" : json)); } catch (Throwable ignore) {}
		}
		@JavascriptInterface public void close() { destroyAsync(id, true); }
		@JavascriptInterface public void moveBy(final double dx, final double dy) {
			ui.post(new Runnable() { @Override public void run() { Ov ov = map.get(id); if (ov == null) return; shift(ov, (int) Math.round(dx * density), (int) Math.round(dy * density)); } });
		}
		@JavascriptInterface public void setPos(final double x, final double y) {
			ui.post(new Runnable() { @Override public void run() { Ov ov = map.get(id); if (ov == null) return; ov.lp.x = dp(x); ov.lp.y = dp(y); upd(ov); } });
		}
		@JavascriptInterface public void setSize(final double w, final double h) {
			ui.post(new Runnable() { @Override public void run() { Ov ov = map.get(id); if (ov == null) return; if (w > 0) ov.lp.width = dp(w); if (h > 0) ov.lp.height = dp(h); upd(ov); } });
		}
		@JavascriptInterface public void setTouchable(final boolean t) {
			ui.post(new Runnable() { @Override public void run() { Ov ov = map.get(id); if (ov == null) return; setFlag(ov, WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, !t); } });
		}
		@JavascriptInterface public void snap() {
			ui.post(new Runnable() { @Override public void run() { Ov ov = map.get(id); if (ov != null) snapToEdge(ov); } });
		}
		@JavascriptInterface public String info() {
			try { Ov ov = map.get(id); return describe(ov == null ? stub(id) : ov).toString(); } catch (Throwable t) { return "{}"; }
		}
	}

	private Ov stub(String id) { Ov o = new Ov(); o.id = id; return o; }

	private void shift(Ov ov, int dx, int dy) {
		int[] s = realSize();
		boolean right = (ov.lp.gravity & Gravity.RIGHT) == Gravity.RIGHT, bottom = (ov.lp.gravity & Gravity.BOTTOM) == Gravity.BOTTOM;
		ov.lp.x += right ? -dx : dx;
		ov.lp.y += bottom ? -dy : dy;
		int w = ov.lp.width > 0 ? ov.lp.width : s[0], h = ov.lp.height > 0 ? ov.lp.height : s[1];
		ov.lp.x = Math.max(-(w - dp(24)), Math.min(s[0] - dp(24), ov.lp.x));
		ov.lp.y = Math.max(0, Math.min(s[1] - dp(24), ov.lp.y));
		upd(ov);
	}

	private void snapToEdge(Ov ov) {
		int[] s = realSize();
		int w = ov.lp.width > 0 ? ov.lp.width : s[0];
		boolean right = (ov.lp.gravity & Gravity.RIGHT) == Gravity.RIGHT;
		int cx = right ? s[0] - ov.lp.x - w / 2 : ov.lp.x + w / 2;
		boolean toLeft = cx < s[0] / 2;
		ov.lp.x = 0;
		ov.lp.gravity = (ov.lp.gravity & Gravity.VERTICAL_GRAVITY_MASK) | (toLeft ? Gravity.LEFT : Gravity.RIGHT);
		upd(ov);
	}

	private void setFlag(Ov ov, int flag, boolean on) {
		if (on) ov.lp.flags |= flag; else ov.lp.flags &= ~flag;
		upd(ov);
	}

	private void upd(Ov ov) {
		try { if (ov.root != null && ov.root.isAttachedToWindow()) wm.updateViewLayout(ov.root, ov.lp); } catch (Throwable ignore) {}
	}

	private JSONObject describe(Ov ov) throws Exception {
		int[] s = realSize();
		JSONObject o = new JSONObject();
		o.put("id", ov.id);
		o.put("density", density);
		o.put("screenW", s[0]); o.put("screenH", s[1]);
		if (ov.lp != null) {
			o.put("x", Math.round(ov.lp.x / density)); o.put("y", Math.round(ov.lp.y / density));
			o.put("w", ov.lp.width > 0 ? Math.round(ov.lp.width / density) : -1);
			o.put("h", ov.lp.height > 0 ? Math.round(ov.lp.height / density) : -1);
			o.put("touchable", (ov.lp.flags & WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE) == 0);
			o.put("focusable", (ov.lp.flags & WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE) == 0);
		}
		o.put("shown", ov.shown); o.put("keep", ov.keep); o.put("fullscreen", ov.full);
		return o;
	}

	// ---------- التدمير ----------
	private void destroyAsync(final String id, final boolean notify) {
		ui.post(new Runnable() { @Override public void run() { destroyNow(id, notify); } });
	}

	private boolean destroyNow(String id, boolean notify) {
		Ov ov = map.remove(id);
		if (ov == null) return false;
		try { wm.removeView(ov.root); } catch (Throwable ignore) {}
		try { ov.web.stopLoading(); ov.web.removeJavascriptInterface("RosTrickOverlayHost"); ov.root.removeAllViews(); ov.web.destroy(); } catch (Throwable ignore) {}
		if (notify) { try { emit("closed", new JSONObject().put("id", id)); } catch (Throwable ignore) {} }
		return true;
	}

	/** إخفاء/إظهار مؤقت لكل النوافذ (لحظة التقاط الشاشة). */
	void setTempHidden(final boolean hidden) {
		Runnable r = new Runnable() {
			@Override public void run() {
				tempHidden = hidden;
				for (Ov ov : map.values()) {
					try { ov.root.setVisibility(hidden ? View.INVISIBLE : (ov.shown ? View.VISIBLE : View.GONE)); } catch (Throwable ignore) {}
				}
			}
		};
		if (Looper.myLooper() == Looper.getMainLooper()) r.run(); else ui.post(r);
	}

	boolean hasOverlays() { return !map.isEmpty(); }

	// ---------- من MainActivity ----------
	public void onResume() {
		if (permPending) {
			permPending = false;
			try { emit("permission", new JSONObject().put("granted", canDrawNow())); } catch (Throwable ignore) {}
		}
	}

	public void onDestroy() {
		// النوافذ المعلَّمة keep تبقى (مثل زر عائم يعمل والتطبيق بالخلفية)، والباقي يُزال
		ArrayList<String> rm = new ArrayList<String>();
		for (Ov ov : map.values()) if (!ov.keep) rm.add(ov.id);
		for (String id : rm) destroyNow(id, false);
		if (map.isEmpty() && sInstance == this) sInstance = null;
	}

	// ---------- الجسر (RosTrickOverlayBridge) ----------
	@JavascriptInterface public boolean available() { return declared(app); }
	@JavascriptInterface public boolean canDraw() { return declared(app) && canDrawNow(); }

	@JavascriptInterface public boolean requestPermission() {
		if (!declared(app)) return false;
		if (canDrawNow()) { try { emit("permission", new JSONObject().put("granted", true)); } catch (Throwable ignore) {} return true; }
		try {
			Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + app.getPackageName()));
			i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			permPending = true;
			act.startActivity(i);
			return true;
		} catch (Throwable t) { permPending = false; return false; }
	}

	@JavascriptInterface public String create(final String json) {
		return onUi(new java.util.concurrent.Callable<String>() { @Override public String call() throws Exception { return create(obj(json)); } });
	}

	@JavascriptInterface public String update(final String id, final String json) {
		return onUi(new java.util.concurrent.Callable<String>() {
			@Override public String call() throws Exception {
				Ov ov = map.get(id);
				if (ov == null) return err("not_found");
				JSONObject o = obj(json);
				if (o.has("x")) ov.lp.x = dp(o.optDouble("x"));
				if (o.has("y")) ov.lp.y = dp(o.optDouble("y"));
				if (o.has("w")) ov.lp.width = sizeOf(o, "w", 200);
				if (o.has("h")) ov.lp.height = sizeOf(o, "h", 120);
				if (o.has("alpha")) ov.lp.alpha = (float) Math.max(0.0, Math.min(1.0, o.optDouble("alpha", 1.0)));
				if (o.has("touchable")) { if (o.optBoolean("touchable")) ov.lp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE; else ov.lp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE; }
				if (o.has("focusable")) { if (o.optBoolean("focusable")) ov.lp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE; else ov.lp.flags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE; }
				if (o.has("keep")) ov.keep = o.optBoolean("keep");
				if (o.has("gravity")) ov.lp.gravity = gravityOf(o.optString("gravity"));
				upd(ov);
				return ok(describe(ov));
			}
		});
	}

	@JavascriptInterface public boolean show(final String id) {
		ui.post(new Runnable() { @Override public void run() { Ov ov = map.get(id); if (ov == null) return; ov.shown = true; ov.root.setVisibility(tempHidden ? View.INVISIBLE : View.VISIBLE); } });
		return map.containsKey(id);
	}

	@JavascriptInterface public boolean hide(final String id) {
		ui.post(new Runnable() { @Override public void run() { Ov ov = map.get(id); if (ov == null) return; ov.shown = false; ov.root.setVisibility(View.GONE); } });
		return map.containsKey(id);
	}

	@JavascriptInterface public boolean destroy(String id) { boolean has = map.containsKey(id); destroyAsync(id, false); return has; }

	@JavascriptInterface public void destroyAll() {
		ui.post(new Runnable() {
			@Override public void run() { for (String id : new ArrayList<String>(map.keySet())) destroyNow(id, false); }
		});
	}

	@JavascriptInterface public boolean exists(String id) { return map.containsKey(id); }

	@JavascriptInterface public String list() {
		return onUi(new java.util.concurrent.Callable<String>() {
			@Override public String call() throws Exception {
				JSONArray a = new JSONArray();
				for (Ov ov : map.values()) a.put(describe(ov));
				return a.toString();
			}
		});
	}

	@JavascriptInterface public boolean post(final String id, final String json) {
		final Ov ov = map.get(id);
		if (ov == null) return false;
		ui.post(new Runnable() {
			@Override public void run() {
				try { ov.web.evaluateJavascript("window.__rtOvMsg&&window.__rtOvMsg(" + JSONObject.quote(json == null ? "null" : json) + ")", null); } catch (Throwable ignore) {}
			}
		});
		return true;
	}

	/** تنفيذ JS داخل النافذة؛ النتيجة تصل كحدث "result" برقم الطلب reqId. */
	@JavascriptInterface public boolean eval(final String id, final String js, final int reqId) {
		final Ov ov = map.get(id);
		if (ov == null) return false;
		ui.post(new Runnable() {
			@Override public void run() {
				try {
					ov.web.evaluateJavascript(js, new android.webkit.ValueCallback<String>() {
						@Override public void onReceiveValue(String v) {
							try { emit("result", new JSONObject().put("reqId", reqId).put("value", v == null ? "null" : v)); } catch (Throwable ignore) {}
						}
					});
				} catch (Throwable t) {
					try { emit("result", new JSONObject().put("reqId", reqId).put("value", "null")); } catch (Throwable ignore) {}
				}
			}
		});
		return true;
	}

	@JavascriptInterface public String screen() {
		try {
			int[] s = realSize();
			JSONObject o = new JSONObject();
			o.put("w", s[0]); o.put("h", s[1]); o.put("density", density);
			o.put("dpW", Math.round(s[0] / density)); o.put("dpH", Math.round(s[1] / density));
			return o.toString();
		} catch (Throwable t) { return "{}"; }
	}
}
