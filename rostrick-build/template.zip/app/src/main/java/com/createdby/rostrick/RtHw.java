package com.createdby.rostrick;

import android.app.Activity;
import android.content.Intent;
import android.webkit.WebView;

/**
 * نسخة فارغة من واجهات العتاد (Web Bluetooth / WebUSB / Web Serial).
 * عند تفعيل أي منها في إعدادات البناء يستبدلها tools/apply_config.py بالنسخة الحقيقية من tools/RtHwReal.java.txt
 * ويضيف الأذونات اللازمة وملف assets/rt-webapi-hw.js.
 */
public final class RtHw {
	static final boolean ENABLED = false;

	public RtHw(Activity activity, WebView webView) {}
	public boolean onActivityResult(int requestCode, int resultCode, Intent data) { return false; }
	public boolean onPermissionResult(int requestCode, int[] grantResults) { return false; }
	public void onDestroy() {}
}
