package com.createdby.rostrick;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.FrameLayout;
import org.json.JSONObject;

/**
 * تحكّم كامل بشريط الحالة: إظهار/إخفاء، لون (شفاف أو معتم أو بين بين)، لون الأيقونات، الرسم خلف الشريط، ومدة الانتقال.
 * يُدار من الصفحة: وسوم meta، أو عناصر بالسمة screen="rt_statusbar"، أو window.RosTrickStatusBar (assets/rt-native.js).
 * لا يغيّر شيئًا في التطبيق ما لم تطلبه الصفحة.
 * لا تُضاف أي عناصر داخل الحاوية الرئيسية (onBackPressed يعامل آخر عنصر فيها كفيديو بملء الشاشة)،
 * بل في طبقة مستقلة فوق محتوى النافذة (راجع layer()).
 */
public final class RtStatusBar {
	private final Activity act;
	private final WebView web;
	private final Handler ui = new Handler(Looper.getMainLooper());
	private final int defColor;
	private final float density;

	private FrameLayout layer;
	private View bar;
	private int sysL, sysT, sysR, sysB;     // هوامش أشرطة النظام كما وصلت من الحاوية الرئيسية
	private boolean taken = false;          // هل تولّينا النافذة (يحدث عند أول طلب من صفحة)
	private boolean hidden = false, overlay = false, colorSet = false, darkHint = false;
	private int argb = 0, animMs = 200, shown = 0;
	private String icons = "auto";
	private ValueAnimator anim;
	private volatile String stateJson = "{}";

	/** طبقة مستقلة فوق محتوى النافذة تتشاركها واجهات RosTrick (شريط الحالة و WebView الإضافي). */
	static FrameLayout layer(Activity a) {
		ViewGroup content = (ViewGroup) a.findViewById(android.R.id.content);
		for (int i = 0; i < content.getChildCount(); i++) {
			View c = content.getChildAt(i);
			if ("rt_layer".equals(c.getTag()) && c instanceof FrameLayout) return (FrameLayout) c;
		}
		FrameLayout f = new FrameLayout(a);
		f.setTag("rt_layer");
		content.addView(f, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
		return f;
	}

	public RtStatusBar(Activity a, WebView w) {
		act = a; web = w;
		density = a.getResources().getDisplayMetrics().density;
		int c = 0xFF000000;
		try { c = a.getResources().getColor(R.color.colorPrimaryDark); } catch (Throwable ignore) {}
		defColor = c; shown = c;
	}

	/** يُستدعى من مستمع هوامش الحاوية الرئيسية؛ يرجع هامش الأعلى الذي تُطبّقه الحاوية. */
	public int insets(int l, int t, int r, int b) {
		sysL = l; sysT = t; sysR = r; sysB = b;
		if (taken) ui.post(new Runnable() { @Override public void run() { refreshBar(); pushState(); } });
		return (taken && overlay) ? 0 : t;
	}
	int topInset() { return sysT; }
	int leftInset() { return sysL; }
	int rightInset() { return sysR; }
	int bottomInset() { return sysB; }

	private void ensureBar() {
		if (bar != null) return;
		layer = layer(act);
		bar = new View(act);
		bar.setBackgroundColor(shown);
		layer.addView(bar, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, android.view.Gravity.TOP));
	}
	private void refreshBar() {
		if (bar == null) return;
		FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) bar.getLayoutParams();
		if (lp.height != sysT) { lp.height = sysT; bar.setLayoutParams(lp); }
		bar.setVisibility(sysT > 0 ? View.VISIBLE : View.GONE);
		bar.bringToFront();
	}

	/** أول مرة تطلب فيها صفحة التحكم: نجعل المحتوى يمتد خلف الشريط ليتحكم به شريطنا الملوّن. */
	private void takeOver() {
		if (taken) return;
		taken = true;
		try {
			Window w = act.getWindow();
			if (Build.VERSION.SDK_INT >= 21) {
				w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
				w.setStatusBarColor(Color.TRANSPARENT);
			}
			if (Build.VERSION.SDK_INT >= 30) {
				w.setDecorFitsSystemWindows(false);
			} else {
				View d = w.getDecorView();
				d.setSystemUiVisibility(d.getSystemUiVisibility() | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
			}
		} catch (Throwable t) { t.printStackTrace(); }
		ensureBar();
		requestRootInsets();
	}
	private void requestRootInsets() {
		try { View p = (View) web.getParent(); if (p != null) p.requestApplyInsets(); } catch (Throwable ignore) {}
	}

	@JavascriptInterface
	public void apply(final String json) {
		ui.post(new Runnable() { @Override public void run() { doApply(json); } });
	}

	private void doApply(String json) {
		try {
			JSONObject o = new JSONObject(json);
			takeOver();
			if (o.has("mode")) hidden = "hidden".equals(o.optString("mode"));
			else hidden = false;
			if (o.has("argb")) {
				if (o.isNull("argb")) colorSet = false; else { colorSet = true; argb = (int) o.optLong("argb"); }
			} else colorSet = false;
			icons = o.optString("icons", "auto");
			overlay = o.optBoolean("overlay", false);
			animMs = o.has("anim") ? Math.max(0, o.optInt("anim")) : 200;
			darkHint = o.optBoolean("dark", false);
			applyAll(true);
		} catch (Throwable t) { t.printStackTrace(); }
	}

	@JavascriptInterface
	public void reset() {
		ui.post(new Runnable() {
			@Override public void run() {
				if (!taken) return;
				hidden = false; overlay = false; colorSet = false; icons = "auto"; animMs = 200; darkHint = false;
				applyAll(true);
			}
		});
	}

	/** يُظهر الشريط مؤقتًا ثم يعيد إخفاءه إن كانت الصفحة تطلبه مخفيًا. */
	@JavascriptInterface
	public void peek(final int ms) {
		ui.post(new Runnable() {
			@Override public void run() {
				if (!taken || !hidden) return;
				setSystemHidden(false);
				ui.postDelayed(new Runnable() { @Override public void run() { if (hidden) setSystemHidden(true); } }, Math.max(500, ms));
			}
		});
	}

	/** عند عودة النشاط: النظام قد يعيد الأشرطة، فنعيد فرض الإخفاء إن كان مطلوبًا. */
	public void onResume() {
		ui.post(new Runnable() { @Override public void run() { if (taken && hidden) setSystemHidden(true); } });
	}

	@JavascriptInterface
	public String getState() { return stateJson; }

	private void applyAll(boolean animate) {
		int target = colorSet ? argb : defColor;
		setBarColor(target, animate && animMs > 0);
		setSystemHidden(hidden);
		applyIcons(target);
		requestRootInsets();
		refreshBar();
		pushState();
	}

	private void setBarColor(final int target, boolean animate) {
		ensureBar();
		if (anim != null) { try { anim.cancel(); } catch (Throwable ignore) {} anim = null; }
		if (!animate || target == shown) { shown = target; bar.setBackgroundColor(target); return; }
		anim = ValueAnimator.ofObject(new ArgbEvaluator(), Integer.valueOf(shown), Integer.valueOf(target));
		anim.setDuration(animMs);
		anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
			@Override public void onAnimationUpdate(ValueAnimator va) {
				shown = ((Integer) va.getAnimatedValue()).intValue();
				bar.setBackgroundColor(shown);
			}
		});
		anim.start();
	}

	private void setSystemHidden(boolean hide) {
		try {
			Window w = act.getWindow();
			if (Build.VERSION.SDK_INT >= 30) {
				WindowInsetsController c = w.getInsetsController();
				if (c == null) return;
				c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
				if (hide) c.hide(WindowInsets.Type.statusBars()); else c.show(WindowInsets.Type.statusBars());
			} else {
				View d = w.getDecorView();
				int f = d.getSystemUiVisibility();
				int mask = View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
				if (hide) f |= mask; else f &= ~mask;
				d.setSystemUiVisibility(f);
			}
		} catch (Throwable t) { t.printStackTrace(); }
	}

	private static double lum(int c) {
		return (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255.0;
	}
	private boolean darkIcons(int target) {
		if ("dark".equals(icons)) return true;
		if ("light".equals(icons)) return false;
		if (Color.alpha(target) < 128) return !darkHint;   // شفاف: نحكم بخلفية الصفحة (خلفية داكنة → أيقونات فاتحة)
		return lum(target) > 0.6;
	}
	private void applyIcons(int target) {
		boolean dark = darkIcons(target);
		try {
			Window w = act.getWindow();
			if (Build.VERSION.SDK_INT >= 30) {
				WindowInsetsController c = w.getInsetsController();
				if (c != null) c.setSystemBarsAppearance(dark ? WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS : 0, WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS);
			} else if (Build.VERSION.SDK_INT >= 23) {
				View d = w.getDecorView();
				int f = d.getSystemUiVisibility();
				if (dark) f |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR; else f &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
				d.setSystemUiVisibility(f);
			}
		} catch (Throwable t) { t.printStackTrace(); }
	}

	private void pushState() {
		try {
			int target = colorSet ? argb : defColor;
			JSONObject s = new JSONObject();
			s.put("takenOver", taken);
			s.put("hidden", hidden);
			s.put("overlay", taken && overlay);
			s.put("icons", darkIcons(target) ? "dark" : "light");
			s.put("color", String.format("#%08x", target));
			s.put("heightPx", sysT);
			s.put("height", Math.round(sysT / density * 100f) / 100f);
			stateJson = s.toString();
			web.evaluateJavascript("window.__rtSbUpd&&window.__rtSbUpd(" + JSONObject.quote(stateJson) + ")", null);
		} catch (Throwable ignore) {}
	}
}
