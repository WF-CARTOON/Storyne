package com.createdby.rostrick;

import android.app.Activity;
import android.content.ComponentName;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.Comparator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * RosTrick: التقاط الشاشة وقراءة الألوان وتسجيل الشاشة — window.RosTrickScreen.
 *  - الإذن عبر نافذة النظام "تسجيل الشاشة"؛ تعمل الجلسة داخل خدمة أمامية (RtScreenService) تُضاف للـ Manifest عند اختيار screen_capture.
 *  - capture({region}) يُرجع ملف صورة، pixel(x,y) يُرجع لون نقطة من آخر إطار، record.start/stop لتسجيل فيديو MP4.
 *  - الأحداث تصل الصفحة عبر window.__rtScreen(type, json): permission | state | stopped | capture | record.
 *  - جلسة الالتقاط ثابتة (static) كي لا تضيع إن أُعيد إنشاء الـ Activity.
 */
public final class RtScreen {
	static final int REQ = 7411;
	static volatile RtScreen sInstance;

	// ---- جلسة الالتقاط (static) ----
	private static final Object LOCK = new Object();
	private static MediaProjection projection;
	private static VirtualDisplay vd;
	private static ImageReader reader;
	private static HandlerThread frameThread;
	private static Handler frameHandler;
	private static Image latest;
	private static long latestAt = 0;
	private static int rw, rh, rdpi;
	private static boolean recording;
	private static MediaRecorder recorder;
	private static File recFile;
	private static long recStart;
	private static int recW, recH;
	private static int fileSeq = 0;
	private static boolean attaching = false;

	private final Activity act;
	private final Context app;
	private final WebView main;
	private final Handler ui = new Handler(Looper.getMainLooper());
	private final ExecutorService io = Executors.newSingleThreadExecutor();
	private final float density;

	public RtScreen(Activity a, WebView mainWeb) {
		act = a; app = a.getApplicationContext(); main = mainWeb;
		density = Math.max(0.5f, a.getResources().getDisplayMetrics().density);
		sInstance = this;
	}

	static boolean declared(Context c) {
		try { c.getPackageManager().getServiceInfo(new ComponentName(c, RtScreenService.class), 0); return true; }
		catch (Throwable t) { return false; }
	}

	// ---------- الأحداث ----------
	private static void emitStatic(final String type, final JSONObject data) {
		final RtScreen me = sInstance;
		if (me == null) return;
		final String json = data == null ? "{}" : data.toString();
		me.act.runOnUiThread(new Runnable() {
			@Override public void run() {
				try { me.main.evaluateJavascript("window.__rtScreen&&window.__rtScreen(" + JSONObject.quote(type) + "," + JSONObject.quote(json) + ")", null); } catch (Throwable ignore) {}
			}
		});
	}

	private static String err(String e) {
		try { return new JSONObject().put("ok", false).put("error", e).toString(); } catch (Throwable t) { return "{\"ok\":false}"; }
	}

	private static JSONObject errObj(String e) {
		try { return new JSONObject().put("ok", false).put("error", e); } catch (Throwable t) { return new JSONObject(); }
	}

	private static JSONObject obj(String s) {
		try { return s == null || s.length() == 0 ? new JSONObject() : new JSONObject(s); } catch (Throwable t) { return new JSONObject(); }
	}

	private static boolean activeNow() { return projection != null && vd != null; }

	private static JSONObject statusJson(Context c) {
		JSONObject o = new JSONObject();
		try {
			o.put("declared", declared(c));
			o.put("active", activeNow());
			o.put("recording", recording);
			o.put("width", rw); o.put("height", rh);
			o.put("hasFrame", latest != null);
			o.put("sdk", Build.VERSION.SDK_INT);
		} catch (Throwable ignore) {}
		return o;
	}

	// ---------- الإذن ----------
	@JavascriptInterface public boolean available() { return declared(app); }

	@JavascriptInterface public boolean requestPermission() {
		if (!declared(app)) return false;
		if (activeNow()) { try { emitStatic("permission", new JSONObject().put("granted", true)); } catch (Throwable ignore) {} return true; }
		ui.post(new Runnable() {
			@Override public void run() {
				try {
					MediaProjectionManager m = (MediaProjectionManager) app.getSystemService(Context.MEDIA_PROJECTION_SERVICE);
					act.startActivityForResult(m.createScreenCaptureIntent(), REQ);
				} catch (Throwable t) {
					try { emitStatic("permission", new JSONObject().put("granted", false).put("error", String.valueOf(t.getMessage()))); } catch (Throwable ignore) {}
				}
			}
		});
		return true;
	}

	/** من MainActivity.onActivityResult؛ يرجع true إن كان الطلب لنا. */
	public boolean onActivityResult(int req, int res, Intent data) {
		if (req != REQ) return false;
		if (res == Activity.RESULT_OK && data != null) {
			attaching = true;
			Intent si = new Intent(app, RtScreenService.class).setAction(RtScreenService.ACTION_START).putExtra("code", res).putExtra("data", data);
			try {
				if (Build.VERSION.SDK_INT >= 26) app.startForegroundService(si); else app.startService(si);
			} catch (Throwable t) {
				attaching = false;
				try { emitStatic("permission", new JSONObject().put("granted", false).put("error", String.valueOf(t.getMessage()))); } catch (Throwable ignore) {}
			}
		} else {
			try { emitStatic("permission", new JSONObject().put("granted", false).put("error", "denied")); } catch (Throwable ignore) {}
		}
		return true;
	}

	// ---------- من الخدمة ----------
	static void failAttach(String why) {
		attaching = false;
		try { emitStatic("permission", new JSONObject().put("granted", false).put("error", why)); } catch (Throwable ignore) {}
	}

	static void attach(final Context svc, int code, Intent data) throws Exception {
		stopSession(false);
		MediaProjectionManager m = (MediaProjectionManager) svc.getSystemService(Context.MEDIA_PROJECTION_SERVICE);
		MediaProjection p = m.getMediaProjection(code, data);
		if (p == null) throw new IllegalStateException("no_projection");
		if (frameThread == null) { frameThread = new HandlerThread("rt-screen-frames"); frameThread.start(); frameHandler = new Handler(frameThread.getLooper()); }
		// Android 14+: يجب تسجيل callback قبل إنشاء VirtualDisplay
		p.registerCallback(new MediaProjection.Callback() {
			@Override public void onStop() { new Handler(Looper.getMainLooper()).post(new Runnable() { @Override public void run() { stopSession(true); } }); }
		}, frameHandler);
		synchronized (LOCK) {
			projection = p;
			int[] s = realSize(svc);
			buildDisplay(svc, s[0], s[1], s[2]);
		}
		attaching = false;
		try { emitStatic("permission", new JSONObject().put("granted", true)); } catch (Throwable ignore) {}
		emitStatic("state", statusJson(svc));
	}

	private static int[] realSize(Context c) {
		DisplayMetrics dm = new DisplayMetrics();
		try { ((WindowManager) c.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay().getRealMetrics(dm); } catch (Throwable t) { dm = c.getResources().getDisplayMetrics(); }
		return new int[] { dm.widthPixels, dm.heightPixels, dm.densityDpi };
	}

	private static void buildDisplay(Context c, int w, int h, int dpi) {
		rw = w; rh = h; rdpi = dpi;
		reader = newReader(w, h);
		vd = projection.createVirtualDisplay("rt-screen", w, h, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, null);
	}

	private static ImageReader newReader(int w, int h) {
		ImageReader r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3);
		r.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
			@Override public void onImageAvailable(ImageReader rd) {
				Image im = null;
				try { im = rd.acquireLatestImage(); } catch (Throwable ignore) {}
				if (im == null) return;
				synchronized (LOCK) {
					if (latest != null) { try { latest.close(); } catch (Throwable ignore) {} }
					latest = im; latestAt = SystemClock.uptimeMillis();
				}
			}
		}, frameHandler);
		return r;
	}

	/** إن تغيّر حجم الشاشة (تدوير) نعيد إنشاء القارئ ونغيّر حجم الشاشة الافتراضية. */
	private static void ensureSize(Context c) {
		if (recording) return;
		int[] s = realSize(c);
		synchronized (LOCK) {
			if (vd == null || (s[0] == rw && s[1] == rh)) return;
			ImageReader old = reader;
			rw = s[0]; rh = s[1]; rdpi = s[2];
			reader = newReader(rw, rh);
			try { vd.resize(rw, rh, rdpi); vd.setSurface(reader.getSurface()); } catch (Throwable ignore) {}
			if (latest != null) { try { latest.close(); } catch (Throwable ignore) {} latest = null; }
			if (old != null) { try { old.close(); } catch (Throwable ignore) {} }
		}
	}

	static void stopSession(boolean notify) {
		boolean was;
		synchronized (LOCK) {
			was = projection != null;
			if (recording) { try { finishRecorder(); } catch (Throwable ignore) {} }
			if (vd != null) { try { vd.release(); } catch (Throwable ignore) {} vd = null; }
			if (reader != null) { try { reader.close(); } catch (Throwable ignore) {} reader = null; }
			if (latest != null) { try { latest.close(); } catch (Throwable ignore) {} latest = null; }
			MediaProjection p = projection; projection = null;
			if (p != null) { try { p.stop(); } catch (Throwable ignore) {} }
		}
		attaching = false;
		if (was && notify) {
			final RtScreen me = sInstance;
			emitStatic("stopped", new JSONObject());
			if (me != null) emitStatic("state", statusJson(me.app));
		}
	}

	@JavascriptInterface public void stop() {
		stopSession(true);
		try { app.stopService(new Intent(app, RtScreenService.class)); } catch (Throwable ignore) {}
	}

	@JavascriptInterface public String status() { return statusJson(app).toString(); }

	// ---------- الالتقاط ----------
	private static Bitmap toBitmap(Image img) {
		Image.Plane p = img.getPlanes()[0];
		ByteBuffer buf = p.getBuffer();
		int ps = p.getPixelStride(), rs = p.getRowStride();
		int w = img.getWidth(), h = img.getHeight();
		int pad = rs - ps * w;
		buf.rewind();
		Bitmap bm = Bitmap.createBitmap(w + pad / ps, h, Bitmap.Config.ARGB_8888);
		bm.copyPixelsFromBuffer(buf);
		if (pad != 0) { Bitmap c = Bitmap.createBitmap(bm, 0, 0, w, h); bm.recycle(); return c; }
		return bm;
	}

	@JavascriptInterface public boolean capture(final String json, final int reqId) {
		if (!declared(app)) return false;
		io.execute(new Runnable() {
			@Override public void run() {
				JSONObject r;
				try { r = doCapture(obj(json)); } catch (Throwable t) { r = errObj(String.valueOf(t.getMessage())); }
				try { r.put("reqId", reqId); } catch (Throwable ignore) {}
				emitStatic("capture", r);
			}
		});
		return true;
	}

	private File outDir() {
		File d = new File(app.getCacheDir(), "rt_screen");
		if (!d.exists()) d.mkdirs();
		return d;
	}

	private void trimOld(File dir, int keep) {
		try {
			File[] fs = dir.listFiles();
			if (fs == null || fs.length <= keep) return;
			Arrays.sort(fs, new Comparator<File>() { @Override public int compare(File a, File b) { return Long.compare(b.lastModified(), a.lastModified()); } });
			for (int i = keep; i < fs.length; i++) fs[i].delete();
		} catch (Throwable ignore) {}
	}

	private JSONObject doCapture(JSONObject o) throws Exception {
		if (!activeNow()) return errObj("not_active");
		if (recording) return errObj("recording");
		boolean hide = o.optBoolean("hideOverlays", true);
		RtOverlay ov = RtOverlay.sInstance;
		boolean hid = false;
		long tHide = SystemClock.uptimeMillis();
		if (hide && ov != null && ov.hasOverlays()) { ov.setTempHidden(true); hid = true; Thread.sleep(Math.max(0, Math.min(1000, o.optInt("delay", 170)))); tHide = SystemClock.uptimeMillis() - 60; }
		Bitmap bm = null;
		try {
			ensureSize(app);
			long end = SystemClock.uptimeMillis() + 900;
			while (SystemClock.uptimeMillis() < end) {
				synchronized (LOCK) {
					if (latest != null && (!hid || latestAt >= tHide || SystemClock.uptimeMillis() > end - 450)) { bm = toBitmap(latest); break; }
				}
				Thread.sleep(25);
			}
		} finally {
			if (hid && ov != null) ov.setTempHidden(false);
		}
		if (bm == null) return errObj("no_frame");

		JSONObject reg = o.optJSONObject("region");
		if (reg != null) {
			double k = "dp".equals(o.optString("unit", "px")) ? density : 1.0;
			int x = (int) Math.round(reg.optDouble("x", 0) * k), y = (int) Math.round(reg.optDouble("y", 0) * k);
			int w = (int) Math.round(reg.optDouble("w", bm.getWidth()) * k), h = (int) Math.round(reg.optDouble("h", bm.getHeight()) * k);
			x = Math.max(0, Math.min(bm.getWidth() - 1, x)); y = Math.max(0, Math.min(bm.getHeight() - 1, y));
			w = Math.max(1, Math.min(bm.getWidth() - x, w)); h = Math.max(1, Math.min(bm.getHeight() - y, h));
			Bitmap c = Bitmap.createBitmap(bm, x, y, w, h);
			if (c != bm) bm.recycle();
			bm = c;
		}
		double sc = o.optDouble("scale", 1.0);
		if (sc > 0.05 && sc < 0.999) {
			Bitmap c = Bitmap.createScaledBitmap(bm, Math.max(1, (int) Math.round(bm.getWidth() * sc)), Math.max(1, (int) Math.round(bm.getHeight() * sc)), true);
			if (c != bm) bm.recycle();
			bm = c;
		}
		boolean jpeg = "jpeg".equalsIgnoreCase(o.optString("format", "png")) || "jpg".equalsIgnoreCase(o.optString("format", "png"));
		int q = Math.max(1, Math.min(100, o.optInt("quality", 92)));
		File dir = outDir();
		File f = new File(dir, "cap_" + System.currentTimeMillis() + "_" + (++fileSeq) + (jpeg ? ".jpg" : ".png"));
		FileOutputStream fo = new FileOutputStream(f);
		try { bm.compress(jpeg ? Bitmap.CompressFormat.JPEG : Bitmap.CompressFormat.PNG, q, fo); } finally { fo.close(); }
		trimOld(dir, 16);
		JSONObject r = new JSONObject();
		r.put("ok", true);
		r.put("path", f.getAbsolutePath());
		r.put("url", Uri.fromFile(f).toString());
		r.put("width", bm.getWidth()); r.put("height", bm.getHeight());
		r.put("format", jpeg ? "jpeg" : "png"); r.put("size", f.length()); r.put("ts", System.currentTimeMillis());
		if (o.optBoolean("dataUrl", false) && f.length() <= 6L * 1024 * 1024) r.put("dataUrl", "data:" + (jpeg ? "image/jpeg" : "image/png") + ";base64," + Base64.encodeToString(readAll(f), Base64.NO_WRAP));
		if (o.optBoolean("save", false)) { String u = saveToGallery(f, jpeg ? "image/jpeg" : "image/png", false); if (u != null) r.put("savedUri", u); }
		bm.recycle();
		return r;
	}

	private static byte[] readAll(File f) throws Exception {
		FileInputStream in = new FileInputStream(f);
		try {
			ByteArrayOutputStream bo = new ByteArrayOutputStream((int) Math.max(1024, f.length()));
			byte[] b = new byte[16384]; int n;
			while ((n = in.read(b)) > 0) bo.write(b, 0, n);
			return bo.toByteArray();
		} finally { in.close(); }
	}

	/** لون نقطة (أو متوسط حولها) من آخر إطار. x/y بالبكسل الحقيقي للشاشة. */
	@JavascriptInterface public String pixel(int x, int y, int radius) {
		if (!activeNow()) return err("not_active");
		if (recording) return err("recording");
		synchronized (LOCK) {
			if (latest == null) return err("no_frame");
			try {
				Image.Plane p = latest.getPlanes()[0];
				ByteBuffer buf = p.getBuffer();
				int ps = p.getPixelStride(), rs = p.getRowStride(), w = latest.getWidth(), h = latest.getHeight();
				int cx = Math.max(0, Math.min(w - 1, x)), cy = Math.max(0, Math.min(h - 1, y));
				int rad = Math.max(0, Math.min(25, radius));
				long sr = 0, sg = 0, sb = 0, sa = 0; int n = 0;
				for (int j = Math.max(0, cy - rad); j <= Math.min(h - 1, cy + rad); j++) {
					for (int i = Math.max(0, cx - rad); i <= Math.min(w - 1, cx + rad); i++) {
						int off = j * rs + i * ps;
						sr += buf.get(off) & 0xFF; sg += buf.get(off + 1) & 0xFF; sb += buf.get(off + 2) & 0xFF; sa += buf.get(off + 3) & 0xFF; n++;
					}
				}
				if (n == 0) return err("out_of_range");
				int r = (int) (sr / n), g = (int) (sg / n), b = (int) (sb / n), a = (int) (sa / n);
				JSONObject o = new JSONObject();
				o.put("ok", true); o.put("x", cx); o.put("y", cy); o.put("r", r); o.put("g", g); o.put("b", b); o.put("a", a);
				o.put("hex", String.format(java.util.Locale.US, "#%02x%02x%02x", r, g, b));
				return o.toString();
			} catch (Throwable t) { return err(String.valueOf(t.getMessage())); }
		}
	}

	// ---------- التسجيل ----------
	@JavascriptInterface public String recordStart(String json) {
		synchronized (LOCK) {
			if (!activeNow()) return err("not_active");
			if (recording) return err("already_recording");
			JSONObject o = obj(json);
			try {
				double sc = Math.max(0.25, Math.min(1.0, o.optDouble("scale", 1.0)));
				int w = (int) (rw * sc), h = (int) (rh * sc);
				int maxSide = Math.max(w, h);
				if (maxSide > 1920) { double k = 1920.0 / maxSide; w = (int) (w * k); h = (int) (h * k); }
				w = Math.max(2, w - (w % 2)); h = Math.max(2, h - (h % 2));
				int fps = Math.max(5, Math.min(60, o.optInt("fps", 30)));
				int br = o.optInt("bitrate", Math.min(12000000, Math.max(1000000, (int) (w * (long) h * fps * 0.08))));
				File f = new File(outDir(), "rec_" + System.currentTimeMillis() + ".mp4");
				MediaRecorder mr = Build.VERSION.SDK_INT >= 31 ? new MediaRecorder(app) : new MediaRecorder();
				mr.setVideoSource(MediaRecorder.VideoSource.SURFACE);
				mr.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
				mr.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
				mr.setVideoSize(w, h);
				mr.setVideoFrameRate(fps);
				mr.setVideoEncodingBitRate(br);
				mr.setOutputFile(f.getAbsolutePath());
				mr.prepare();
				vd.resize(w, h, rdpi);
				vd.setSurface(mr.getSurface());
				mr.start();
				recorder = mr; recFile = f; recW = w; recH = h; recStart = SystemClock.elapsedRealtime(); recording = true;
				RtScreen me = sInstance;
				emitStatic("state", statusJson(app));
				JSONObject r = new JSONObject(); r.put("ok", true); r.put("width", w); r.put("height", h); r.put("fps", fps);
				return r.toString();
			} catch (Throwable t) {
				try { if (recorder != null) recorder.release(); } catch (Throwable ignore) {}
				recorder = null; recording = false;
				try { if (vd != null && reader != null) { vd.resize(rw, rh, rdpi); vd.setSurface(reader.getSurface()); } } catch (Throwable ignore) {}
				return err(String.valueOf(t.getMessage()));
			}
		}
	}

	/** يُنهي المسجّل ويُعيد الشاشة الافتراضية للقارئ؛ يُستدعى داخل LOCK. */
	private static void finishRecorder() throws Exception {
		MediaRecorder mr = recorder; recorder = null; recording = false;
		Exception ex = null;
		if (mr != null) {
			try { mr.stop(); } catch (RuntimeException e) { ex = e; }
			try { mr.release(); } catch (Throwable ignore) {}
		}
		try { if (vd != null && reader != null) { vd.resize(rw, rh, rdpi); vd.setSurface(reader.getSurface()); } } catch (Throwable ignore) {}
		if (ex != null) throw ex;
	}

	@JavascriptInterface public String recordStop(String json) {
		File f; long dur; int w, h;
		synchronized (LOCK) {
			if (!recording) return err("not_recording");
			f = recFile; w = recW; h = recH; dur = SystemClock.elapsedRealtime() - recStart;
			try { finishRecorder(); } catch (Throwable t) { try { if (f != null) f.delete(); } catch (Throwable ignore) {} emitStatic("state", statusJson(app)); return err("no_frames"); }
		}
		try {
			JSONObject o = obj(json);
			JSONObject r = new JSONObject();
			r.put("ok", true); r.put("path", f.getAbsolutePath()); r.put("url", Uri.fromFile(f).toString());
			r.put("duration", dur); r.put("size", f.length()); r.put("width", w); r.put("height", h);
			if (o.optBoolean("save", false)) { String u = saveToGallery(f, "video/mp4", true); if (u != null) r.put("savedUri", u); }
			trimOld(outDir(), 16);
			emitStatic("state", statusJson(app));
			return r.toString();
		} catch (Throwable t) { return err(String.valueOf(t.getMessage())); }
	}

	// ---------- حفظ في المعرض ----------
	private String saveToGallery(File f, String mime, boolean video) {
		try {
			String name = f.getName();
			if (Build.VERSION.SDK_INT >= 29) {
				ContentValues cv = new ContentValues();
				cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
				cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
				cv.put(MediaStore.MediaColumns.RELATIVE_PATH, (video ? Environment.DIRECTORY_MOVIES : Environment.DIRECTORY_PICTURES) + "/RosTrick");
				cv.put(MediaStore.MediaColumns.IS_PENDING, 1);
				Uri coll = video ? MediaStore.Video.Media.EXTERNAL_CONTENT_URI : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
				Uri u = app.getContentResolver().insert(coll, cv);
				if (u == null) return null;
				OutputStream os = app.getContentResolver().openOutputStream(u);
				InputStream in = new FileInputStream(f);
				try { byte[] b = new byte[16384]; int n; while ((n = in.read(b)) > 0) os.write(b, 0, n); } finally { in.close(); if (os != null) os.close(); }
				ContentValues done = new ContentValues();
				done.put(MediaStore.MediaColumns.IS_PENDING, 0);
				app.getContentResolver().update(u, done, null, null);
				return u.toString();
			} else {
				File dir = new File(Environment.getExternalStoragePublicDirectory(video ? Environment.DIRECTORY_MOVIES : Environment.DIRECTORY_PICTURES), "RosTrick");
				if (!dir.exists() && !dir.mkdirs()) return null;
				File dst = new File(dir, name);
				InputStream in = new FileInputStream(f); OutputStream os = new FileOutputStream(dst);
				try { byte[] b = new byte[16384]; int n; while ((n = in.read(b)) > 0) os.write(b, 0, n); } finally { in.close(); os.close(); }
				android.media.MediaScannerConnection.scanFile(app, new String[] { dst.getAbsolutePath() }, new String[] { mime }, null);
				return Uri.fromFile(dst).toString();
			}
		} catch (Throwable t) { return null; }
	}

	// ---------- دورة الحياة ----------
	public void onDestroy() {
		// الجلسة تبقى (static) ما دامت الخدمة تعمل؛ نفك الارتباط بالواجهة فقط
		if (sInstance == this) sInstance = null;
	}
}
