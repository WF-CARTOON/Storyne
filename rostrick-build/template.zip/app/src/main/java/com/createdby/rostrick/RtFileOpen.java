package com.createdby.rostrick;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * RosTrick: ربط نوع الملف بصفحة (fileopen.json) — منطق بحت بلا اعتماد على أندرويد.
 * الملف في جذر المستودع: {"rules":[{"type":"application/pdf","page":"pdf-viewer.html"}, ...]}
 * عند «فتح بواسطة» أو المشاركة يُنقل المستخدم إلى صفحة النوع المطابق (تطابق تام ثم type/* ثم *\/*).
 * أي قاعدة غير صالحة تُهمَل وحدها؛ ملف غير صالح = لا ربط.
 */
final class RtFileOpen {
	static final int MAX_RULES = 30;
	private static final Pattern MIME = Pattern.compile("^(\\*|[a-z0-9][a-z0-9.+-]*)/(\\*|[a-z0-9][a-z0-9.+_-]*)$");

	static final class Rule {
		final String type, page;
		Rule(String t, String p) { type = t; page = p; }
	}

	/** "Text/Plain; charset=UTF-8" -> "text/plain" */
	static String normMime(String m) {
		if (m == null) return "";
		int sc = m.indexOf(';');
		if (sc >= 0) m = m.substring(0, sc);
		return m.trim().toLowerCase(Locale.ROOT);
	}

	static boolean validPage(String n) {
		if (n == null) return false;
		n = n.trim();
		if (n.length() == 0 || n.length() > 160 || n.indexOf('/') >= 0 || n.indexOf('\\') >= 0 || n.contains("..")) return false;
		String l = n.toLowerCase(Locale.ROOT);
		if (!l.endsWith(".html")) return false;
		return !(l.equals("404.html") || l.equals("splash.html") || l.equals("loader.html") || l.equals("closed.html")
				|| l.equals("maintenance.html") || l.equals("searchbyrostrick.html"));
	}

	static List<Rule> parse(String json) {
		List<Rule> out = new ArrayList<Rule>();
		try {
			if (json == null) return out;
			String t = json.trim();
			if (t.length() == 0 || t.charAt(0) != '{') return out;
			JSONArray arr = new JSONObject(t).optJSONArray("rules");
			if (arr == null) return out;
			for (int i = 0; i < arr.length() && out.size() < MAX_RULES; i++) {
				JSONObject o = arr.optJSONObject(i);
				if (o == null) continue;
				String type = normMime(o.optString("type", ""));
				String page = o.optString("page", "").trim();
				if (!MIME.matcher(type).matches() || !validPage(page)) continue;
				out.add(new Rule(type, page));
			}
		} catch (Throwable ignore) { out.clear(); }
		return out;
	}

	/** اسم الصفحة المطابقة لنوع الملف، أو null. التطابق التام أولاً، ثم type/*، ثم *\/*؛ وعند التكرار الأسبق يفوز. */
	static String pageFor(List<Rule> rules, String mime) {
		String m = normMime(mime);
		if (rules == null || m.length() == 0) return null;
		int slash = m.indexOf('/');
		String wild = slash > 0 ? m.substring(0, slash) + "/*" : "";
		String byWild = null, byAny = null;
		for (Rule r : rules) {
			if (r.type.equals(m)) return r.page;
			if (byWild == null && wild.length() > 0 && r.type.equals(wild)) byWild = r.page;
			if (byAny == null && r.type.equals("*/*")) byAny = r.page;
		}
		return byWild != null ? byWild : byAny;
	}
}
