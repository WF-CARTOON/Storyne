package com.createdby.rostrick;

import android.app.Activity;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.WebView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 * RosTrick: استقبال الملفات والنصوص من التطبيقات الأخرى — window.RosTrickIntent.
 *  - "فتح بواسطة" (ACTION_VIEW)، "مشاركة" (ACTION_SEND / SEND_MULTIPLE)، وقائمة تحديد النص (ACTION_PROCESS_TEXT).
 *  - الفلاتر في الـ Manifest يولّدها البناء من الإعداد intents؛ هذا الصنف ينسخ الملفات إلى مجلد مؤقت خاص ويسلّمها للصفحة.
 *  - الصفحة تستلم: getInitial() (Promise) عند فتح التطبيق بالملف، والحدث rostrick-intent عند وصول ملف والتطبيق يعمل.
 */
public final class RtIntent {
	static final long MAX_FILE = 200L * 1024 * 1024;
	static final int MAX_ITEMS = 20;

	private final Activity act;
	private final WebView main;
	private final ExecutorService io = Executors.newSingleThreadExecutor();
	private Future<JSONObject> pending;

	public RtIntent(Activity a, WebView w) {
		act = a; main = w;
		io.execute(new Runnable() { @Override public void run() { cleanup(); } });
	}

	/** هل أعلن البناء أي فلاتر؟ (meta-data داخل SplashActivity: rt.intents). */
	static String declared(Context c) {
		try {
			ActivityInfo ai = c.getPackageManager().getActivityInfo(new ComponentName(c, SplashActivity.class), PackageManager.GET_META_DATA);
			Bundle b = ai.metaData;
			return b == null ? "" : String.valueOf(b.getString("rt.intents", ""));
		} catch (Throwable t) { return ""; }
	}

	static boolean isIntentOfInterest(Intent i) {
		if (i == null || i.getAction() == null) return false;
		String a = i.getAction();
		if (Intent.ACTION_SEND.equals(a) || Intent.ACTION_SEND_MULTIPLE.equals(a)) return true;
		if ("android.intent.action.PROCESS_TEXT".equals(a)) return true;
		if (Intent.ACTION_VIEW.equals(a)) {
			Uri d = i.getData();
			String s = d == null ? "" : String.valueOf(d.getScheme()).toLowerCase(java.util.Locale.ROOT);
			return "content".equals(s) || "file".equals(s);
		}
		return false;
	}

	private File inDir() {
		File d = new File(act.getCacheDir(), "rt_in");
		if (!d.exists()) d.mkdirs();
		return d;
	}

	private void cleanup() {
		try {
			File[] fs = inDir().listFiles();
			if (fs == null) return;
			long old = System.currentTimeMillis() - 24L * 3600 * 1000;
			for (File f : fs) if (f.lastModified() < old) f.delete();
		} catch (Throwable ignore) {}
	}

	private static String safe(String n) {
		String s = n == null ? "" : n.replaceAll("[^\\p{L}\\p{N}._-]", "_");
		if (s.length() == 0 || s.startsWith(".")) s = "file" + s;
		if (s.length() > 80) s = s.substring(s.length() - 80);
		return s;
	}

	private String nameOf(Uri u) {
		String n = null;
		if ("content".equals(u.getScheme())) {
			Cursor c = null;
			try {
				c = act.getContentResolver().query(u, new String[] { OpenableColumns.DISPLAY_NAME }, null, null, null);
				if (c != null && c.moveToFirst()) n = c.getString(0);
			} catch (Throwable ignore) {} finally { if (c != null) c.close(); }
		}
		if (n == null || n.length() == 0) n = u.getLastPathSegment();
		return n == null ? "file" : n;
	}

	private String mimeOf(Uri u, String hint) { return mimeOf(act, u, hint); }

	static String mimeOf(Context c, Uri u, String hint) {
		String m = null;
		try { m = c.getContentResolver().getType(u); } catch (Throwable ignore) {}
		if (m == null || m.length() == 0 || m.equals("application/octet-stream")) {
			String ext = MimeTypeMap.getFileExtensionFromUrl(String.valueOf(u));
			if (ext != null && ext.length() > 0) m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext.toLowerCase(java.util.Locale.ROOT));
		}
		if (m == null || m.length() == 0) m = hint != null ? hint : "application/octet-stream";
		return m;
	}

	/**
	 * نوع الملف الأول في الـ Intent دون نسخه (لاختيار الصفحة المربوطة قبل اكتمال النسخ).
	 * النص المشارك أو المحدد = text/plain.
	 */
	static String peekMime(Context c, Intent i) {
		try {
			if (i == null || i.getAction() == null) return "";
			String a = i.getAction();
			if ("android.intent.action.PROCESS_TEXT".equals(a)) return "text/plain";
			Uri u = null;
			if (Intent.ACTION_VIEW.equals(a)) u = i.getData();
			else {
				try { u = i.getParcelableExtra(Intent.EXTRA_STREAM); } catch (Throwable ignore) {}
				if (u == null) {
					try {
						ArrayList<Uri> many = i.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
						if (many != null && many.size() > 0) u = many.get(0);
					} catch (Throwable ignore) {}
				}
				if (u == null) {
					ClipData cd = i.getClipData();
					if (cd != null && cd.getItemCount() > 0) u = cd.getItemAt(0).getUri();
				}
				if (u == null) {
					CharSequence t = i.getCharSequenceExtra(Intent.EXTRA_TEXT);
					return t != null ? "text/plain" : (i.getType() == null ? "" : i.getType());
				}
			}
			return u == null ? (i.getType() == null ? "" : i.getType()) : mimeOf(c, u, i.getType());
		} catch (Throwable t) { return ""; }
	}

	private JSONObject copyOne(Uri u, int idx, String hint) {
		JSONObject it = new JSONObject();
		try {
			String name = nameOf(u);
			String mime = mimeOf(u, hint);
			File dst = new File(inDir(), System.currentTimeMillis() + "_" + idx + "_" + safe(name));
			InputStream in = "file".equals(u.getScheme()) ? new java.io.FileInputStream(new File(u.getPath())) : act.getContentResolver().openInputStream(u);
			if (in == null) return it.put("ok", false).put("error", "open_failed").put("name", name);
			long total = 0; boolean tooBig = false;
			FileOutputStream out = new FileOutputStream(dst);
			try {
				byte[] b = new byte[32768]; int n;
				while ((n = in.read(b)) > 0) { total += n; if (total > MAX_FILE) { tooBig = true; break; } out.write(b, 0, n); }
			} finally { in.close(); out.close(); }
			if (tooBig) { dst.delete(); return it.put("ok", false).put("error", "too_big").put("name", name); }
			it.put("ok", true).put("name", name).put("mime", mime).put("size", total).put("path", dst.getAbsolutePath()).put("url", Uri.fromFile(dst).toString());
		} catch (Throwable t) {
			try { it.put("ok", false).put("error", String.valueOf(t.getMessage())); } catch (Throwable ignore) {}
		}
		return it;
	}

	private JSONObject build(Intent i) throws Exception {
		JSONObject o = new JSONObject();
		String a = i.getAction();
		String type = i.getType();
		JSONArray items = new JSONArray();
		ArrayList<Uri> uris = new ArrayList<Uri>();
		if ("android.intent.action.PROCESS_TEXT".equals(a)) {
			CharSequence t = i.getCharSequenceExtra("android.intent.extra.PROCESS_TEXT");
			o.put("action", "process_text").put("text", t == null ? "" : t.toString());
		} else if (Intent.ACTION_VIEW.equals(a)) {
			o.put("action", "view");
			if (i.getData() != null) uris.add(i.getData());
		} else {
			o.put("action", Intent.ACTION_SEND_MULTIPLE.equals(a) ? "send_multiple" : "send");
			CharSequence t = i.getCharSequenceExtra(Intent.EXTRA_TEXT);
			if (t != null) o.put("text", t.toString());
			CharSequence sj = i.getCharSequenceExtra(Intent.EXTRA_SUBJECT);
			if (sj != null) o.put("subject", sj.toString());
			Uri one = null;
			try { one = i.getParcelableExtra(Intent.EXTRA_STREAM); } catch (Throwable ignore) {}
			if (one != null) uris.add(one);
			try {
				ArrayList<Uri> many = i.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
				if (many != null) for (Uri u : many) if (u != null && !uris.contains(u)) uris.add(u);
			} catch (Throwable ignore) {}
			ClipData cd = i.getClipData();
			if (cd != null) for (int k = 0; k < cd.getItemCount(); k++) { Uri u = cd.getItemAt(k).getUri(); if (u != null && !uris.contains(u)) uris.add(u); }
		}
		o.put("mime", type == null ? "" : type);
		o.put("ts", System.currentTimeMillis());
		for (int k = 0; k < uris.size() && k < MAX_ITEMS; k++) items.put(copyOne(uris.get(k), k, type));
		o.put("items", items);
		return o;
	}

	/** تُستدعى من MainActivity عند وصول Intent (onCreate/onNewIntent). */
	public void handle(final Intent i) { handle(i, true); }

	/**
	 * pushToPage=false عندما سينتقل التطبيق إلى صفحة مربوطة بنوع الملف: لا نرسل الحدث للصفحة الحالية،
	 * وتستلم الصفحة الجديدة الملف عبر getInitial() عند فتحها.
	 */
	public void handle(final Intent i, final boolean pushToPage) {
		if (!isIntentOfInterest(i)) return;
		final Intent copy = new Intent(i);
		pending = io.submit(new java.util.concurrent.Callable<JSONObject>() {
			@Override public JSONObject call() throws Exception {
				JSONObject o = build(copy);
				if (pushToPage) push(o);
				return o;
			}
		});
	}

	private void push(final JSONObject o) {
		final String json = o.toString();
		act.runOnUiThread(new Runnable() {
			@Override public void run() {
				try { main.evaluateJavascript("window.__rtIntent&&window.__rtIntent(" + JSONObject.quote(json) + ")", null); } catch (Throwable ignore) {}
			}
		});
	}

	// ---------- الجسر (RosTrickIntentBridge) ----------
	@JavascriptInterface public String enabled() { return declared(act); }

	/** آخر Intent لم يُمسح (انتظار اكتمال النسخ حتى 20 ثانية)؛ "" إن لم يوجد. */
	@JavascriptInterface public String getInitial() {
		Future<JSONObject> f = pending;
		if (f == null) return "";
		try { return f.get(20, TimeUnit.SECONDS).toString(); } catch (Throwable t) { return ""; }
	}

	@JavascriptInterface public void clear() { pending = null; }

	@JavascriptInterface public boolean remove(String path) {
		try {
			File f = new File(path);
			if (f.getCanonicalPath().startsWith(inDir().getCanonicalPath() + File.separator)) return f.delete();
		} catch (Throwable ignore) {}
		return false;
	}

	public void onDestroy() {}
}
