package com.createdby.rostrick;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.WebView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;

/**
 * RosTrick: سجل التنزيلات — window.RosTrickDownloads (يعمل دائماً بلا إعداد ولا أذونات إضافية).
 * يتتبّع كل ما ينزّله التطبيق (DownloadManager لروابط http/https، وملفات data:/blob: المحفوظة في Downloads)،
 * ويتيح للصفحة: قراءة القائمة وحالتها (pending/running/paused/done/failed/removed) ونسبة التقدّم،
 * وفتح الملف المكتمل أو مشاركته أو حذفه أو إلغاء التنزيل، وفتح تطبيق «التنزيلات» في النظام.
 * الأحداث تصل للصفحة عبر window.__rtDl(type, json) (انظر assets/rt-native.js).
 */
public final class RtDownloads {
	private static final String PREFS = "rostrick_downloads";
	private static final String KEY = "items";
	private static final int MAX_ITEMS = 100;
	private static final long POLL_MS = 700;

	private final Activity act;
	private final WebView web;
	private final Handler ui = new Handler(Looper.getMainLooper());
	private final Object lock = new Object();
	private JSONArray items = new JSONArray(); // الأحدث أولاً
	private boolean polling = false;
	private int seq = 0;

	public RtDownloads(Activity activity, WebView webView) {
		this.act = activity;
		this.web = webView;
		load();
		if (hasActive()) startPolling();
		trimCache();
	}

	// ---------- التخزين ----------
	private SharedPreferences prefs() { return act.getSharedPreferences(PREFS, Context.MODE_PRIVATE); }

	private void load() {
		synchronized (lock) {
			try { items = new JSONArray(prefs().getString(KEY, "[]")); } catch (Throwable e) { items = new JSONArray(); }
		}
	}

	private void save() {
		synchronized (lock) {
			try {
				while (items.length() > MAX_ITEMS) items.remove(items.length() - 1);
				prefs().edit().putString(KEY, items.toString()).apply();
			} catch (Throwable ignore) {}
		}
	}

	private int indexOf(String id) {
		for (int i = 0; i < items.length(); i++) {
			JSONObject o = items.optJSONObject(i);
			if (o != null && id != null && id.equals(o.optString("id"))) return i;
		}
		return -1;
	}

	private JSONObject find(String id) {
		synchronized (lock) {
			int i = indexOf(id);
			return i < 0 ? null : items.optJSONObject(i);
		}
	}

	private boolean isActiveState(String s) { return "pending".equals(s) || "running".equals(s) || "paused".equals(s); }

	private boolean hasActive() {
		synchronized (lock) {
			for (int i = 0; i < items.length(); i++) {
				JSONObject o = items.optJSONObject(i);
				if (o != null && o.optLong("dm", -1) >= 0 && isActiveState(o.optString("state"))) return true;
			}
		}
		return false;
	}

	private String newId() { return "d" + Long.toString(System.currentTimeMillis(), 36) + (++seq); }

	private DownloadManager dm() { return (DownloadManager) act.getSystemService(Context.DOWNLOAD_SERVICE); }

	// ---------- التسجيل (يُستدعى من MainActivity من أي خيط) ----------
	/** تنزيل بدأ عبر DownloadManager. */
	public void trackDm(long dmId, String url, String name, String mime) {
		try {
			JSONObject o = new JSONObject();
			o.put("id", newId()); o.put("dm", dmId); o.put("url", url == null ? "" : url);
			o.put("name", name == null ? "" : name); o.put("mime", mime == null ? "" : mime);
			o.put("ts", System.currentTimeMillis()); o.put("state", "pending"); o.put("bytes", 0); o.put("total", -1);
			synchronized (lock) {
				JSONArray n = new JSONArray(); n.put(o);
				for (int i = 0; i < items.length(); i++) n.put(items.opt(i));
				items = n;
			}
			save();
			emit("start", o);
			startPolling();
		} catch (Throwable ignore) {}
	}

	/** ملف حُفظ كاملاً في Downloads عبر MediaStore (data:/blob:) — uri من نوع content://. */
	public void trackSaved(String uri, String name, String mime, long size) {
		try {
			JSONObject o = new JSONObject();
			o.put("id", newId()); o.put("dm", -1); o.put("url", ""); o.put("uri", uri == null ? "" : uri);
			o.put("name", name == null ? "" : name); o.put("mime", mime == null ? "" : mime);
			o.put("ts", System.currentTimeMillis()); o.put("state", "done"); o.put("bytes", size); o.put("total", size);
			synchronized (lock) {
				JSONArray n = new JSONArray(); n.put(o);
				for (int i = 0; i < items.length(); i++) n.put(items.opt(i));
				items = n;
			}
			save();
			emit("start", o);
			emit("done", o);
		} catch (Throwable ignore) {}
	}

	/** ملف كُتب مباشرة في مجلد Downloads العام (أندرويد 9 وأقل): نسجّله في DownloadManager ليظهر في تطبيق التنزيلات ويمكن فتحه. */
	public void trackFile(File f, String mime) {
		try {
			long id = dm().addCompletedDownload(f.getName(), f.getName(), true, mime == null || mime.length() == 0 ? "application/octet-stream" : mime, f.getAbsolutePath(), f.length(), true);
			trackDm(id, "", f.getName(), mime);
		} catch (Throwable e) {
			trackSaved(Uri.fromFile(f).toString(), f.getName(), mime, f.length());
		}
	}

	// ---------- المراقبة ----------
	private void startPolling() {
		synchronized (lock) { if (polling) return; polling = true; }
		ui.postDelayed(pollTask, POLL_MS);
	}

	private final Runnable pollTask = new Runnable() {
		@Override public void run() {
			boolean again = false;
			try { again = pollOnce(); } catch (Throwable ignore) {}
			if (again) ui.postDelayed(this, POLL_MS);
			else synchronized (lock) { polling = false; }
		}
	};

	/** يحدّث حالة التنزيلات النشطة ويبثّ الأحداث. يرجع true إن بقي تنزيل نشط. */
	private boolean pollOnce() {
		boolean active = false;
		JSONArray snapshot = new JSONArray();
		synchronized (lock) { for (int i = 0; i < items.length(); i++) snapshot.put(items.opt(i)); }
		boolean changed = false;
		for (int i = 0; i < snapshot.length(); i++) {
			JSONObject o = snapshot.optJSONObject(i);
			if (o == null || o.optLong("dm", -1) < 0 || !isActiveState(o.optString("state"))) continue;
			String before = o.optString("state"); long bytesBefore = o.optLong("bytes", 0);
			refresh(o);
			String after = o.optString("state");
			if (isActiveState(after)) active = true;
			if (!after.equals(before)) {
				changed = true;
				if ("done".equals(after)) emit("done", o);
				else if ("failed".equals(after)) emit("failed", o);
				else if ("removed".equals(after)) emit("removed", o);
				else emit("progress", o);
			} else if (o.optLong("bytes", 0) != bytesBefore) {
				emit("progress", o);
			}
		}
		if (changed) save();
		return active;
	}

	/** يقرأ حالة عنصر DownloadManager الحيّة ويكتبها في الكائن. */
	private void refresh(JSONObject o) {
		long dmId = o.optLong("dm", -1);
		if (dmId < 0) return;
		Cursor c = null;
		try {
			c = dm().query(new DownloadManager.Query().setFilterById(dmId));
			if (c == null || !c.moveToFirst()) { o.put("state", "removed"); return; }
			applyRow(c, o);
		} catch (Throwable ignore) {
		} finally { if (c != null) c.close(); }
	}

	/** يطبّق صفّ DownloadManager (المؤشر عليه الآن) على كائن العنصر. */
	private void applyRow(Cursor c, JSONObject o) throws org.json.JSONException {
		int st = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
		o.put("bytes", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)));
		o.put("total", c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)));
		o.put("reason", c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_REASON)));
		String state;
		if (st == DownloadManager.STATUS_SUCCESSFUL) state = "done";
		else if (st == DownloadManager.STATUS_FAILED) state = "failed";
		else if (st == DownloadManager.STATUS_RUNNING) state = "running";
		else if (st == DownloadManager.STATUS_PAUSED) state = "paused";
		else state = "pending";
		o.put("state", state);
		if ("done".equals(state)) {
			String local = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI));
			if (local != null) {
				Uri lu = Uri.parse(local);
				if ("file".equals(lu.getScheme()) && lu.getPath() != null) o.put("path", lu.getPath());
			}
			String mt = c.getString(c.getColumnIndexOrThrow(DownloadManager.COLUMN_MEDIA_TYPE));
			if (mt != null && mt.length() > 0 && o.optString("mime").length() == 0) o.put("mime", mt);
			long tot = o.optLong("total", -1), by = o.optLong("bytes", 0);
			if (tot < 0 && by > 0) o.put("total", by);
		}
	}

	/** يحدّث كل عناصر DownloadManager بطلب واحد (والمفقود منها في النظام يصير removed). يرجع true إن تغيّرت حالة ما. */
	private boolean refreshAll() {
		java.util.ArrayList<JSONObject> objs = new java.util.ArrayList<JSONObject>();
		java.util.ArrayList<Long> ids = new java.util.ArrayList<Long>();
		synchronized (lock) {
			for (int i = 0; i < items.length(); i++) {
				JSONObject o = items.optJSONObject(i);
				if (o != null && o.optLong("dm", -1) >= 0 && !"removed".equals(o.optString("state"))) { objs.add(o); ids.add(Long.valueOf(o.optLong("dm"))); }
			}
		}
		if (objs.isEmpty()) return false;
		long[] arr = new long[ids.size()];
		for (int i = 0; i < arr.length; i++) arr[i] = ids.get(i).longValue();
		boolean changed = false;
		java.util.HashMap<Long, JSONObject> byDm = new java.util.HashMap<Long, JSONObject>();
		for (JSONObject o : objs) byDm.put(Long.valueOf(o.optLong("dm")), o);
		Cursor c = null;
		try {
			c = dm().query(new DownloadManager.Query().setFilterById(arr));
			if (c == null) return false;
			while (c.moveToNext()) {
				long rid = c.getLong(c.getColumnIndexOrThrow(DownloadManager.COLUMN_ID));
				JSONObject o = byDm.remove(Long.valueOf(rid));
				if (o == null) continue;
				String before = o.optString("state");
				applyRow(c, o);
				if (!before.equals(o.optString("state"))) changed = true;
			}
			for (JSONObject gone : byDm.values()) { gone.put("state", "removed"); changed = true; }
		} catch (Throwable ignore) {
		} finally { if (c != null) c.close(); }
		return changed;
	}

	// ---------- البثّ للصفحة ----------
	private void emit(final String type, final JSONObject item) {
		final String json = item.toString();
		act.runOnUiThread(new Runnable() {
			@Override public void run() {
				try { web.evaluateJavascript("window.__rtDl&&window.__rtDl(" + JSONObject.quote(type) + "," + JSONObject.quote(json) + ")", null); } catch (Throwable ignore) {}
			}
		});
	}

	private void toast(final String ar, final String en) {
		act.runOnUiThread(new Runnable() {
			@Override public void run() { try { Toast.makeText(act, RtI18n.t(ar, en), Toast.LENGTH_SHORT).show(); } catch (Throwable ignore) {} }
		});
	}

	// ---------- واجهة الصفحة ----------
	@JavascriptInterface
	public String list() {
		boolean changed = refreshAll();
		JSONArray out = new JSONArray();
		synchronized (lock) { for (int i = 0; i < items.length(); i++) { JSONObject o = items.optJSONObject(i); if (o != null) out.put(o); } }
		if (changed) { save(); if (hasActive()) startPolling(); }
		return out.toString();
	}

	@JavascriptInterface
	public String get(String id) {
		JSONObject o = find(id);
		if (o == null) return "";
		if (o.optLong("dm", -1) >= 0) refresh(o);
		return o.toString();
	}

	/** Uri قابل للقراءة من تطبيق آخر للملف المكتمل، أو null. */
	private Uri contentUri(JSONObject o) {
		try {
			long dmId = o.optLong("dm", -1);
			if (dmId >= 0) return dm().getUriForDownloadedFile(dmId);
			String u = o.optString("uri");
			return u.length() > 0 ? Uri.parse(u) : null;
		} catch (Throwable e) { return null; }
	}

	private String mimeOf(JSONObject o) {
		String m = o.optString("mime");
		if (m.length() > 0 && !"application/octet-stream".equals(m)) return m;
		String name = o.optString("name");
		int dot = name.lastIndexOf('.');
		if (dot >= 0 && dot < name.length() - 1) {
			String g = MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substring(dot + 1).toLowerCase(java.util.Locale.ROOT));
			if (g != null) return g;
		}
		try {
			long dmId = o.optLong("dm", -1);
			if (dmId >= 0) { String g2 = dm().getMimeTypeForDownloadedFile(dmId); if (g2 != null && g2.length() > 0) return g2; }
		} catch (Throwable ignore) {}
		return m.length() > 0 ? m : "*/*";
	}

	/** يفتح الملف المكتمل بالتطبيق المناسب في الجهاز. */
	@JavascriptInterface
	public boolean open(final String id) {
		final JSONObject o = find(id);
		if (o == null) return false;
		if (o.optLong("dm", -1) >= 0) refresh(o);
		if (!"done".equals(o.optString("state"))) { toast("الملف لم يكتمل بعد", "The file is not finished yet"); return false; }
		final Uri u = contentUri(o);
		if (u == null) { toast("الملف غير موجود (ربما حُذف)", "File not found (it may have been deleted)"); return false; }
		final String mime = mimeOf(o);
		act.runOnUiThread(new Runnable() {
			@Override public void run() {
				try {
					Intent i = new Intent(Intent.ACTION_VIEW);
					i.setDataAndType(u, mime);
					i.setClipData(ClipData.newRawUri("", u));
					i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
					act.startActivity(i);
				} catch (Throwable e) {
					toast("لا يوجد تطبيق يفتح هذا النوع من الملفات", "No app can open this file type");
				}
			}
		});
		return true;
	}

	/** يشارك الملف المكتمل عبر قائمة المشاركة. */
	@JavascriptInterface
	public boolean share(final String id) {
		final JSONObject o = find(id);
		if (o == null) return false;
		if (o.optLong("dm", -1) >= 0) refresh(o);
		if (!"done".equals(o.optString("state"))) return false;
		final Uri u = contentUri(o);
		if (u == null) return false;
		final String mime = mimeOf(o);
		act.runOnUiThread(new Runnable() {
			@Override public void run() {
				try {
					Intent s = new Intent(Intent.ACTION_SEND);
					s.setType(mime);
					s.putExtra(Intent.EXTRA_STREAM, u);
					s.setClipData(ClipData.newRawUri("", u));
					s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
					Intent ch = Intent.createChooser(s, o.optString("name"));
					ch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					act.startActivity(ch);
				} catch (Throwable ignore) {}
			}
		});
		return true;
	}

	/** يحذف العنصر من القائمة، ومع deleteFile=true يحذف الملف نفسه من الجهاز (أو يلغي التنزيل الجاري). */
	@JavascriptInterface
	public boolean remove(String id, boolean deleteFile) {
		JSONObject o = find(id);
		if (o == null) return false;
		try {
			if (deleteFile || isActiveState(o.optString("state"))) {
				long dmId = o.optLong("dm", -1);
				if (dmId >= 0) dm().remove(dmId);
				else if (o.optString("uri").length() > 0) { try { act.getContentResolver().delete(Uri.parse(o.optString("uri")), null, null); } catch (Throwable ignore) {} }
			}
		} catch (Throwable ignore) {}
		synchronized (lock) {
			int i = indexOf(id);
			if (i >= 0) items.remove(i);
		}
		save();
		try { o.put("state", "removed"); } catch (Throwable ignore) {}
		emit("removed", o);
		return true;
	}

	@JavascriptInterface
	public boolean cancel(String id) { return remove(id, true); }

	/** يفرّغ القائمة فقط (لا يحذف أي ملف) ويلغي النشط منها. */
	@JavascriptInterface
	public boolean clear() {
		JSONArray copy = new JSONArray();
		synchronized (lock) { for (int i = 0; i < items.length(); i++) copy.put(items.opt(i)); }
		for (int i = 0; i < copy.length(); i++) {
			JSONObject o = copy.optJSONObject(i);
			if (o != null && isActiveState(o.optString("state"))) remove(o.optString("id"), true);
		}
		synchronized (lock) { items = new JSONArray(); }
		save();
		return true;
	}

	/** يفتح تطبيق «التنزيلات» في النظام. */
	@JavascriptInterface
	public boolean openFolder() {
		act.runOnUiThread(new Runnable() {
			@Override public void run() {
				try {
					Intent i = new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS);
					i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					act.startActivity(i);
				} catch (Throwable e) { toast("تعذّر فتح التنزيلات", "Could not open Downloads"); }
			}
		});
		return true;
	}

	// ---------- التشغيل/العرض داخل التطبيق ----------
	// الصفحة (file://) تقدر تشغّل ملفًا محليًا حقيقيًا مباشرة (مع seek كامل من مشغّل النظام)، لكن ملفات DownloadManager/MediaStore قد لا تُقرأ بمسارها
	// على أندرويد الحديث؛ لذلك prepare() يرجع المسار المباشر إن كان مقروءًا، وإلا ينسخ الملف إلى ذاكرة التطبيق المؤقتة (rt_open) ويرجع مسار النسخة.
	private File openDir() { File d = new File(act.getCacheDir(), "rt_open"); d.mkdirs(); return d; }

	private boolean readable(File f) {
		InputStream in = null;
		try { in = new FileInputStream(f); in.read(); return true; } catch (Throwable e) { return false; }
		finally { try { if (in != null) in.close(); } catch (Throwable ignore) {} }
	}

	private static String safeName(String n) {
		String x = n == null ? "" : n.replaceAll("[/\\\\:*?\"<>|]", "_").trim();
		return x.length() == 0 ? "file" : x;
	}

	private void prepReply(final int req, final JSONObject o) {
		final String json = o.toString();
		act.runOnUiThread(new Runnable() {
			@Override public void run() {
				try { web.evaluateJavascript("window.__rtDlPrep&&window.__rtDlPrep(" + req + "," + JSONObject.quote(json) + ")", null); } catch (Throwable ignore) {}
			}
		});
	}

	private JSONObject prepErr(String code) {
		try { return new JSONObject().put("done", true).put("ok", false).put("error", code); } catch (Throwable e) { return new JSONObject(); }
	}

	/** يجهّز الملف المكتمل للعرض داخل الصفحة. الردّ يصل عبر window.__rtDlPrep(req, json): {done, ok, url, path, mime, name, size, copied, bytes, total, error}. */
	@JavascriptInterface
	public boolean prepare(final String id, final int req) {
		final JSONObject item = find(id);
		if (item == null) { prepReply(req, prepErr("notfound")); return false; }
		new Thread(new Runnable() {
			@Override public void run() {
				try {
					if (item.optLong("dm", -1) >= 0) refresh(item);
					if (!"done".equals(item.optString("state"))) { prepReply(req, prepErr(isActiveState(item.optString("state")) ? "notdone" : "missing")); return; }
					String name = item.optString("name"), mime = mimeOf(item);
					JSONObject r = new JSONObject();
					r.put("done", true).put("ok", true).put("mime", mime).put("name", name);
					String p = item.optString("path");
					if (p.length() > 0) {
						File f = new File(p);
						if (f.exists() && readable(f)) {
							r.put("path", f.getAbsolutePath()).put("url", Uri.fromFile(f).toString()).put("size", f.length()).put("copied", false);
							prepReply(req, r); return;
						}
					}
					Uri u = contentUri(item);
					if (u == null) { prepReply(req, prepErr("missing")); return; }
					File out = new File(openDir(), safeName(id) + "_" + safeName(name));
					long total = item.optLong("total", -1);
					if (out.exists() && out.length() > 0 && (total <= 0 || out.length() == total)) {
						out.setLastModified(System.currentTimeMillis());
					} else {
						File part = new File(out.getPath() + ".part");
						InputStream in = null; FileOutputStream fo = null;
						try {
							in = act.getContentResolver().openInputStream(u);
							if (in == null) { prepReply(req, prepErr("missing")); return; }
							fo = new FileOutputStream(part);
							byte[] buf = new byte[65536]; long done = 0, lastEmit = 0; int n;
							while ((n = in.read(buf)) > 0) {
								fo.write(buf, 0, n); done += n;
								if (done - lastEmit >= 2 * 1024 * 1024) { lastEmit = done; prepReply(req, new JSONObject().put("done", false).put("bytes", done).put("total", total)); }
							}
							fo.flush(); fo.close(); fo = null; in.close(); in = null;
							if (out.exists()) out.delete();
							if (!part.renameTo(out)) { prepReply(req, prepErr("copy")); return; }
						} catch (Throwable e) {
							try { part.delete(); } catch (Throwable ignore) {}
							prepReply(req, prepErr("copy")); return;
						} finally {
							try { if (fo != null) fo.close(); } catch (Throwable ignore) {}
							try { if (in != null) in.close(); } catch (Throwable ignore) {}
						}
					}
					r.put("path", out.getAbsolutePath()).put("url", Uri.fromFile(out).toString()).put("size", out.length()).put("copied", true);
					prepReply(req, r);
				} catch (Throwable e) { prepReply(req, prepErr("error")); }
			}
		}).start();
		return true;
	}

	/** حجم النسخ المؤقتة المنسوخة للعرض (بالبايت). */
	@JavascriptInterface
	public long cacheSize() {
		long t = 0;
		try { File[] fs = openDir().listFiles(); if (fs != null) for (File f : fs) t += f.length(); } catch (Throwable ignore) {}
		return t;
	}

	/** يحذف النسخ المؤقتة (لا يمس التنزيلات الأصلية). */
	@JavascriptInterface
	public boolean clearCache() {
		try { File[] fs = openDir().listFiles(); if (fs != null) for (File f : fs) f.delete(); return true; } catch (Throwable e) { return false; }
	}

	private void trimCache() {
		new Thread(new Runnable() {
			@Override public void run() {
				try {
					long cut = System.currentTimeMillis() - 3L * 24 * 3600 * 1000;
					File[] fs = openDir().listFiles();
					if (fs != null) for (File f : fs) if (f.lastModified() < cut) f.delete();
				} catch (Throwable ignore) {}
			}
		}).start();
	}

	/** خلاصة سريعة: عدد النشط ومجموع التقدّم. */
	@JavascriptInterface
	public String summary() {
		int active = 0, done = 0, failed = 0; long bytes = 0, total = 0;
		synchronized (lock) {
			for (int i = 0; i < items.length(); i++) {
				JSONObject o = items.optJSONObject(i);
				if (o == null) continue;
				String s = o.optString("state");
				if (isActiveState(s)) { active++; bytes += Math.max(0, o.optLong("bytes", 0)); if (o.optLong("total", -1) > 0) total += o.optLong("total", 0); }
				else if ("done".equals(s)) done++;
				else if ("failed".equals(s)) failed++;
			}
		}
		try { return new JSONObject().put("active", active).put("done", done).put("failed", failed).put("bytes", bytes).put("total", total).toString(); } catch (Throwable e) { return "{}"; }
	}
}
