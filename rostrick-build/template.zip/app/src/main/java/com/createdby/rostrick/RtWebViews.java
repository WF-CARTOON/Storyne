package com.createdby.rostrick;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.ConsoleMessage;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.PermissionRequest;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.SslErrorHandler;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * WebView أصلي إضافي تتحكم به الصفحة بالكامل (متصفح داخل التطبيق، نوافذ ويب، تبويبات…).
 * - WebView حقيقي (وليس iframe): لا قيود CORS ولا X-Frame-Options، وله ملفات تعريف ارتباط وتخزين حقيقيان.
 * - يوضع في مستطيل تحدده الصفحة (بإحداثيات CSS نسبة لنافذة الصفحة)، وكل واحد له معرّف.
 * - لا تُحقن فيه جسور RosTrick أبدًا (محتوى غير موثوق)، والوصول للملفات معطّل.
 * - العناصر تعيش في طبقة مستقلة (RtStatusBar.layer) ولا تُضاف للحاوية الرئيسية.
 */
public final class RtWebViews {
	private static final int MAX = 10;
	private static final String FS = "fs";

	private final Activity act;
	private final WebView main;
	private final RtStatusBar sb;
	private WebChromeClient mainChrome;
	private DownloadListener mainDl;
	private final Handler ui = new Handler(Looper.getMainLooper());
	private final float density;
	private final LinkedHashMap<String, Item> items = new LinkedHashMap<String, Item>();
	private int seq = 0;
	private FrameLayout layer;
	private String page = "";

	private static final class Item {
		String id, owner = "", url = "", title = "";
		WebView w;
		View root;                       // العنصر المضاف للطبقة (الـ WebView نفسه أو واجهة ملء الشاشة)
		boolean persist, handleBack, intercept, fullscreen, canBack, canFwd, dlEvent, newEvent, destroyed;
		int progress;
		TextView titleTv;
		ProgressBar pb;
	}

	public RtWebViews(Activity a, WebView mainWeb, RtStatusBar statusBar) {
		act = a; main = mainWeb; sb = statusBar;
		density = a.getResources().getDisplayMetrics().density;
	}

	/** عملاء الـ WebView الرئيسي (رفع الملفات، الحوارات، الأذونات، التنزيل) تُفوَّض إليهم نوافذ الويب الإضافية. */
	public void setChrome(WebChromeClient c) { mainChrome = c; }
	public void setDownloads(DownloadListener d) { mainDl = d; }

	private int dp(float v) { return Math.round(v * density); }
	private FrameLayout layer() { if (layer == null) layer = RtStatusBar.layer(act); return layer; }

	// ===================== إرسال الأحداث للصفحة =====================
	private void emit(String id, String type, JSONObject d) {
		final String js = "window.__rtWV&&window.__rtWV(" + JSONObject.quote(id) + "," + JSONObject.quote(type) + "," + JSONObject.quote(d == null ? "{}" : d.toString()) + ")";
		ui.post(new Runnable() { @Override public void run() { try { main.evaluateJavascript(js, null); } catch (Throwable ignore) {} } });
	}
	private JSONObject st(Item it) {
		JSONObject o = new JSONObject();
		try { o.put("url", it.url); o.put("title", it.title); o.put("canGoBack", it.canBack); o.put("canGoForward", it.canFwd); o.put("progress", it.progress); } catch (Throwable ignore) {}
		return o;
	}
	private void sync(Item it) {
		try { it.url = it.w.getUrl() == null ? "" : it.w.getUrl(); it.canBack = it.w.canGoBack(); it.canFwd = it.w.canGoForward(); } catch (Throwable ignore) {}
	}

	private Item get(String id) { synchronized (items) { return items.get(id); } }
	private void onUi(Runnable r) { if (Looper.myLooper() == Looper.getMainLooper()) r.run(); else ui.post(r); }

	// ===================== إنشاء WebView =====================
	private WebView newWebView(final Item it, JSONObject o) {
		final WebView w = new WebView(act);
		WebSettings s = w.getSettings();
		s.setJavaScriptEnabled(o.optBoolean("javascript", true));
		s.setDomStorageEnabled(true);
		s.setAllowFileAccess(false);
		s.setAllowContentAccess(false);
		s.setAllowFileAccessFromFileURLs(false);
		s.setAllowUniversalAccessFromFileURLs(false);
		s.setSupportMultipleWindows(true);
		s.setJavaScriptCanOpenWindowsAutomatically(false);
		s.setBuiltInZoomControls(o.optBoolean("zoom", true));
		s.setDisplayZoomControls(false);
		s.setSupportZoom(o.optBoolean("zoom", true));
		s.setUseWideViewPort(true);
		s.setLoadWithOverviewMode(true);
		s.setMediaPlaybackRequiresUserGesture(o.optBoolean("mediaGesture", true));
		String ua = o.optString("userAgent", "");
		if (ua.length() > 0) s.setUserAgentString(ua);
		int tz = o.optInt("textZoom", 0);
		if (tz > 0) s.setTextZoom(tz);
		if (o.has("background")) { try { w.setBackgroundColor((int) o.optLong("background")); } catch (Throwable ignore) {} }
		try { CookieManager.getInstance().setAcceptThirdPartyCookies(w, o.optBoolean("thirdPartyCookies", true)); } catch (Throwable ignore) {}
		it.persist = o.optBoolean("persist", false);
		it.handleBack = o.optBoolean("handleBack", false);
		it.intercept = o.optBoolean("intercept", false);
		it.dlEvent = "event".equals(o.optString("download", "auto"));
		it.newEvent = "event".equals(o.optString("newWindow", "same"));
		if (o.optBoolean("desktop", false)) setDesktop(w, true);

		w.setWebViewClient(new WebViewClient() {
			@Override
			public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
				return handleUrl(it, r.getUrl().toString(), r.isForMainFrame());
			}
			@SuppressWarnings("deprecation")
			@Override
			public boolean shouldOverrideUrlLoading(WebView v, String url) { return handleUrl(it, url, true); }
			@Override
			public void onPageStarted(WebView v, String url, Bitmap f) {
				it.url = url == null ? "" : url; it.progress = 0; sync(it);
				if (it.pb != null) { it.pb.setProgress(0); it.pb.setVisibility(View.VISIBLE); }
				emit(it.id, "start", st(it));
			}
			@Override
			public void onPageFinished(WebView v, String url) {
				sync(it); it.title = v.getTitle() == null ? "" : v.getTitle(); it.progress = 100;
				if (it.pb != null) it.pb.setVisibility(View.GONE);
				if (it.titleTv != null) it.titleTv.setText(it.title.length() > 0 ? it.title : it.url);
				emit(it.id, "finish", st(it));
			}
			@Override
			public void doUpdateVisitedHistory(WebView v, String url, boolean isReload) {
				sync(it);
				JSONObject d = st(it);
				try { d.put("url", url == null ? "" : url); d.put("reload", isReload); } catch (Throwable ignore) {}
				emit(it.id, "url", d);
			}
			@SuppressWarnings("deprecation")
			@Override
			public void onReceivedError(WebView v, int code, String desc, String failingUrl) {
				if (Build.VERSION.SDK_INT >= 23) return; // على 23+ تُستدعى النسخة الأحدث
				JSONObject d = new JSONObject();
				try { d.put("code", code); d.put("description", desc); d.put("url", failingUrl); } catch (Throwable ignore) {}
				emit(it.id, "error", d);
			}
			@android.annotation.TargetApi(23)
			@Override
			public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
				if (!r.isForMainFrame()) return;
				JSONObject d = new JSONObject();
				try { d.put("code", e.getErrorCode()); d.put("description", String.valueOf(e.getDescription())); d.put("url", r.getUrl().toString()); } catch (Throwable ignore) {}
				emit(it.id, "error", d);
			}
			@android.annotation.TargetApi(23)
			@Override
			public void onReceivedHttpError(WebView v, WebResourceRequest r, WebResourceResponse resp) {
				if (!r.isForMainFrame()) return;
				JSONObject d = new JSONObject();
				try { d.put("status", resp.getStatusCode()); d.put("url", r.getUrl().toString()); } catch (Throwable ignore) {}
				emit(it.id, "httperror", d);
			}
			@Override
			public void onReceivedSslError(WebView v, SslErrorHandler h, SslError e) {
				h.cancel();
				JSONObject d = new JSONObject();
				try { d.put("code", -11); d.put("description", "SSL"); d.put("url", e.getUrl()); } catch (Throwable ignore) {}
				emit(it.id, "error", d);
			}
			@android.annotation.TargetApi(26)
			@Override
			public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail detail) {
				emit(it.id, "crash", st(it));
				final String id = it.id;
				ui.post(new Runnable() { @Override public void run() { destroyInternal(id); } });
				return true;
			}
		});

		w.setWebChromeClient(new WebChromeClient() {
			@Override
			public void onProgressChanged(WebView v, int p) {
				it.progress = p;
				if (it.pb != null) { it.pb.setProgress(p); it.pb.setVisibility(p >= 100 ? View.GONE : View.VISIBLE); }
				JSONObject d = new JSONObject();
				try { d.put("progress", p); } catch (Throwable ignore) {}
				emit(it.id, "progress", d);
			}
			@Override
			public void onReceivedTitle(WebView v, String t) {
				it.title = t == null ? "" : t;
				if (it.titleTv != null) it.titleTv.setText(it.title.length() > 0 ? it.title : it.url);
				JSONObject d = new JSONObject();
				try { d.put("title", it.title); } catch (Throwable ignore) {}
				emit(it.id, "title", d);
			}
			@Override
			public boolean onCreateWindow(WebView v, boolean isDialog, boolean isUserGesture, Message resultMsg) {
				final WebView tmp = new WebView(act);
				tmp.setWebViewClient(new WebViewClient() {
					@Override
					public boolean shouldOverrideUrlLoading(WebView v2, WebResourceRequest r) {
						String url = r.getUrl().toString();
						if (!"about".equals(r.getUrl().getScheme())) {
							if (it.newEvent) {
								JSONObject d = new JSONObject();
								try { d.put("url", url); } catch (Throwable ignore) {}
								emit(it.id, "newwindow", d);
							} else {
								final String u = url;
								ui.post(new Runnable() { @Override public void run() { if (!it.destroyed) it.w.loadUrl(u); } });
							}
							final WebView t2 = v2;
							ui.post(new Runnable() { @Override public void run() { try { t2.stopLoading(); t2.destroy(); } catch (Throwable ignore) {} } });
						}
						return true;
					}
				});
				WebView.WebViewTransport tr = (WebView.WebViewTransport) resultMsg.obj;
				tr.setWebView(tmp);
				resultMsg.sendToTarget();
				return true;
			}
			@Override
			public void onPermissionRequest(PermissionRequest r) { if (mainChrome != null) mainChrome.onPermissionRequest(r); else r.deny(); }
			@Override
			public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
				if (mainChrome != null) mainChrome.onGeolocationPermissionsShowPrompt(origin, cb); else cb.invoke(origin, false, false);
			}
			@Override
			public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
				return mainChrome != null && mainChrome.onShowFileChooser(v, cb, p);
			}
			@Override
			public boolean onJsAlert(WebView v, String url, String m, JsResult r) { return mainChrome != null && mainChrome.onJsAlert(v, url, m, r); }
			@Override
			public boolean onJsConfirm(WebView v, String url, String m, JsResult r) { return mainChrome != null && mainChrome.onJsConfirm(v, url, m, r); }
			@Override
			public boolean onJsPrompt(WebView v, String url, String m, String def, JsPromptResult r) { return mainChrome != null && mainChrome.onJsPrompt(v, url, m, def, r); }
			@Override
			public boolean onConsoleMessage(ConsoleMessage cm) { return true; }
		});

		w.setDownloadListener(new DownloadListener() {
			@Override
			public void onDownloadStart(String url, String ua2, String cd, String mime, long len) {
				JSONObject d = new JSONObject();
				try { d.put("url", url); d.put("mime", mime); d.put("size", len); d.put("disposition", cd); } catch (Throwable ignore) {}
				emit(it.id, "download", d);
				if (!it.dlEvent && mainDl != null) mainDl.onDownloadStart(url, ua2, cd, mime, len);
			}
		});
		w.setFindListener(new WebView.FindListener() {
			@Override
			public void onFindResultReceived(int active, int count, boolean done) {
				JSONObject d = new JSONObject();
				try { d.put("active", active); d.put("count", count); d.put("done", done); } catch (Throwable ignore) {}
				emit(it.id, "find", d);
			}
		});
		return w;
	}

	/** يقرر مصير رابط تنقّل: يُحمَّل داخل الـ WebView (http/https/about/data/blob)، أو يُفتح خارجيًا (tel:/mailto:/intent:…)، أو يُحجب (file/content). */
	private boolean handleUrl(Item it, String url, boolean mainFrame) {
		Uri u = Uri.parse(url);
		String sc = u.getScheme() == null ? "" : u.getScheme().toLowerCase();
		if ("http".equals(sc) || "https".equals(sc) || "about".equals(sc) || "data".equals(sc) || "blob".equals(sc) || "javascript".equals(sc)) {
			if (it.intercept && mainFrame && ("http".equals(sc) || "https".equals(sc))) {
				JSONObject d = new JSONObject();
				try { d.put("url", url); } catch (Throwable ignore) {}
				emit(it.id, "navigate", d);
				return true;
			}
			return false;
		}
		if ("file".equals(sc) || "content".equals(sc)) return true;
		try {
			Intent in = "intent".equals(sc) ? Intent.parseUri(url, Intent.URI_INTENT_SCHEME) : new Intent(Intent.ACTION_VIEW, u);
			if ("intent".equals(sc)) { in.addCategory(Intent.CATEGORY_BROWSABLE); in.setComponent(null); in.setSelector(null); }
			act.startActivity(in);
		} catch (Throwable ignore) {}
		JSONObject d = new JSONObject();
		try { d.put("url", url); } catch (Throwable ignore) {}
		emit(it.id, "external", d);
		return true;
	}

	private void setDesktop(WebView w, boolean on) {
		WebSettings s = w.getSettings();
		if (on) {
			s.setUserAgentString("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36");
			s.setUseWideViewPort(true); s.setLoadWithOverviewMode(true);
		} else {
			s.setUserAgentString(null);
		}
	}

	private void place(Item it, double x, double y, double wd, double ht) {
		if (it.root == null || it.fullscreen) return;
		int[] a = new int[2], b = new int[2];
		main.getLocationInWindow(a);
		layer().getLocationInWindow(b);
		FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(Math.max(1, (int) Math.round(wd * density)), Math.max(1, (int) Math.round(ht * density)));
		lp.leftMargin = a[0] - b[0] + (int) Math.round(x * density);
		lp.topMargin = a[1] - b[1] + (int) Math.round(y * density);
		lp.gravity = Gravity.TOP | Gravity.START;
		it.root.setLayoutParams(lp);
	}

	@JavascriptInterface
	public String create(String optsJson) {
		final JSONObject o;
		try { o = new JSONObject(optsJson); } catch (Throwable t) { return ""; }
		final Item it = new Item();
		synchronized (items) {
			String id = o.optString("id", "");
			if (id.length() == 0) id = "wv" + (++seq);
			if (items.containsKey(id) || FS.equals(id) || items.size() >= MAX) return "";
			it.id = id; items.put(id, it);
		}
		it.owner = o.optString("owner", "");
		ui.post(new Runnable() {
			@Override public void run() {
				try {
					it.w = newWebView(it, o);
					it.root = it.w;
					layer().addView(it.root);
					JSONObject b = o.optJSONObject("bounds");
					if (b != null) place(it, b.optDouble("x"), b.optDouble("y"), b.optDouble("w"), b.optDouble("h"));
					else it.root.setLayoutParams(new FrameLayout.LayoutParams(1, 1));
					if (!o.optBoolean("visible", true)) it.root.setVisibility(View.INVISIBLE);
					String url = o.optString("url", "");
					if (url.length() > 0) it.w.loadUrl(url);
					emit(it.id, "created", st(it));
				} catch (Throwable t) { t.printStackTrace(); synchronized (items) { items.remove(it.id); } }
			}
		});
		return it.id;
	}

	@JavascriptInterface
	public boolean setBounds(final String id, final double x, final double y, final double w, final double h) {
		final Item it = get(id); if (it == null) return false;
		onUi(new Runnable() { @Override public void run() { place(it, x, y, w, h); } });
		return true;
	}
	@JavascriptInterface
	public boolean setVisible(final String id, final boolean v) {
		final Item it = get(id); if (it == null) return false;
		onUi(new Runnable() { @Override public void run() { if (it.root != null) it.root.setVisibility(v ? View.VISIBLE : View.INVISIBLE); } });
		return true;
	}
	@JavascriptInterface
	public boolean bringToFront(final String id) {
		final Item it = get(id); if (it == null) return false;
		onUi(new Runnable() { @Override public void run() { if (it.root != null) it.root.bringToFront(); } });
		return true;
	}
	@JavascriptInterface
	public boolean load(final String id, final String url, final String headersJson) {
		final Item it = get(id); if (it == null) return false;
		onUi(new Runnable() {
			@Override public void run() {
				if (it.w == null) return;
				if (headersJson != null && headersJson.length() > 2) {
					try {
						JSONObject h = new JSONObject(headersJson);
						Map<String, String> m = new LinkedHashMap<String, String>();
						JSONArray ks = h.names();
						for (int i = 0; ks != null && i < ks.length(); i++) m.put(ks.getString(i), h.optString(ks.getString(i)));
						it.w.loadUrl(url, m);
						return;
					} catch (Throwable ignore) {}
				}
				it.w.loadUrl(url);
			}
		});
		return true;
	}
	@JavascriptInterface
	public boolean loadHtml(final String id, final String html, final String base) {
		final Item it = get(id); if (it == null) return false;
		onUi(new Runnable() {
			@Override public void run() {
				if (it.w == null) return;
				it.w.loadDataWithBaseURL(base != null && base.length() > 0 ? base : null, html, "text/html", "UTF-8", null);
			}
		});
		return true;
	}
	@JavascriptInterface
	public boolean reload(final String id) { final Item it = get(id); if (it == null) return false; onUi(new Runnable() { @Override public void run() { if (it.w != null) it.w.reload(); } }); return true; }
	@JavascriptInterface
	public boolean stop(final String id) { final Item it = get(id); if (it == null) return false; onUi(new Runnable() { @Override public void run() { if (it.w != null) it.w.stopLoading(); } }); return true; }
	@JavascriptInterface
	public boolean back(final String id) { final Item it = get(id); if (it == null) return false; onUi(new Runnable() { @Override public void run() { if (it.w != null && it.w.canGoBack()) it.w.goBack(); } }); return true; }
	@JavascriptInterface
	public boolean forward(final String id) { final Item it = get(id); if (it == null) return false; onUi(new Runnable() { @Override public void run() { if (it.w != null && it.w.canGoForward()) it.w.goForward(); } }); return true; }

	@JavascriptInterface
	public boolean evaluate(final String id, final String code, final int cb) {
		final Item it = get(id); if (it == null) return false;
		onUi(new Runnable() {
			@Override public void run() {
				if (it.w == null) return;
				it.w.evaluateJavascript(code, new ValueCallback<String>() {
					@Override public void onReceiveValue(String v) {
						JSONObject d = new JSONObject();
						try { d.put("cb", cb); d.put("value", v == null ? "null" : v); } catch (Throwable ignore) {}
						emit(id, "eval", d);
					}
				});
			}
		});
		return true;
	}
	@JavascriptInterface
	public boolean setUserAgent(final String id, final String ua) {
		final Item it = get(id); if (it == null) return false;
		onUi(new Runnable() { @Override public void run() { if (it.w != null) it.w.getSettings().setUserAgentString(ua != null && ua.length() > 0 ? ua : null); } });
		return true;
	}
	@JavascriptInterface
	public boolean setDesktopMode(final String id, final boolean on) {
		final Item it = get(id); if (it == null) return false;
		onUi(new Runnable() { @Override public void run() { if (it.w != null) { setDesktop(it.w, on); it.w.reload(); } } });
		return true;
	}
	@JavascriptInterface
	public boolean setTextZoom(final String id, final int pct) {
		final Item it = get(id); if (it == null) return false;
		onUi(new Runnable() { @Override public void run() { if (it.w != null && pct > 0) it.w.getSettings().setTextZoom(pct); } });
		return true;
	}
	@JavascriptInterface
	public boolean setJavaScript(final String id, final boolean on) {
		final Item it = get(id); if (it == null) return false;
		onUi(new Runnable() { @Override public void run() { if (it.w != null) it.w.getSettings().setJavaScriptEnabled(on); } });
		return true;
	}
	@JavascriptInterface
	public boolean find(final String id, final String q) { final Item it = get(id); if (it == null) return false; onUi(new Runnable() { @Override public void run() { if (it.w != null) it.w.findAllAsync(q); } }); return true; }
	@JavascriptInterface
	public boolean findNext(final String id, final boolean fwd) { final Item it = get(id); if (it == null) return false; onUi(new Runnable() { @Override public void run() { if (it.w != null) it.w.findNext(fwd); } }); return true; }
	@JavascriptInterface
	public boolean clearFind(final String id) { final Item it = get(id); if (it == null) return false; onUi(new Runnable() { @Override public void run() { if (it.w != null) it.w.clearMatches(); } }); return true; }
	@JavascriptInterface
	public boolean clearCache(final String id) { final Item it = get(id); if (it == null) return false; onUi(new Runnable() { @Override public void run() { if (it.w != null) it.w.clearCache(true); } }); return true; }
	@JavascriptInterface
	public boolean clearHistory(final String id) { final Item it = get(id); if (it == null) return false; onUi(new Runnable() { @Override public void run() { if (it.w != null) it.w.clearHistory(); sync(it); } }); return true; }
	@JavascriptInterface
	public boolean clearCookies() {
		onUi(new Runnable() { @Override public void run() { try { CookieManager.getInstance().removeAllCookies(null); CookieManager.getInstance().flush(); } catch (Throwable ignore) {} } });
		return true;
	}

	@JavascriptInterface
	public String list() {
		JSONArray a = new JSONArray();
		synchronized (items) {
			for (Item it : items.values()) {
				try { JSONObject o = st(it); o.put("id", it.id); o.put("fullscreen", it.fullscreen); a.put(o); } catch (Throwable ignore) {}
			}
		}
		return a.toString();
	}

	@JavascriptInterface
	public boolean destroy(final String id) {
		if (get(id) == null) return false;
		onUi(new Runnable() { @Override public void run() { destroyInternal(id); } });
		return true;
	}
	private void destroyInternal(String id) {
		Item it;
		synchronized (items) { it = items.remove(id); }
		if (it == null || it.destroyed) return;
		it.destroyed = true;
		try { if (it.root != null && it.root.getParent() instanceof ViewGroup) ((ViewGroup) it.root.getParent()).removeView(it.root); } catch (Throwable ignore) {}
		final WebView w = it.w;
		if (w != null) {
			ui.post(new Runnable() { @Override public void run() { try { w.stopLoading(); w.loadUrl("about:blank"); w.clearHistory(); w.removeAllViews(); w.destroy(); } catch (Throwable ignore) {} } });
		}
		JSONObject d = new JSONObject();
		emit(id, "destroyed", d);
	}

	/** تُستدعى عند تحميل كل صفحة رئيسية: يُغلق ما أنشأته الصفحة السابقة ولم يُطلب بقاؤه (persist). */
	@JavascriptInterface
	public void pageStart(final String pageId) {
		onUi(new Runnable() {
			@Override public void run() {
				page = pageId == null ? "" : pageId;
				ArrayList<String> kill = new ArrayList<String>();
				synchronized (items) { for (Item it : items.values()) if (!it.persist && !page.equals(it.owner)) kill.add(it.id); }
				for (String id : kill) destroyInternal(id);
			}
		});
	}

	// ===================== ملء الشاشة (شريط جاهز) =====================
	private TextView btn(String glyph, View.OnClickListener l, int fg) {
		TextView t = new TextView(act);
		t.setText(glyph); t.setTextColor(fg); t.setTextSize(20); t.setGravity(Gravity.CENTER);
		t.setLayoutParams(new LinearLayout.LayoutParams(dp(46), ViewGroup.LayoutParams.MATCH_PARENT));
		t.setOnClickListener(l);
		return t;
	}

	@JavascriptInterface
	public String openFullscreen(final String url, final String optsJson) {
		JSONObject o0;
		try { o0 = new JSONObject(optsJson == null || optsJson.length() == 0 ? "{}" : optsJson); } catch (Throwable t) { o0 = new JSONObject(); }
		final JSONObject o = o0;
		synchronized (items) {
			Item ex = items.get(FS);
			if (ex != null) { final Item e2 = ex; onUi(new Runnable() { @Override public void run() { if (e2.w != null) e2.w.loadUrl(url); } }); return FS; }
		}
		final Item it = new Item();
		it.id = FS; it.fullscreen = true; it.owner = o.optString("owner", "");
		synchronized (items) { items.put(FS, it); }
		ui.post(new Runnable() {
			@Override public void run() {
				try {
					final int barBg = o.has("barColor") ? (int) o.optLong("barColor") : 0xFF1B2229;
					final int fg = o.has("textColor") ? (int) o.optLong("textColor") : 0xFFFFFFFF;
					LinearLayout root = new LinearLayout(act);
					root.setOrientation(LinearLayout.VERTICAL);
					root.setBackgroundColor(0xFFFFFFFF);
					root.setClickable(true);
					root.setPadding(sb.leftInset(), 0, sb.rightInset(), sb.bottomInset());
					LinearLayout bar = new LinearLayout(act);
					bar.setOrientation(LinearLayout.HORIZONTAL);
					bar.setBackgroundColor(barBg);
					bar.setPadding(0, sb.topInset(), 0, 0);
					LinearLayout row = new LinearLayout(act);
					row.setOrientation(LinearLayout.HORIZONTAL);
					row.setGravity(Gravity.CENTER_VERTICAL);
					it.w = newWebView(it, o);
					row.addView(btn("✕", new View.OnClickListener() { @Override public void onClick(View v) { destroyInternal(FS); } }, fg));
					row.addView(btn("◀", new View.OnClickListener() { @Override public void onClick(View v) { if (it.w.canGoBack()) it.w.goBack(); } }, fg));
					row.addView(btn("▶", new View.OnClickListener() { @Override public void onClick(View v) { if (it.w.canGoForward()) it.w.goForward(); } }, fg));
					TextView tt = new TextView(act);
					tt.setTextColor(fg); tt.setTextSize(14); tt.setSingleLine(true); tt.setEllipsize(android.text.TextUtils.TruncateAt.END);
					tt.setPadding(dp(8), 0, dp(8), 0);
					tt.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
					row.addView(tt);
					row.addView(btn("⟳", new View.OnClickListener() { @Override public void onClick(View v) { it.w.reload(); } }, fg));
					bar.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));
					root.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
					ProgressBar pb = new ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal);
					pb.setMax(100);
					root.addView(pb, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(3)));
					root.addView(it.w, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
					it.titleTv = tt; it.pb = pb; it.root = root;
					layer().addView(root, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
					it.w.loadUrl(url);
					emit(FS, "created", st(it));
				} catch (Throwable t) { t.printStackTrace(); synchronized (items) { items.remove(FS); } }
			}
		});
		return FS;
	}
	@JavascriptInterface
	public boolean closeFullscreen() {
		if (get(FS) == null) return false;
		onUi(new Runnable() { @Override public void run() { destroyInternal(FS); } });
		return true;
	}

	// ===================== دورة حياة النشاط =====================
	/** زر الرجوع: يُستهلك إن كانت هناك نافذة ملء شاشة أو WebView يطلب handleBack وفيه سجل. */
	public boolean onBackPressed() {
		Item fsItem = get(FS);
		if (fsItem != null && fsItem.w != null) {
			if (fsItem.w.canGoBack()) fsItem.w.goBack(); else destroyInternal(FS);
			return true;
		}
		ArrayList<Item> all;
		synchronized (items) { all = new ArrayList<Item>(items.values()); }
		for (int i = all.size() - 1; i >= 0; i--) {
			Item it = all.get(i);
			if (it.handleBack && it.w != null && it.root != null && it.root.getVisibility() == View.VISIBLE && it.w.canGoBack()) { it.w.goBack(); return true; }
		}
		return false;
	}
	public void onPause() { synchronized (items) { for (Item it : items.values()) { try { if (it.w != null) it.w.onPause(); } catch (Throwable ignore) {} } } }
	public void onResume() { synchronized (items) { for (Item it : items.values()) { try { if (it.w != null) it.w.onResume(); } catch (Throwable ignore) {} } } }
	public void onDestroy() {
		ArrayList<String> ids;
		synchronized (items) { ids = new ArrayList<String>(items.keySet()); }
		for (String id : ids) destroyInternal(id);
	}
}
