package com.createdby.rostrick;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.Vibrator;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.HapticFeedbackConstants;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONObject;

import java.util.Locale;

/**
 * RosTrick: جسر الجهاز — window.RosTrickDevice (يعمل دائماً، بلا أذونات خطرة ولا إعداد).
 *  - السطوع: سطوع نافذة التطبيق فقط (لا يغيّر إعداد النظام ولا يحتاج WRITE_SETTINGS) + قراءة سطوع النظام.
 *  - الصوت: قراءة/ضبط مستوى أي قناة (وسائط/رنين/منبّه/إشعارات/نظام/مكالمة) + كتم + وضع الرنين + مراقبة التغيير.
 *  - كشاف الفلاش، اهتزاز لمسي (haptic)، اتجاه الشاشة، منع لقطات الشاشة (FLAG_SECURE)، حالة الشبكة، معلومات الجهاز.
 * الأحداث تصل للصفحة عبر window.__rtDev(type, json) (انظر assets/rt-native.js).
 */
public final class RtDevice {
	private final Activity act;
	private final WebView web;
	private final Handler ui = new Handler(Looper.getMainLooper());

	private BroadcastReceiver volRx = null;
	private CameraManager camMgr = null;
	private Object torchCb = null;
	private String torchId = null;
	private boolean torchOn = false;
	private ConnectivityManager.NetworkCallback netCb = null;
	private boolean secure = false;
	private final Runnable netEmit = new Runnable() { @Override public void run() { emit("network", networkObj()); } };

	public RtDevice(Activity activity, WebView webView) {
		this.act = activity;
		this.web = webView;
	}

	// ---------- مساعدات ----------
	private AudioManager am() { return (AudioManager) act.getSystemService(Context.AUDIO_SERVICE); }

	private void emit(final String type, final JSONObject data) {
		final String json = data == null ? "{}" : data.toString();
		act.runOnUiThread(new Runnable() {
			@Override public void run() {
				try { web.evaluateJavascript("window.__rtDev&&window.__rtDev(" + JSONObject.quote(type) + "," + JSONObject.quote(json) + ")", null); } catch (Throwable ignore) {}
			}
		});
	}

	private static int streamOf(String s) {
		String k = s == null ? "music" : s.toLowerCase(Locale.ROOT);
		if (k.equals("ring") || k.equals("ringtone")) return AudioManager.STREAM_RING;
		if (k.equals("alarm")) return AudioManager.STREAM_ALARM;
		if (k.equals("notification")) return AudioManager.STREAM_NOTIFICATION;
		if (k.equals("system")) return AudioManager.STREAM_SYSTEM;
		if (k.equals("call") || k.equals("voice") || k.equals("voice_call")) return AudioManager.STREAM_VOICE_CALL;
		return AudioManager.STREAM_MUSIC;
	}

	private static String nameOf(int stream) {
		switch (stream) {
			case AudioManager.STREAM_RING: return "ring";
			case AudioManager.STREAM_ALARM: return "alarm";
			case AudioManager.STREAM_NOTIFICATION: return "notification";
			case AudioManager.STREAM_SYSTEM: return "system";
			case AudioManager.STREAM_VOICE_CALL: return "call";
			case AudioManager.STREAM_MUSIC: return "music";
			default: return "stream" + stream;
		}
	}

	private JSONObject volumeObj(int stream) {
		JSONObject o = new JSONObject();
		try {
			AudioManager a = am();
			int lvl = a.getStreamVolume(stream), max = a.getStreamMaxVolume(stream);
			int min = Build.VERSION.SDK_INT >= 28 ? a.getStreamMinVolume(stream) : 0;
			boolean muted = Build.VERSION.SDK_INT >= 23 ? a.isStreamMute(stream) : lvl == 0;
			o.put("stream", nameOf(stream)); o.put("level", lvl); o.put("min", min); o.put("max", max);
			o.put("percent", max > min ? (lvl - min) / (double) (max - min) : 0);
			o.put("muted", muted);
		} catch (Throwable ignore) {}
		return o;
	}

	// ---------- معلومات الجهاز ----------
	@JavascriptInterface
	public String info() {
		JSONObject o = new JSONObject();
		try {
			o.put("model", Build.MODEL); o.put("manufacturer", Build.MANUFACTURER); o.put("brand", Build.BRAND);
			o.put("sdk", Build.VERSION.SDK_INT); o.put("release", Build.VERSION.RELEASE);
			o.put("locale", Locale.getDefault().toString());
			DisplayMetrics dm = act.getResources().getDisplayMetrics();
			o.put("widthPx", dm.widthPixels); o.put("heightPx", dm.heightPixels); o.put("density", dm.density);
			Configuration cfg = act.getResources().getConfiguration();
			o.put("tablet", cfg.smallestScreenWidthDp >= 600);
			o.put("darkMode", (cfg.uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES);
			o.put("orientation", cfg.orientation == Configuration.ORIENTATION_LANDSCAPE ? "landscape" : "portrait");
			PackageManager pm = act.getPackageManager();
			o.put("hasFlash", pm.hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH));
			Vibrator v = (Vibrator) act.getSystemService(Context.VIBRATOR_SERVICE);
			o.put("hasVibrator", v != null && v.hasVibrator());
			try {
				ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
				((ActivityManager) act.getSystemService(Context.ACTIVITY_SERVICE)).getMemoryInfo(mi);
				o.put("ramMB", mi.totalMem / (1024 * 1024));
			} catch (Throwable ignore) {}
			o.put("package", act.getPackageName());
		} catch (Throwable ignore) {}
		return o.toString();
	}

	// ---------- السطوع ----------
	/** {window: -1..1 (-1 = يتبع النظام)، system: 0..1، auto: سطوع النظام تلقائي؟، current: القيمة الفعلية التقريبية}. */
	@JavascriptInterface
	public String brightnessGet() {
		JSONObject o = new JSONObject();
		try {
			float w = act.getWindow().getAttributes().screenBrightness;
			double sys = -1; boolean auto = false;
			try {
				sys = Settings.System.getInt(act.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS) / 255.0;
				auto = Settings.System.getInt(act.getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE) == Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC;
			} catch (Throwable ignore) {}
			o.put("window", w < 0 ? -1 : w); o.put("system", sys); o.put("auto", auto);
			o.put("current", w >= 0 ? w : sys);
		} catch (Throwable ignore) {}
		return o.toString();
	}

	/** v بين 0 و1 يضبط سطوع نافذة التطبيق فقط؛ قيمة سالبة تعيده لسطوع النظام. */
	@JavascriptInterface
	public boolean brightnessSet(final double v) {
		act.runOnUiThread(new Runnable() {
			@Override public void run() {
				try {
					Window w = act.getWindow();
					WindowManager.LayoutParams lp = w.getAttributes();
					lp.screenBrightness = v < 0 ? WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE : (float) Math.max(0.01, Math.min(1.0, v));
					w.setAttributes(lp);
				} catch (Throwable ignore) {}
			}
		});
		return true;
	}

	// ---------- الصوت ----------
	@JavascriptInterface
	public String volumeGet(String stream) { return volumeObj(streamOf(stream)).toString(); }

	/** frac بين 0 و1 (نسبة من أعلى مستوى للقناة). */
	@JavascriptInterface
	public boolean volumeSet(String stream, double frac) {
		try {
			int s = streamOf(stream);
			AudioManager a = am();
			int min = Build.VERSION.SDK_INT >= 28 ? a.getStreamMinVolume(s) : 0, max = a.getStreamMaxVolume(s);
			int lvl = min + (int) Math.round(Math.max(0, Math.min(1, frac)) * (max - min));
			a.setStreamVolume(s, lvl, 0);
			return true;
		} catch (Throwable e) { return false; } // مثلاً قناة الرنين أثناء وضع «عدم الإزعاج» تحتاج إذن النظام
	}

	/** مستوى رقمي مباشر. */
	@JavascriptInterface
	public boolean volumeSetLevel(String stream, int level) {
		try { am().setStreamVolume(streamOf(stream), level, 0); return true; } catch (Throwable e) { return false; }
	}

	/** dir: up | down | mute | unmute | toggle ؛ showUi يعرض شريط الصوت الخاص بالنظام. */
	@JavascriptInterface
	public boolean volumeAdjust(String stream, String dir, boolean showUi) {
		try {
			int s = streamOf(stream), flags = showUi ? AudioManager.FLAG_SHOW_UI : 0;
			String d = dir == null ? "" : dir.toLowerCase(Locale.ROOT);
			int a;
			if (d.equals("up") || d.equals("raise")) a = AudioManager.ADJUST_RAISE;
			else if (d.equals("down") || d.equals("lower")) a = AudioManager.ADJUST_LOWER;
			else if (Build.VERSION.SDK_INT >= 23 && d.equals("mute")) a = AudioManager.ADJUST_MUTE;
			else if (Build.VERSION.SDK_INT >= 23 && d.equals("unmute")) a = AudioManager.ADJUST_UNMUTE;
			else if (Build.VERSION.SDK_INT >= 23 && d.equals("toggle")) a = AudioManager.ADJUST_TOGGLE_MUTE;
			else return false;
			am().adjustStreamVolume(s, a, flags);
			return true;
		} catch (Throwable e) { return false; }
	}

	/** أي قناة تتحكم بها أزرار الصوت الفعلية للجهاز داخل التطبيق؛ "auto" يعيد السلوك الافتراضي. */
	@JavascriptInterface
	public boolean volumeKeys(final String stream) {
		act.runOnUiThread(new Runnable() {
			@Override public void run() {
				try { act.setVolumeControlStream("auto".equals(stream) ? AudioManager.USE_DEFAULT_STREAM_TYPE : streamOf(stream)); } catch (Throwable ignore) {}
			}
		});
		return true;
	}

	/** normal | vibrate | silent */
	@JavascriptInterface
	public String ringerMode() {
		try {
			int m = am().getRingerMode();
			return m == AudioManager.RINGER_MODE_SILENT ? "silent" : m == AudioManager.RINGER_MODE_VIBRATE ? "vibrate" : "normal";
		} catch (Throwable e) { return "normal"; }
	}

	/** التحويل إلى silent قد يتطلب صلاحية «عدم الإزعاج» من المستخدم، فيرجع false عند الرفض. */
	@JavascriptInterface
	public boolean setRingerMode(String mode) {
		try {
			String m = mode == null ? "" : mode.toLowerCase(Locale.ROOT);
			int r = m.equals("silent") ? AudioManager.RINGER_MODE_SILENT : m.equals("vibrate") ? AudioManager.RINGER_MODE_VIBRATE : AudioManager.RINGER_MODE_NORMAL;
			am().setRingerMode(r);
			return am().getRingerMode() == r;
		} catch (Throwable e) { return false; }
	}

	// ---------- الكشاف ----------
	private synchronized String torchCameraId() {
		if (torchId != null) return torchId.length() == 0 ? null : torchId;
		try {
			if (camMgr == null) camMgr = (CameraManager) act.getSystemService(Context.CAMERA_SERVICE);
			String best = null;
			for (String id : camMgr.getCameraIdList()) {
				CameraCharacteristics cc = camMgr.getCameraCharacteristics(id);
				Boolean flash = cc.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
				if (flash != null && flash) {
					Integer facing = cc.get(CameraCharacteristics.LENS_FACING);
					if (best == null || (facing != null && facing == CameraCharacteristics.LENS_FACING_BACK)) best = id;
				}
			}
			torchId = best == null ? "" : best;
			return best;
		} catch (Throwable e) { torchId = ""; return null; }
	}

	@JavascriptInterface
	public boolean torchAvailable() { return Build.VERSION.SDK_INT >= 23 && torchCameraId() != null; }

	@JavascriptInterface
	public boolean torchGet() {
		if (torchCb == null) act.runOnUiThread(new Runnable() { @Override public void run() { if (torchCb == null) startTorchWatch(); } }); // الحالة الحيّة تصل من مستمع النظام
		return torchOn;
	}

	@JavascriptInterface
	public boolean torchSet(boolean on) {
		if (Build.VERSION.SDK_INT < 23) return false;
		try {
			String id = torchCameraId();
			if (id == null) return false;
			camMgr.setTorchMode(id, on);
			torchOn = on;
			if (torchCb == null) act.runOnUiThread(new Runnable() { @Override public void run() { if (torchCb == null) startTorchWatch(); } });
			return true;
		} catch (CameraAccessException e) { return false; }
		catch (Throwable e) { return false; }
	}

	// ---------- الاهتزاز اللمسي ----------
	/** kind: tick | click | long | confirm | reject */
	@JavascriptInterface
	public boolean haptic(final String kind) {
		act.runOnUiThread(new Runnable() {
			@Override public void run() {
				try {
					String k = kind == null ? "click" : kind.toLowerCase(Locale.ROOT);
					int c;
					if (k.equals("tick")) c = HapticFeedbackConstants.CLOCK_TICK;
					else if (k.equals("long")) c = HapticFeedbackConstants.LONG_PRESS;
					else if (k.equals("confirm")) c = Build.VERSION.SDK_INT >= 30 ? HapticFeedbackConstants.CONFIRM : HapticFeedbackConstants.KEYBOARD_TAP;
					else if (k.equals("reject")) c = Build.VERSION.SDK_INT >= 30 ? HapticFeedbackConstants.REJECT : HapticFeedbackConstants.LONG_PRESS;
					else c = Build.VERSION.SDK_INT >= 23 ? HapticFeedbackConstants.CONTEXT_CLICK : HapticFeedbackConstants.KEYBOARD_TAP;
					act.getWindow().getDecorView().performHapticFeedback(c);
				} catch (Throwable ignore) {}
			}
		});
		return true;
	}

	// ---------- اتجاه الشاشة ----------
	/** portrait | landscape | auto (تدوير حر) | lock (تثبيت الاتجاه الحالي) | unlock (الافتراضي). يستمر حتى تحمّل صفحة جديدة تعرّف <meta name="rostrick-orientation">. */
	@JavascriptInterface
	public boolean orientationSet(final String mode) {
		act.runOnUiThread(new Runnable() {
			@Override public void run() {
				try {
					String m = mode == null ? "" : mode.toLowerCase(Locale.ROOT);
					int o;
					if (m.equals("portrait")) o = ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT;
					else if (m.equals("landscape")) o = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE;
					else if (m.equals("auto") || m.equals("both")) o = ActivityInfo.SCREEN_ORIENTATION_FULL_USER;
					else if (m.equals("lock")) o = ActivityInfo.SCREEN_ORIENTATION_LOCKED;
					else o = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED;
					act.setRequestedOrientation(o);
				} catch (Throwable ignore) {}
			}
		});
		return true;
	}

	@JavascriptInterface
	public String orientationGet() {
		return act.getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE ? "landscape" : "portrait";
	}

	// ---------- منع لقطات الشاشة ----------
	@JavascriptInterface
	public boolean secureSet(final boolean on) {
		secure = on;
		act.runOnUiThread(new Runnable() {
			@Override public void run() {
				try {
					if (on) act.getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
					else act.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
				} catch (Throwable ignore) {}
			}
		});
		return true;
	}

	@JavascriptInterface
	public boolean secureGet() { return secure; }

	// ---------- الشبكة ----------
	private JSONObject networkObj() {
		JSONObject o = new JSONObject();
		try {
			ConnectivityManager cm = (ConnectivityManager) act.getSystemService(Context.CONNECTIVITY_SERVICE);
			boolean online = false; String type = "none";
			if (Build.VERSION.SDK_INT >= 23) {
				Network n = cm.getActiveNetwork();
				NetworkCapabilities nc = n == null ? null : cm.getNetworkCapabilities(n);
				if (nc != null) {
					online = nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
					type = nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ? "wifi"
						: nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ? "cellular"
						: nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) ? "ethernet"
						: nc.hasTransport(NetworkCapabilities.TRANSPORT_VPN) ? "vpn" : "other";
				}
			} else {
				NetworkInfo ni = cm.getActiveNetworkInfo();
				if (ni != null && ni.isConnected()) {
					online = true;
					type = ni.getType() == ConnectivityManager.TYPE_WIFI ? "wifi" : ni.getType() == ConnectivityManager.TYPE_MOBILE ? "cellular" : "other";
				}
			}
			o.put("online", online); o.put("type", online ? type : "none"); o.put("metered", cm.isActiveNetworkMetered());
		} catch (Throwable ignore) {}
		return o;
	}

	@JavascriptInterface
	public String networkGet() { return networkObj().toString(); }

	// ---------- مراقبة التغييرات (تبدأ عند أول اشتراك من الصفحة) ----------
	/** types: قائمة مفصولة بفواصل من volume,ringer,torch,network — تبدأ المراقبة لكل نوع مرة واحدة. */
	@JavascriptInterface
	public void watch(final String types) {
		final String t = types == null ? "" : types;
		act.runOnUiThread(new Runnable() {
			@Override public void run() {
				if ((t.contains("volume") || t.contains("ringer")) && volRx == null) startVolumeWatch();
				if (t.contains("torch") && torchCb == null) startTorchWatch();
				if (t.contains("network") && netCb == null) startNetWatch();
			}
		});
	}

	private void startVolumeWatch() {
		try {
			volRx = new BroadcastReceiver() {
				@Override public void onReceive(Context c, Intent i) {
					try {
						String a = i.getAction();
						if ("android.media.VOLUME_CHANGED_ACTION".equals(a)) {
							int s = i.getIntExtra("android.media.EXTRA_VOLUME_STREAM_TYPE", -1);
							if (s >= 0) emit("volume", volumeObj(s));
						} else if (AudioManager.RINGER_MODE_CHANGED_ACTION.equals(a)) {
							emit("ringer", new JSONObject().put("mode", ringerMode()));
						}
					} catch (Throwable ignore) {}
				}
			};
			IntentFilter f = new IntentFilter();
			f.addAction("android.media.VOLUME_CHANGED_ACTION");
			f.addAction(AudioManager.RINGER_MODE_CHANGED_ACTION);
			if (Build.VERSION.SDK_INT >= 33) act.registerReceiver(volRx, f, Context.RECEIVER_NOT_EXPORTED);
			else act.registerReceiver(volRx, f);
		} catch (Throwable e) { volRx = null; }
	}

	private void startTorchWatch() {
		if (Build.VERSION.SDK_INT < 23) return;
		try {
			if (camMgr == null) camMgr = (CameraManager) act.getSystemService(Context.CAMERA_SERVICE);
			final CameraManager.TorchCallback cb = new CameraManager.TorchCallback() {
				@Override public void onTorchModeChanged(String id, boolean enabled) {
					if (torchId != null && torchId.length() > 0 && !torchId.equals(id)) return;
					torchOn = enabled;
					try { emit("torch", new JSONObject().put("on", enabled)); } catch (Throwable ignore) {}
				}
			};
			torchCb = cb;
			camMgr.registerTorchCallback(cb, ui);
		} catch (Throwable e) { torchCb = null; }
	}

	private void startNetWatch() {
		if (Build.VERSION.SDK_INT < 24) return;
		try {
			ConnectivityManager cm = (ConnectivityManager) act.getSystemService(Context.CONNECTIVITY_SERVICE);
			netCb = new ConnectivityManager.NetworkCallback() {
				private void kick() { ui.removeCallbacks(netEmit); ui.postDelayed(netEmit, 300); }
				@Override public void onAvailable(Network n) { kick(); }
				@Override public void onLost(Network n) { kick(); }
				@Override public void onCapabilitiesChanged(Network n, NetworkCapabilities c) { kick(); }
			};
			cm.registerDefaultNetworkCallback(netCb);
		} catch (Throwable e) { netCb = null; }
	}

	public void onDestroy() {
		try { if (volRx != null) act.unregisterReceiver(volRx); } catch (Throwable ignore) {}
		volRx = null;
		try { if (torchCb != null && camMgr != null && Build.VERSION.SDK_INT >= 23) camMgr.unregisterTorchCallback((CameraManager.TorchCallback) torchCb); } catch (Throwable ignore) {}
		torchCb = null;
		try {
			if (netCb != null && Build.VERSION.SDK_INT >= 21) ((ConnectivityManager) act.getSystemService(Context.CONNECTIVITY_SERVICE)).unregisterNetworkCallback(netCb);
		} catch (Throwable ignore) {}
		netCb = null;
		ui.removeCallbacks(netEmit);
	}
}
