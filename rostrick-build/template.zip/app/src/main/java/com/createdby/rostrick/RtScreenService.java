package com.createdby.rostrick;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

/**
 * RosTrick: خدمة أمامية لالتقاط الشاشة وتسجيلها (نوع mediaProjection).
 * تُضاف للـ Manifest فقط إذا اختار صاحب التطبيق الإذن screen_capture في إعدادات البناء.
 * Android 10+ يشترط أن تعمل خدمة أمامية بهذا النوع قبل الحصول على MediaProjection، لذلك تُنشأ الجلسة هنا.
 */
public class RtScreenService extends Service {
	static final String ACTION_START = "com.createdby.rostrick.screen.START";
	static final String ACTION_STOP = "com.createdby.rostrick.screen.STOP";
	static final String CHANNEL = "rt_screen";
	static final int NOTIF_ID = 74110;

	@Override public IBinder onBind(Intent i) { return null; }

	@Override public int onStartCommand(Intent intent, int flags, int startId) {
		String act = intent == null ? null : intent.getAction();
		if (intent == null || ACTION_STOP.equals(act)) {
			try { RtScreen.stopSession(true); } catch (Throwable ignore) {}
			stopSelf();
			return START_NOT_STICKY;
		}
		try {
			startAsForeground();
		} catch (Throwable t) {
			RtScreen.failAttach("foreground_failed");
			stopSelf();
			return START_NOT_STICKY;
		}
		final int code = intent.getIntExtra("code", 0);
		final Intent data = intent.getParcelableExtra("data");
		try {
			RtScreen.attach(this, code, data);
		} catch (Throwable t) {
			RtScreen.failAttach(String.valueOf(t.getMessage()));
			stopSelf();
		}
		return START_NOT_STICKY;
	}

	private void startAsForeground() {
		RtBackground.ensureChannel(this, CHANNEL, RtI18n.t("التقاط الشاشة", "Screen capture"), NotificationManager.IMPORTANCE_LOW);
		Notification.Builder b = (Build.VERSION.SDK_INT >= 26) ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
		int icon = getApplicationInfo().icon;
		b.setSmallIcon(icon != 0 ? icon : android.R.drawable.ic_menu_camera);
		b.setContentTitle(getApplicationInfo().loadLabel(getPackageManager()).toString());
		b.setContentText(RtI18n.t("التقاط الشاشة نشط", "Screen capture is active"));
		b.setOngoing(true);
		b.setContentIntent(RtBackground.openAppIntent(this, NOTIF_ID, ""));
		Intent stop = new Intent(this, RtScreenService.class).setAction(ACTION_STOP);
		int fl = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
		PendingIntent sp = PendingIntent.getService(this, NOTIF_ID + 1, stop, fl);
		b.addAction(android.R.drawable.ic_menu_close_clear_cancel, RtI18n.t("إيقاف", "Stop"), sp);
		Notification n = b.build();
		if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
		else startForeground(NOTIF_ID, n);
	}

	@Override public void onDestroy() {
		try { RtScreen.stopSession(true); } catch (Throwable ignore) {}
		super.onDestroy();
	}
}
