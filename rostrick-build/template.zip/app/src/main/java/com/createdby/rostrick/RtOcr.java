package com.createdby.rostrick;

import android.app.Activity;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

/**
 * نسخة فارغة من قراءة النص من الصور (OCR) — لا مكتبة Tesseract ولا بيانات لغات.
 * عند تفعيل "ocr" في إعدادات البناء يستبدلها tools/apply_config.py بالنسخة الحقيقية
 * من tools/RtOcrReal.java.txt ويضيف المكتبة وملفات اللغات (ara/eng افتراضياً).
 */
public final class RtOcr {
	static final boolean ENABLED = false;

	public RtOcr(Activity a, WebView w) {}

	@JavascriptInterface public boolean enabled() { return false; }
	@JavascriptInterface public String languages() { return "[]"; }
	@JavascriptInterface public boolean recognize(String json, int reqId) { return false; }
	@JavascriptInterface public void release() {}
	public void onDestroy() {}
}
