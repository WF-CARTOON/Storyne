package com.createdby.rostrick;

import com.createdby.rostrick.SplashActivity;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.DialogFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.*;
import com.createdby.rostrick.databinding.*;
import com.scottyab.rootbeer.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;

public class MainActivity extends Activity {
	
	private MainBinding binding;
	
	private RequestNetwork updater;
	private RequestNetwork.RequestListener _updater_request_listener;
	
	// ===== RosTrick: اتجاه الشاشة (يُقرأ من <meta name="rostrick-orientation" content="landscape|portrait|both"> في الصفحة) =====
	private static final String RT_ORIENT_JS = "(function(){try{var m=document.querySelector('meta[name=\\\"rostrick-orientation\\\"]');return m?String(m.getAttribute('content')||''):'';}catch(e){return '';}})()";
	// يجعل navigator.vibrate() القياسي يمر عبر الجسر أعلاه
	private static final String RT_VIBRATE_JS = "(function(){try{if(window.__rtVib||!window.RosTrickDevice)return;window.__rtVib=1;Object.defineProperty(navigator,'vibrate',{configurable:true,writable:true,value:function(p){try{window.__rtVibStatus=String(RosTrickDevice.vibrate(JSON.stringify(p==null?0:p)));return true;}catch(e){return false;}}});}catch(e){}})();";
	// === RosTrick: واجهة الإعلانات للصفحات — window.RosTrickAds (تعمل دائماً؛ إن كانت الإعلانات غير مفعّلة تُرجع false) ===
	private static final String RT_ADS_JS = "(function(){try{if(window.RosTrickAds&&window.RosTrickAds.__v)return;var B=window.RosTrickAdsBridge;var on=false;try{on=!!(B&&B.enabled());}catch(e){}var pend={},n=0;function ev(t,e,ok){try{window.dispatchEvent(new CustomEvent('rostrick-ad',{detail:{type:t,event:e,ok:!!ok}}));}catch(_){}}window.__rtAdEvent=function(t,e,id,ok){ev(t,e,ok);if(id&&pend[id]&&(e==='closed'||e==='failed')){var r=pend[id];delete pend[id];r(!!ok);}};function run(fn){return new Promise(function(r){if(!on){r(false);return;}var id=++n;pend[id]=r;try{B[fn](id);}catch(e){delete pend[id];r(false);}});}window.RosTrickAds={__v:1,enabled:on,showBanner:function(p){if(on)try{B.showBanner(p==='top'?'top':'bottom');}catch(e){}},hideBanner:function(){if(on)try{B.hideBanner();}catch(e){}},isReady:function(t){try{return on&&!!B.isReady(String(t));}catch(e){return false;}},showInterstitial:function(){return run('showInterstitial');},showRewarded:function(){return run('showRewarded');}};}catch(e){}})();";
	private RtAds rtAds;
	// === RosTrick: واجهة إعلانات Unity Ads للصفحات — window.RosTrickUnityAds (نفس شكل window.RosTrickAds أعلاه، بمساحة اسم مستقلة) ===
	private static final String RT_UNITY_ADS_JS = "(function(){try{if(window.RosTrickUnityAds&&window.RosTrickUnityAds.__v)return;var B=window.RosTrickUnityAdsBridge;var on=false;try{on=!!(B&&B.enabled());}catch(e){}var pend={},n=0;function ev(t,e,ok){try{window.dispatchEvent(new CustomEvent('rostrick-unity-ad',{detail:{type:t,event:e,ok:!!ok}}));}catch(_){}}window.__rtUnityAdEvent=function(t,e,id,ok){ev(t,e,ok);if(id&&pend[id]&&(e==='closed'||e==='failed')){var r=pend[id];delete pend[id];r(!!ok);}};function run(fn){return new Promise(function(r){if(!on){r(false);return;}var id=++n;pend[id]=r;try{B[fn](id);}catch(e){delete pend[id];r(false);}});}window.RosTrickUnityAds={__v:1,enabled:on,showBanner:function(p){if(on)try{B.showBanner(p==='top'?'top':'bottom');}catch(e){}},hideBanner:function(){if(on)try{B.hideBanner();}catch(e){}},isReady:function(t){try{return on&&!!B.isReady(String(t));}catch(e){return false;}},showInterstitial:function(){return run('showInterstitial');},showRewarded:function(){return run('showRewarded');}};}catch(e){}})();";
	private RtUnityAds rtUnityAds;
	// === RosTrick: واجهة إعلانات فيسبوك (Meta Audience Network) للصفحات — window.RosTrickFbAds (نفس الشكل، مساحة اسم مستقلة) ===
	private static final String RT_FB_ADS_JS = "(function(){try{if(window.RosTrickFbAds&&window.RosTrickFbAds.__v)return;var B=window.RosTrickFbAdsBridge;var on=false;try{on=!!(B&&B.enabled());}catch(e){}var pend={},n=0;function ev(t,e,ok){try{window.dispatchEvent(new CustomEvent('rostrick-fb-ad',{detail:{type:t,event:e,ok:!!ok}}));}catch(_){}}window.__rtFbAdEvent=function(t,e,id,ok){ev(t,e,ok);if(id&&pend[id]&&(e==='closed'||e==='failed')){var r=pend[id];delete pend[id];r(!!ok);}};function run(fn){return new Promise(function(r){if(!on){r(false);return;}var id=++n;pend[id]=r;try{B[fn](id);}catch(e){delete pend[id];r(false);}});}window.RosTrickFbAds={__v:1,enabled:on,showBanner:function(p){if(on)try{B.showBanner(p==='top'?'top':'bottom');}catch(e){}},hideBanner:function(){if(on)try{B.hideBanner();}catch(e){}},isReady:function(t){try{return on&&!!B.isReady(String(t));}catch(e){return false;}},showInterstitial:function(){return run('showInterstitial');},showRewarded:function(){return run('showRewarded');}};}catch(e){}})();";
	private RtFbAds rtFbAds;
	// === RosTrick: واجهة الصفحات اليدوية — window.RosTrickPages (تعمل دائماً، لا تحتاج تفعيلاً من إعدادات البناء)
	//     تتيح تحميل صفحة لم تُسجَّل ضمن apppages.json (فلم تُحمَّل تلقائياً عند تشغيل التطبيق) عند طلب المستخدم ===
	private static final String RT_PAGES_JS = "(function(){try{if(window.RosTrickPages&&window.RosTrickPages.__v)return;var B=window.RosTrickPagesBridge;var pend={},n=0;window.__rtPageDownloadEvent=function(id,ok){if(id&&pend[id]){var r=pend[id];delete pend[id];r(!!ok);}};window.RosTrickPages={__v:1,isDownloaded:function(p){try{return !!(B&&B.isDownloaded(String(p)));}catch(e){return false;}},download:function(p){return new Promise(function(r){if(!B){r(false);return;}var id=++n;pend[id]=r;try{B.download(String(p),id);}catch(e){delete pend[id];r(false);}});},openPage:function(p){try{if(B)B.openPage(String(p));}catch(e){}}};}catch(e){}})();";

	// جسر "Assets داخل الـ APK" (ملفات تُحقن وقت البناء من rostrick-build/assets.zip عبر apply_config.py،
	// بخلاف الصفحات/app-assets التي تُجلب عبر الشبكة). الواجهة: window.RosTrickAssets.exists(path)/.read(path) (base64 أو null).
	private static final String RT_ASSETS_JS = "(function(){try{if(window.RosTrickAssets&&window.RosTrickAssets.__v)return;var B=window.RosTrickAssetsBridge;window.RosTrickAssets={__v:1,exists:function(p){try{return !!(B&&B.exists(String(p)));}catch(e){return false;}},read:function(p){try{var r=B?B.read(String(p)):null;return (r===undefined)?null:r;}catch(e){return null;}}};}catch(e){}})();";
	// === RosTrick: واجهة الإشعارات (Firebase) — window.RosTrickPush ===
	private static final String RT_PUSH_JS = "(function(){try{if(window.RosTrickPush&&window.RosTrickPush.__v)return;var B=window.RosTrickPushBridge;var on=false;try{on=!!(B&&B.enabled());}catch(e){}var pend={},n=0;window.__rtPush=function(id,s){var o;try{o=JSON.parse(s);}catch(e){o={};}if(!id){try{window.dispatchEvent(new CustomEvent('rostrick-push',{detail:o}));}catch(_){}return;}var r=pend[id];if(r){delete pend[id];r(o);}};function call(fn,args,map){return new Promise(function(r){if(!on){r(map({}));return;}var id=++n;pend[id]=function(o){r(map(o));};try{B[fn].apply(B,[id].concat(args||[]));}catch(e){delete pend[id];r(map({}));}});}window.RosTrickPush={__v:1,enabled:on,getToken:function(){return call('getToken',[],function(o){return o.token||'';});},subscribe:function(t){return call('subscribe',[String(t)],function(o){return !!o.ok;});},unsubscribe:function(t){return call('unsubscribe',[String(t)],function(o){return !!o.ok;});},requestPermission:function(){return call('requestPermission',[],function(o){return !!o.granted;});}};}catch(e){}})();";
	// === RosTrick: واجهة الشراء داخل التطبيق (Google Play Billing) — window.RosTrickBilling ===
	private static final String RT_BILL_JS = "(function(){try{if(window.RosTrickBilling&&window.RosTrickBilling.__v)return;var B=window.RosTrickBillingBridge;var on=false;try{on=!!(B&&B.enabled());}catch(e){}var pend={},n=0;window.__rtBill=function(id,s){var o;try{o=JSON.parse(s);}catch(e){o={ok:false,error:'bad response'};}if(!id){try{window.dispatchEvent(new CustomEvent('rostrick-purchase',{detail:o}));}catch(_){}return;}var r=pend[id];if(r){delete pend[id];r(o);}};function call(fn,args){return new Promise(function(r){if(!on){r({ok:false,error:'billing disabled'});return;}var id=++n;pend[id]=r;try{B[fn].apply(B,[id].concat(args||[]));}catch(e){delete pend[id];r({ok:false,error:String(e)});}});}window.RosTrickBilling={__v:1,enabled:on,getProducts:function(ids,type){return call('getProducts',[JSON.stringify(ids||[]),type==='subs'?'subs':'inapp']);},buy:function(pid,o){o=o||{};return call('buy',[String(pid),o.type==='subs'?'subs':'inapp',!!o.consumable,String(o.offerToken||'')]);},getPurchases:function(){return call('getPurchases',[]);},consume:function(t){return call('consume',[String(t)]);}};}catch(e){}})();";
	private RtPush rtPush;
	private RtBilling rtBilling;
	// === RosTrick: واجهة الروابط العميقة — window.RosTrickLinks (تعمل دائماً؛ تُفعَّل الروابط نفسها من إعدادات البناء) ===
	private static final String RT_LINKS_JS = "(function(){try{if(window.RosTrickLinks&&window.RosTrickLinks.__v)return;var B=window.RosTrickLinksBridge;function parse(u){if(!u)return null;var o={url:String(u),scheme:'',host:'',path:'',query:{},hash:''};try{var m=/^([a-zA-Z][a-zA-Z0-9+.-]*):\\/\\/([^\\/?#]*)([^?#]*)(?:\\?([^#]*))?(?:#(.*))?$/.exec(String(u));if(m){o.scheme=m[1].toLowerCase();o.host=m[2];o.path=m[3]||'';o.hash=m[5]||'';(m[4]||'').split('&').forEach(function(kv){if(!kv)return;var i=kv.indexOf('=');var k=i<0?kv:kv.slice(0,i);var v=i<0?'':kv.slice(i+1);try{o.query[decodeURIComponent(k)]=decodeURIComponent(v.replace(/\\+/g,' '));}catch(_){o.query[k]=v;}});}}catch(e){}return o;}window.__rtLink=function(u){var o=parse(u);if(!o)return;try{window.dispatchEvent(new CustomEvent('rostrick-link',{detail:o}));}catch(_){}};window.RosTrickLinks={__v:1,getInitial:function(){try{return B?parse(B.getInitial()||''):null;}catch(e){return null;}},clear:function(){try{if(B)B.clear();}catch(e){}}};}catch(e){}})();";
	// === RosTrick: واجهة التقييم — window.RosTrickReview (openStore تعمل دائماً؛ request تحتاج تفعيل "طلب التقييم" في إعدادات البناء) ===
	private static final String RT_REVIEW_JS = "(function(){try{if(window.RosTrickReview&&window.RosTrickReview.__v)return;var B=window.RosTrickReviewBridge;var on=false;try{on=!!(B&&B.enabled());}catch(e){}var pend={},n=0;window.__rtReview=function(id,s){var o;try{o=JSON.parse(s);}catch(e){o={ok:false};}var r=pend[id];if(r){delete pend[id];r(o);}};window.RosTrickReview={__v:1,enabled:on,request:function(){return new Promise(function(r){if(!on){r({ok:false,error:'review disabled'});return;}var id=++n;pend[id]=r;try{B.request(id);}catch(e){delete pend[id];r({ok:false,error:String(e)});}});},openStore:function(){try{return !!(B&&B.openStore());}catch(e){return false;}}};}catch(e){}})();";
	private RtReview rtReview;
	private String rtLastLink = null;
	// === RosTrick: واجهات المتصفح القياسية (clipboard, wakeLock, Notification, getBattery, share, contacts, serviceWorker) ===
	private RtWebApi rtWebApi;
	private RtHw rtHw;
	private String rtHwJsCache = null;
	private String rtHwJs() {
		if (rtHwJsCache == null) {
			try {
				java.io.InputStream in = getAssets().open("rt-webapi-hw.js");
				java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
				byte[] buf = new byte[8192];
				int r;
				while ((r = in.read(buf)) > 0) bo.write(buf, 0, r);
				in.close();
				rtHwJsCache = bo.toString("UTF-8");
			} catch (Throwable t) { rtHwJsCache = ""; }
		}
		return rtHwJsCache;
	}
	private String rtWebApiJsCache = null;
	private String rtWebApiJs() {
		if (rtWebApiJsCache == null) {
			try {
				java.io.InputStream in = getAssets().open("rt-webapi.js");
				java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
				byte[] buf = new byte[8192];
				int r;
				while ((r = in.read(buf)) > 0) bo.write(buf, 0, r);
				in.close();
				rtWebApiJsCache = bo.toString("UTF-8");
			} catch (Throwable t) { rtWebApiJsCache = ""; }
		}
		return rtWebApiJsCache;
	}
	private android.webkit.WebView rtWebView;
	// === RosTrick: واجهة المشاركة — window.RosTrickShare (تعمل دائماً، بلا إعداد) ===
	private static final String RT_SHARE_JS = "(function(){try{if(window.RosTrickShare&&window.RosTrickShare.__v)return;var B=window.RosTrickShareBridge;var pend={},n=0;window.__rtShare=function(id,ok){var r=pend[id];if(r){delete pend[id];r(!!ok);}};function s(v){return v==null?'':String(v);}window.RosTrickShare={__v:1,available:!!B,share:function(o){o=o||{};return new Promise(function(r){if(!B){r(false);return;}var id=++n;pend[id]=r;try{B.share(id,s(o.title),s(o.text),s(o.url),s(o.file),s(o.fileName),s(o.mime));}catch(e){delete pend[id];r(false);}});}};}catch(e){}})();";
	private static final String RT_PREFS = "rostrick_runtime";
	
	// يطبّق الاتجاه: أفقي فقط / عمودي فقط / كلاهما (تدوير حر) / بدون تعريف = السلوك الافتراضي
	private void rtApplyOrientation(String raw) {
		String m = raw == null ? "" : raw.toLowerCase(java.util.Locale.ROOT);
		boolean land = m.contains("landscape");
		boolean port = m.contains("portrait");
		boolean both = m.contains("both") || m.contains("auto") || (land && port);
		int o;
		String norm;
		if (both) { o = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_FULL_USER; norm = "both"; }
		else if (land) { o = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE; norm = "landscape"; }
		else if (port) { o = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT; norm = "portrait"; }
		else { o = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED; norm = ""; }
		try {
			if (getRequestedOrientation() != o) setRequestedOrientation(o);
			getSharedPreferences(RT_PREFS, MODE_PRIVATE).edit().putString("orientation", norm).apply();
		} catch (Exception e) { e.printStackTrace(); }
	}
	
	// يقرأ تعريف الاتجاه من الصفحة المعروضة حالياً
	private void rtReadOrientationFromPage(android.webkit.WebView view) {
		if (view == null) return;
		view.evaluateJavascript(RT_ORIENT_JS, new android.webkit.ValueCallback<String>() {
			@Override
			public void onReceiveValue(String v) {
				String val = v == null ? "" : v.replace("\"", "").trim();
				if ("null".equals(val)) val = "";
				rtApplyOrientation(val);
			}
		});
	}
	
	// ===== RosTrick: الروابط العميقة =====
	// إن كان الرابط ينتهي باسم صفحة موجودة (مثل myapp://open/about.html أو https://site.com/about.html) نفتح الصفحة مباشرة؛
	// وفي كل الأحوال تستلم الصفحة الرابط عبر window.RosTrickLinks.getInitial() أو الحدث rostrick-link.
	private String rtLinkPageFile(String link) {
		try {
			Uri u = Uri.parse(link);
			String last = u.getLastPathSegment();
			if (last == null || last.length() > 160 || last.indexOf('/') >= 0 || last.indexOf('\\') >= 0 || last.indexOf("..") >= 0) return null;
			// رابط نظيف بدون امتداد: example.com/home  ->  home.html
			if (last.indexOf('.') < 0) { if (!last.matches("[A-Za-z0-9_-]+")) return null; last = last + ".html"; }
			else if (!last.endsWith(".html")) return null;
			File f = new File(getApplicationContext().getFilesDir(), last);
			return f.exists() ? "file://" + f.getAbsolutePath() : null;
		} catch (Throwable t) { return null; }
	}
	
	// يصل التطبيق وهو يعمل (singleTask): رابط جديد أو إشعار جديد
	@Override
	protected void onNewIntent(android.content.Intent intent) {
		super.onNewIntent(intent);
		try {
			setIntent(intent);
			if (rtWebApi != null) rtWebApi.onNewIntent(intent);
			String link = intent != null ? intent.getStringExtra("rt_link") : null;
			String pageUrl = null;
			if (link != null && link.length() > 0 && link.length() <= 2048) {
				rtLastLink = link;
				pageUrl = rtLinkPageFile(link);
			} else if (intent != null) {
				String rtPage = intent.getStringExtra("rt_page");
				if (rtPage != null && rtPage.length() > 0 && rtPage.length() < 160 && rtPage.indexOf('/') < 0 && rtPage.indexOf('\\') < 0 && rtPage.indexOf("..") < 0) {
					File pf = new File(getApplicationContext().getFilesDir(), rtPage);
					if (pf.exists()) pageUrl = "file://" + pf.getAbsolutePath();
				}
			}
			if (rtWebView == null) return;
			if (pageUrl != null) {
				rtWebView.loadUrl(pageUrl);
			}
			if (link != null && link.length() > 0) {
				final String lk = org.json.JSONObject.quote(link);
				// بعد تحميل الصفحة الجديدة (إن وُجدت) نُرسل الحدث؛ وإلا فوراً
				rtWebView.postDelayed(new Runnable() {
					@Override public void run() { try { rtWebView.evaluateJavascript("window.__rtLink&&window.__rtLink(" + lk + ")", null); } catch (Throwable ignore) {} }
				}, pageUrl != null ? 1200 : 0);
			}
		} catch (Throwable ignored) {}
	}
	
	// ===== RosTrick: المشاركة عبر قائمة المشاركة في النظام (نص و/أو رابط و/أو ملف base64) =====
	private boolean rtShare(String title, String text, String url, String fileB64, String fileName, String mime) throws Exception {
		StringBuilder body = new StringBuilder();
		if (text != null && text.length() > 0) body.append(text);
		if (url != null && url.length() > 0) { if (body.length() > 0) body.append("\n"); body.append(url); }
		android.content.Intent send = new android.content.Intent(android.content.Intent.ACTION_SEND);
		if (title != null && title.length() > 0) send.putExtra(android.content.Intent.EXTRA_SUBJECT, title);
		if (body.length() > 0) send.putExtra(android.content.Intent.EXTRA_TEXT, body.toString());
		boolean hasFile = false;
		if (fileB64 != null && fileB64.length() > 0) {
			String b64 = fileB64;
			int comma = b64.indexOf("base64,");
			if (b64.startsWith("data:") && comma > 0) {
				if (mime == null || mime.length() == 0) { int sc = b64.indexOf(';'); if (sc > 5) mime = b64.substring(5, sc); }
				b64 = b64.substring(comma + 7);
			}
			byte[] data = android.util.Base64.decode(b64, android.util.Base64.DEFAULT);
			if (data.length > 0 && data.length <= 20 * 1024 * 1024) {
				String safe = (fileName == null ? "" : fileName).replaceAll("[^A-Za-z0-9._-]", "_");
				if (safe.length() == 0 || safe.startsWith(".")) safe = "share" + (safe.startsWith(".") ? safe : "");
				if (safe.length() > 80) safe = safe.substring(safe.length() - 80);
				File dir = new File(getCacheDir(), "rt_share");
				if (!dir.exists()) dir.mkdirs();
				File[] old = dir.listFiles();
				if (old != null) for (File o : old) { if (System.currentTimeMillis() - o.lastModified() > 3600000L) o.delete(); }
				File f = new File(dir, safe);
				FileOutputStream fo = new FileOutputStream(f);
				try { fo.write(data); } finally { fo.close(); }
				Uri uri = new Uri.Builder().scheme("content").authority(RtShareProvider.authority(this)).appendPath(safe).build();
				send.putExtra(android.content.Intent.EXTRA_STREAM, uri);
				send.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);
				send.setClipData(android.content.ClipData.newRawUri(safe, uri));
				hasFile = true;
			}
		}
		if (!hasFile && body.length() == 0) return false;
		send.setType((hasFile && mime != null && mime.length() > 0) ? mime : (hasFile ? "application/octet-stream" : "text/plain"));
		android.content.Intent chooser = android.content.Intent.createChooser(send, (title != null && title.length() > 0) ? title : null);
		startActivity(chooser);
		return true;
	}
	
	// ===== RosTrick: تنفيذ الاهتزاز بأسلوب محدد =====
	private String rtVibrate(String mode, String json, final android.view.View hapticView) {
		try {
			if ("haptic".equals(mode)) {
				// اهتزاز اللمس النظامي مع تجاهل إعدادات "ردود فعل اللمس" في الجهاز
				hapticView.post(new Runnable() {
					@Override public void run() {
						hapticView.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS,
							android.view.HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING | android.view.HapticFeedbackConstants.FLAG_IGNORE_VIEW_SETTING);
					}
				});
				return "ok(haptic)";
			}
			android.os.Vibrator vb = (android.os.Vibrator) getSystemService(VIBRATOR_SERVICE);
			if (vb == null || !vb.hasVibrator()) return "no_vibrator";
			Object v = new org.json.JSONTokener(json == null ? "0" : json).nextValue();
			java.util.ArrayList<Long> t = new java.util.ArrayList<Long>();
			t.add(0L);
			if (v instanceof org.json.JSONArray) {
				org.json.JSONArray arr = (org.json.JSONArray) v;
				for (int i = 0; i < arr.length() && i < 50; i++) t.add(Math.max(0L, Math.min(5000L, arr.optLong(i, 0))));
			} else if (v instanceof Number) {
				t.add(Math.max(0L, Math.min(5000L, ((Number) v).longValue())));
			}
			long sum = 0;
			for (long x : t) sum += x;
			if (sum <= 0) { vb.cancel(); return "cancelled"; }
			long[] timings = new long[t.size()];
			for (int i = 0; i < timings.length; i++) timings[i] = t.get(i);
			if ("legacy".equals(mode)) {
				vb.vibrate(timings, -1);
				return "ok(legacy)";
			}
			int usage = android.media.AudioAttributes.USAGE_ALARM;
			if ("touch".equals(mode)) usage = android.media.AudioAttributes.USAGE_ASSISTANCE_SONIFICATION;
			else if ("notification".equals(mode)) usage = android.media.AudioAttributes.USAGE_NOTIFICATION;
			else if ("media".equals(mode)) usage = android.media.AudioAttributes.USAGE_MEDIA;
			else if ("unknown".equals(mode)) usage = android.media.AudioAttributes.USAGE_UNKNOWN;
			android.media.AudioAttributes aa = new android.media.AudioAttributes.Builder()
				.setUsage(usage)
				.setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION)
				.build();
			if (android.os.Build.VERSION.SDK_INT >= 26) {
				vb.vibrate(android.os.VibrationEffect.createWaveform(timings, -1), aa);
			} else {
				vb.vibrate(timings, -1, aa);
			}
			return "ok(" + mode + ")";
		} catch (Throwable e) {
			e.printStackTrace();
			return "error:" + e.getClass().getSimpleName();
		}
	}
	
	// ===== RosTrick: أذونات الكاميرا/الميكروفون/الموقع لصفحات الـ HTML =====
	// لا يُمنح إلا ما أُعلن في AndroidManifest (أي ما اختاره صاحب التطبيق وقت البناء)
	private android.webkit.PermissionRequest rtPendingWebReq;
	private String[] rtPendingWebRes;
	private String rtPendingGeoOrigin;
	private android.webkit.GeolocationPermissions.Callback rtPendingGeoCb;
	
	private boolean rtDeclared(String perm) {
		try {
			android.content.pm.PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), android.content.pm.PackageManager.GET_PERMISSIONS);
			if (pi.requestedPermissions != null) {
				for (String p : pi.requestedPermissions) { if (perm.equals(p)) return true; }
			}
		} catch (Exception e) { e.printStackTrace(); }
		return false;
	}
	
	private boolean rtHas(String perm) {
		return android.os.Build.VERSION.SDK_INT < 23 || checkSelfPermission(perm) == android.content.pm.PackageManager.PERMISSION_GRANTED;
	}
	
	private void rtHandleWebPermission(final android.webkit.PermissionRequest request) {
		java.util.ArrayList<String> grant = new java.util.ArrayList<String>();
		java.util.ArrayList<String> need = new java.util.ArrayList<String>();
		for (String r : request.getResources()) {
			if (android.webkit.PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r) && rtDeclared(android.Manifest.permission.CAMERA)) {
				grant.add(r);
				if (!rtHas(android.Manifest.permission.CAMERA)) need.add(android.Manifest.permission.CAMERA);
			} else if (android.webkit.PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r) && rtDeclared(android.Manifest.permission.RECORD_AUDIO)) {
				grant.add(r);
				if (!rtHas(android.Manifest.permission.RECORD_AUDIO)) need.add(android.Manifest.permission.RECORD_AUDIO);
			}
		}
		if (grant.isEmpty()) { request.deny(); return; }
		String[] res = grant.toArray(new String[0]);
		if (need.isEmpty()) { request.grant(res); return; }
		if (rtPendingWebReq != null) { try { rtPendingWebReq.deny(); } catch (Exception ignored) {} }
		rtPendingWebReq = request;
		rtPendingWebRes = res;
		requestPermissions(need.toArray(new String[0]), 7301);
	}
	
	private void rtHandleGeoPermission(String origin, android.webkit.GeolocationPermissions.Callback callback) {
		boolean declared = rtDeclared(android.Manifest.permission.ACCESS_FINE_LOCATION) || rtDeclared(android.Manifest.permission.ACCESS_COARSE_LOCATION);
		if (!declared) { callback.invoke(origin, false, false); return; }
		if (rtHas(android.Manifest.permission.ACCESS_FINE_LOCATION) || rtHas(android.Manifest.permission.ACCESS_COARSE_LOCATION)) {
			callback.invoke(origin, true, false);
			return;
		}
		if (rtPendingGeoCb != null) { try { rtPendingGeoCb.invoke(rtPendingGeoOrigin, false, false); } catch (Exception ignored) {} }
		rtPendingGeoOrigin = origin;
		rtPendingGeoCb = callback;
		requestPermissions(new String[]{ android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION }, 7302);
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (rtWebApi != null && rtWebApi.onPermissionResult(requestCode, grantResults)) return;
		if (rtHw != null && rtHw.onPermissionResult(requestCode, grantResults)) return;
		if (requestCode == 7303) {
			if (rtPush != null) rtPush.onPermissionResult(grantResults != null && grantResults.length > 0 && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED);
		} else if (requestCode == 7301 && rtPendingWebReq != null) {
			android.webkit.PermissionRequest req = rtPendingWebReq;
			String[] res = rtPendingWebRes;
			rtPendingWebReq = null; rtPendingWebRes = null;
			java.util.ArrayList<String> ok = new java.util.ArrayList<String>();
			for (String r : res) {
				if (android.webkit.PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r) && rtHas(android.Manifest.permission.CAMERA)) ok.add(r);
				if (android.webkit.PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r) && rtHas(android.Manifest.permission.RECORD_AUDIO)) ok.add(r);
			}
			try { if (ok.isEmpty()) req.deny(); else req.grant(ok.toArray(new String[0])); } catch (Exception e) { e.printStackTrace(); }
		} else if (requestCode == 7302 && rtPendingGeoCb != null) {
			boolean ok = rtHas(android.Manifest.permission.ACCESS_FINE_LOCATION) || rtHas(android.Manifest.permission.ACCESS_COARSE_LOCATION);
			try { rtPendingGeoCb.invoke(rtPendingGeoOrigin, ok, false); } catch (Exception e) { e.printStackTrace(); }
			rtPendingGeoCb = null; rtPendingGeoOrigin = null;
		}
	}
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		// اتجاه الشاشة: نبدأ بآخر اتجاه طُبّق (حتى لا يومض عند الفتح)، ثم تحدده الصفحة المعروضة
		rtApplyOrientation(getSharedPreferences(RT_PREFS, MODE_PRIVATE).getString("orientation", ""));
		binding = MainBinding.inflate(getLayoutInflater());
		setContentView(binding.getRoot());
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		updater = new RequestNetwork(this);
		
		binding.WebView1.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				super.onPageFinished(_param1, _param2);
			}
		});
		
		_updater_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		// =======================================================
		// 🧱 البلوك الأول: تعريفات Workers.dev (مصدر المشروع الوحيد)
		// =======================================================
		final String ASSET_BASE_HOST = "";
		final String ASSET_BASE_URL = "https://" + ASSET_BASE_HOST + "/";
		final String APP_PAGES_URL = ASSET_BASE_URL + "apppages.json";
		// =======================================================
		// 🧱 البلوك الثاني: بقية كود onCreate
		// =======================================================
		
		// === [جديد] مسح سجل التصفح الذكي (Smart Back Stack) بداية كل فتحة للتطبيق، فيبدأ كل جلسة استخدام سجلاً جديداً فاضياً
		MainActivity.this.getSharedPreferences("smart_back_stack", android.content.Context.MODE_PRIVATE).edit().clear().apply();
		
		// =======================================================
		// 🚀 أولاً: نظام التحديث الإجباري للـ APK (تحديث التطبيق نفسه)
		// =======================================================
		int currentVersionCode = 0;
		try {
			android.content.pm.PackageInfo pInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
			if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
				currentVersionCode = (int) pInfo.getLongVersionCode();
			} else {
				currentVersionCode = pInfo.versionCode;
			}
		} catch (android.content.pm.PackageManager.NameNotFoundException e) {
			e.printStackTrace();
		}
		
		final int installedCode = currentVersionCode;
		
		RequestNetwork apkUpdateChecker = new RequestNetwork(MainActivity.this);
		String apkVersionUrl = ASSET_BASE_URL + "apk_version.json";
		
		apkUpdateChecker.startRequestNetwork(RequestNetworkController.GET, apkVersionUrl, "apk_check", new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String tag, String response, java.util.HashMap<String, Object> responseHeaders) {
				if (response == null || response.trim().isEmpty()) return;
				
				try {
					org.json.JSONObject json = new org.json.JSONObject(response);
					int latestVersionCode = json.optInt("version_code", 0);
					final String downloadUrl = json.optString("download_url", "");
					final String changeLog = json.optString("change_log", RtI18n.t("يتوفر إصدار جديد من التطبيق، يرجى التحديث للمتابعة.", "A new version of the app is available. Please update to continue."));
					
					if (latestVersionCode > installedCode) {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(MainActivity.this);
								builder.setTitle(RtI18n.t("تحديث جديد متوفر 🚀", "New update available 🚀"));
								builder.setMessage(changeLog);
								builder.setCancelable(false);
								
								builder.setPositiveButton(RtI18n.t("تحديث الآن", "Update now"), new android.content.DialogInterface.OnClickListener() {
									@Override
									public void onClick(android.content.DialogInterface dialog, int which) {
										try {
											android.content.Intent intent = new android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(downloadUrl));
											startActivity(intent);
										} catch (Exception e) {
											e.printStackTrace();
										}
										finish();
									}
								});
								
								builder.setOnKeyListener(new android.content.DialogInterface.OnKeyListener() {
									@Override
									public boolean onKey(android.content.DialogInterface dialog, int keyCode, android.view.KeyEvent event) {
										if (keyCode == android.view.KeyEvent.KEYCODE_BACK) {
											finish();
											return true;
										}
										return false;
									}
								});
								
								android.app.AlertDialog dialog = builder.create();
								dialog.setCanceledOnTouchOutside(false);
								dialog.show();
							}
						});
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			
			@Override
			public void onErrorResponse(String tag, String message) {}
		});
		
		// =======================================================
		// 🌐 ثانياً: تهيئة الـ WebView
		// =======================================================
		final boolean[] hasShownMediaAlert = {false};
		final android.webkit.ValueCallback<android.net.Uri[]>[] mUploadMessage = new android.webkit.ValueCallback[1];
		
		final android.webkit.WebView dynamicWebView = new android.webkit.WebView(MainActivity.this);
		rtWebView = dynamicWebView;
		
		dynamicWebView.setId(99999); 
		
		// === [إضافة جديدة] إخفاء شريط التمرير (Scrollbar) نهائياً من الـ WebView ===
		dynamicWebView.setVerticalScrollBarEnabled(false);
		dynamicWebView.setHorizontalScrollBarEnabled(false);
		dynamicWebView.setScrollBarStyle(android.view.View.SCROLLBARS_INSIDE_OVERLAY);
		
		// === [إضافة جديدة] تعطيل تأثير الموجة/الوهج (Overscroll Glow) عند الوصول لنهاية المحتوى ===
		dynamicWebView.setOverScrollMode(android.view.View.OVER_SCROLL_NEVER);
		
		// === [جديد] حاوية جذر تدعم عرض فيديو/عنصر بملء الشاشة (Fullscreen) فوق الـ WebView ===
		final android.widget.FrameLayout rootFullscreenContainer = new android.widget.FrameLayout(MainActivity.this);
		final android.view.View[] customFullscreenView = new android.view.View[1];
		final android.webkit.WebChromeClient.CustomViewCallback[] customFullscreenCallback = new android.webkit.WebChromeClient.CustomViewCallback[1];
		
		dynamicWebView.getSettings().setJavaScriptEnabled(true);
		dynamicWebView.getSettings().setAllowFileAccess(true);
		dynamicWebView.getSettings().setAllowFileAccessFromFileURLs(true);
		dynamicWebView.getSettings().setAllowUniversalAccessFromFileURLs(true);
		
		dynamicWebView.getSettings().setDomStorageEnabled(true);
		dynamicWebView.getSettings().setDatabaseEnabled(true);
		
		// === [إضافة جديدة] تفعيل دعم target="_blank" و window.open() ===
		dynamicWebView.getSettings().setSupportMultipleWindows(true);
		dynamicWebView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
		String databasePath = MainActivity.this.getApplicationContext().getDir("database", android.content.Context.MODE_PRIVATE).getPath();
		dynamicWebView.getSettings().setDatabasePath(databasePath);
		
		// === [إضافة جديدة] منع التكبير/التصغير (Zoom) بالكامل ===
		dynamicWebView.getSettings().setSupportZoom(false);
		dynamicWebView.getSettings().setBuiltInZoomControls(false);
		dynamicWebView.getSettings().setDisplayZoomControls(false);
		dynamicWebView.getSettings().setTextZoom(100);
		
		// === [جديد] حاقن قفل الـ Zoom المشترك: يُستخدم لكل صفحات HTML (المحلية file:// وصفحات الـ Worker وصفحات الصيانة/الإغلاق/404 المضمّنة) ===
		// يحط meta viewport (user-scalable=no) + touch-action في أول <head> ويشيل أي meta viewport قديم
		class ZoomLockInjector {
			// يبني محتوى الـ viewport: يحافظ على كل إعدادات الصفحة (width / initial-scale / viewport-fit ...) ويضيف قفل الـ Zoom فقط
			// (user-scalable=no + minimum/maximum-scale بنفس قيمة initial-scale). لو الصفحة بلا viewport أصلاً: width=device-width, initial-scale=1.0
			String buildViewport(String old) {
				java.util.ArrayList<String> keep = new java.util.ArrayList<String>();
				String scale = null;
				boolean hasMeta = old != null && !old.trim().isEmpty();
				if (hasMeta) {
					for (String t : old.split("[,;]")) {
						t = t.trim();
						if (t.isEmpty()) continue;
						int eq = t.indexOf('=');
						String k = (eq > 0 ? t.substring(0, eq) : t).trim().toLowerCase(java.util.Locale.US);
						String v = eq > 0 ? t.substring(eq + 1).trim() : "";
						if (k.equals("user-scalable") || k.equals("maximum-scale") || k.equals("minimum-scale")) continue;
						if (k.equals("initial-scale")) scale = v;
						keep.add(t);
					}
				} else {
					keep.add("width=device-width");
					keep.add("initial-scale=1.0");
					scale = "1.0";
				}
				if (scale != null) {
					keep.add("minimum-scale=" + scale);
					keep.add("maximum-scale=" + scale);
				}
				keep.add("user-scalable=no");
				StringBuilder sb = new StringBuilder();
				for (int i = 0; i < keep.size(); i++) {
					if (i > 0) sb.append(", ");
					sb.append(keep.get(i));
				}
				return sb.toString().replace("\"", "");
			}
			
			// يعدّل بداية النص فقط، ويرجّع null لو ما لقى <head> ولا <html> (عشان ما نحط شي قبل الـ DOCTYPE ونكسر الصفحة)
			String injectPrefix(String html) {
				try {
					// === [جديد] الصفحة اللي تحط <meta name="allow-zoom" content="true"> تُترك كما هي تماماً (بدون قفل zoom) ===
					if (java.util.regex.Pattern.compile("(?i)<meta(?=[^>]*name\\s*=\\s*[\"']allow-zoom[\"'])(?=[^>]*content\\s*=\\s*[\"']?\\s*true)[^>]*>").matcher(html).find()) {
						return null;
					}
					String metaRegex = "(?i)<meta[^>]*name\\s*=\\s*[\"']viewport[\"'][^>]*>";
					String existingContent = null;
					java.util.regex.Matcher vm = java.util.regex.Pattern.compile(metaRegex).matcher(html);
					while (vm.find()) {
						java.util.regex.Matcher cm = java.util.regex.Pattern.compile("(?i)content\\s*=\\s*([\"'])(.*?)\\1").matcher(vm.group());
						if (cm.find()) existingContent = cm.group(2);
					}
					html = html.replaceAll(metaRegex, "");
					String lock = "<meta name=\"viewport\" content=\"" + buildViewport(existingContent) + "\"><style>html,body{touch-action:pan-x pan-y !important;}</style>";
					
					java.util.regex.Matcher headMatcher = java.util.regex.Pattern.compile("(?i)<head(\\s[^>]*)?>").matcher(html);
					if (headMatcher.find()) {
						return html.substring(0, headMatcher.end()) + lock + html.substring(headMatcher.end());
					}
					java.util.regex.Matcher htmlMatcher = java.util.regex.Pattern.compile("(?i)<html(\\s[^>]*)?>").matcher(html);
					if (htmlMatcher.find()) {
						return html.substring(0, htmlMatcher.end()) + "<head>" + lock + "</head>" + html.substring(htmlMatcher.end());
					}
				} catch (Exception e) { e.printStackTrace(); }
				return null;
			}
			
			// للنصوص الصغيرة (صفحات الصيانة/الإغلاق/404 المضمّنة)
			String inject(String html) {
				if (html == null) return null;
				String r = injectPrefix(html);
				return r != null ? r : html;
			}
			
			// === للملفات: نقرأ فقط لين نوصل نهاية الـ <head> (أو بداية <body>)، مع سقف أمان 1MB، نعدّل هذا الجزء،
			// ونكمّل باقي الملف كما هو بدون تحميله بالذاكرة. بهذا أي meta viewport داخل الـ head ينشال مهما كان حجم الـ head،
			// وبدون ما نحمّل الصفحة كاملة. نستخدم ISO-8859-1 عشان البايتات تمر كما هي بدون أي تلف للـ UTF-8 ===
			java.io.InputStream wrap(java.io.InputStream in) throws java.io.IOException {
				final int CHUNK = 8192;
				final int MAX_PREFIX = 1024 * 1024;
				java.io.ByteArrayOutputStream raw = new java.io.ByteArrayOutputStream();
				StringBuilder low = new StringBuilder();
				byte[] buf = new byte[CHUNK];
				boolean headEnded = false;
				
				while (raw.size() < MAX_PREFIX && !headEnded) {
					int r = in.read(buf, 0, CHUNK);
					if (r == -1) break;
					raw.write(buf, 0, r);
					int from = Math.max(0, low.length() - 8); // تداخل بسيط عشان لو انقسم الوسم بين دفعتين
					low.append(new String(buf, 0, r, "ISO-8859-1").toLowerCase(java.util.Locale.US));
					if (low.indexOf("</head", from) != -1 || low.indexOf("<body", from) != -1) headEnded = true;
				}
				
				if (raw.size() == 0) return in;
				String prefix = new String(raw.toByteArray(), "ISO-8859-1");
				String patched = injectPrefix(prefix);
				byte[] out = (patched != null ? patched : prefix).getBytes("ISO-8859-1");
				return new java.io.SequenceInputStream(new java.io.ByteArrayInputStream(out), in);
			}
		}
		final ZoomLockInjector zoomInjector = new ZoomLockInjector();
		
		// =====================================================================================
		// === [إصلاح] أدوات تنزيل موحّدة لكل الكود:
		//     - كتابة ذرّية: التنزيل لملف .tmp ثم rename، فلا يبقى ملف مبتور أبداً لو انقطع الاتصال
		//     - التحقق من الحجم (Content-Length) ومن أن الرد ليس نص "404: Not Found"
		//     - تمييز (ملف غير موجود 4xx) عن (فشل مؤقت: شبكة/5xx) حتى لا يُسجَّل تحديث ناقص على أنه كامل
		//     - نفس User-Agent الخاص بالـ WebView حتى يرجع نفس الـ CSS/الخطوط التي سيطلبها المتصفح فعلاً
		// =====================================================================================
		class SafeIO {
			final int OK = 0;
			final int MISSING = 1;
			final int FAIL = 2;
			final String ua;
			
			SafeIO(String ua) { this.ua = ua; }
			
			java.net.HttpURLConnection open(String urlStr, int timeoutMs) throws java.io.IOException {
				java.net.HttpURLConnection c = (java.net.HttpURLConnection) new java.net.URL(urlStr).openConnection();
				c.setConnectTimeout(timeoutMs);
				c.setReadTimeout(timeoutMs);
				c.setInstanceFollowRedirects(true);
				c.setUseCaches(false); // === [إصلاح 5] لا نعتمد على أي كاش HTTP عند تحديث الصور ===
				if (ua != null && ua.length() > 0) c.setRequestProperty("User-Agent", ua);
				return c;
			}
			
			// رد قصير جداً يشبه صفحة خطأ (وليس مجرد ظهور كلمة 404 داخل محتوى حقيقي)
			boolean looksLikeNotFound(String body) {
				if (body == null) return true;
				String t = body.trim();
				if (t.length() == 0) return true;
				if (t.length() > 100) return false;
				String l = t.toLowerCase(java.util.Locale.US);
				return l.startsWith("404") || l.contains("404: not found") || l.equals("not found") || l.equals("null");
			}
			
			String readText(java.io.File f) {
				java.io.FileInputStream in = null;
				try {
					in = new java.io.FileInputStream(f);
					java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
					byte[] buf = new byte[8192];
					int r;
					while ((r = in.read(buf)) != -1) bo.write(buf, 0, r);
					return new String(bo.toByteArray(), "UTF-8");
				} catch (Exception e) {
					return null;
				} finally {
					try { if (in != null) in.close(); } catch (Exception ignore) {}
				}
			}
			
			// يحفظ الـ stream في dest بشكل ذرّي. OK فقط لو اكتمل الملف فعلاً
			int saveStream(java.io.InputStream in, java.io.File dest, long expectedLen, boolean checkNotFound) {
				java.io.File tmp = new java.io.File(dest.getPath() + "." + Thread.currentThread().getId() + ".tmp");
				java.io.FileOutputStream out = null;
				int result = FAIL;
				try {
					out = new java.io.FileOutputStream(tmp);
					byte[] buf = new byte[8192];
					long total = 0;
					int r;
					while ((r = in.read(buf)) != -1) {
						out.write(buf, 0, r);
						total += r;
					}
					out.flush();
					out.close();
					out = null;
					
					if (expectedLen > 0 && total != expectedLen) {
						result = FAIL; // تنزيل مبتور
					} else if (checkNotFound && total <= 100 && looksLikeNotFound(readText(tmp))) {
						result = MISSING; // الخادم رجّع نص 404 بحالة 200
					} else if (tmp.renameTo(dest)) {
						result = OK;
					} else {
						dest.delete();
						result = tmp.renameTo(dest) ? OK : FAIL;
					}
				} catch (Exception e) {
					e.printStackTrace();
					result = FAIL;
				} finally {
					try { in.close(); } catch (Exception ignore) {}
					try { if (out != null) out.close(); } catch (Exception ignore) {}
					if (result != OK && tmp.exists()) tmp.delete();
				}
				return result;
			}
			
			boolean writeTextAtomic(java.io.File dest, String text) {
				try {
					byte[] b = text.getBytes("UTF-8");
					return saveStream(new java.io.ByteArrayInputStream(b), dest, b.length, false) == OK;
				} catch (Exception e) {
					return false;
				}
			}
			
			int downloadToFile(String urlStr, java.io.File dest, int timeoutMs, int attempts, String[] ctOut, boolean checkNotFound) {
				int result = FAIL;
				for (int i = 0; i < attempts && result == FAIL; i++) {
					java.net.HttpURLConnection c = null;
					try {
						c = open(urlStr, timeoutMs);
						int code = c.getResponseCode();
						if (code == 200) {
							if (ctOut != null) ctOut[0] = c.getContentType();
							result = saveStream(c.getInputStream(), dest, c.getContentLength(), checkNotFound);
						} else if (code >= 400 && code < 500 && code != 408 && code != 429) {
							result = MISSING;
						}
					} catch (Exception e) {
						e.printStackTrace();
					} finally {
						if (c != null) c.disconnect();
					}
				}
				return result;
			}
			
			// === [إصلاح 9] فحص أي رابط مجهول: هل هو صورة فعلاً؟ القرار من Content-Type الذي يرسله الخادم (أي موقع)،
			//     نقرأ الهيدر فقط ونقطع الاتصال بلا تنزيل الجسم ===
			boolean probeIsImage(String urlStr, int timeoutMs) {
				java.net.HttpURLConnection c = null;
				try {
					c = open(urlStr, timeoutMs);
					if (c.getResponseCode() != 200) return false;
					String ct = c.getContentType();
					return ct != null && ct.toLowerCase(java.util.Locale.US).startsWith("image/");
				} catch (Exception e) {
					return false;
				} finally {
					if (c != null) c.disconnect();
				}
			}
			
			// روابط لا نفحصها أبداً (امتداد معروف غير صورة، أو كلمات توحي بإجراء لا بمحتوى)
			boolean skipProbe(String lowerUrl, String c) {
				if (c.endsWith(".html") || c.endsWith(".htm") || c.endsWith(".php") || c.endsWith(".js") || c.endsWith(".css")
				|| c.endsWith(".json") || c.endsWith(".xml") || c.endsWith(".txt") || c.endsWith(".map") || c.endsWith(".wasm")
				|| c.endsWith(".pdf") || c.endsWith(".zip") || c.endsWith(".apk") || c.endsWith(".woff") || c.endsWith(".woff2")
				|| c.endsWith(".ttf") || c.endsWith(".eot") || isMediaExt(c)) return true;
				return lowerUrl.contains("logout") || lowerUrl.contains("signout") || lowerUrl.contains("unsubscribe")
				|| lowerUrl.contains("delete") || lowerUrl.contains("remove") || lowerUrl.contains("webhook")
				|| lowerUrl.contains("oauth") || lowerUrl.contains("/auth") || lowerUrl.contains("/api/");
			}
			
			// === [إصلاح 10] نوع المكتبة/الخط الحقيقي: الامتداد المعروف أولاً، ثم Content-Type من الخادم، ثم فحص محتوى الملف.
			//     (كان يُفترض .css لأي رابط بلا امتداد، فتُقدَّم مكتبات مثل esm.sh بنوع text/css وترفضها المتصفحات) ===
			String readHead(java.io.File f, int n) {
				java.io.FileInputStream in = null;
				try {
					in = new java.io.FileInputStream(f);
					byte[] buf = new byte[n];
					int r = in.read(buf);
					return r <= 0 ? "" : new String(buf, 0, r, "UTF-8");
				} catch (Exception e) {
					return "";
				} finally {
					try { if (in != null) in.close(); } catch (Exception ignore) {}
				}
			}
			
			String staticMimeFor(String ct, String lowerUrl, String c, java.io.File f) {
				if (c.endsWith(".woff2")) return "font/woff2";
				if (c.endsWith(".woff")) return "font/woff";
				if (c.endsWith(".ttf")) return "font/ttf";
				if (c.endsWith(".otf")) return "font/otf";
				if (c.endsWith(".eot")) return "application/vnd.ms-fontobject";
				if (c.endsWith(".wasm")) return "application/wasm";
				if (c.endsWith(".js") || c.endsWith(".mjs")) return "application/javascript";
				if (c.endsWith(".css")) return "text/css";
				if (ct != null) {
					String m = ct.split(";")[0].trim().toLowerCase(java.util.Locale.US);
					if (m.contains("javascript") || m.contains("ecmascript")) return "application/javascript";
					if (m.length() > 0 && !m.equals("text/html") && !m.equals("text/plain")
					&& !m.equals("application/octet-stream") && !m.equals("binary/octet-stream")) return m;
				}
				String head = readHead(f, 2048);
				if (head.contains("@font-face") || head.contains("@import") || head.contains("@charset")) return "text/css";
				boolean jsLike = head.contains("function") || head.contains("=>") || head.contains("export ") || head.contains("import ")
				|| head.contains("var ") || head.contains("const ") || head.contains("let ") || head.contains("define(");
				if (jsLike) return "application/javascript";
				if (lowerUrl.contains("woff2")) return "font/woff2";
				if (lowerUrl.contains("woff")) return "font/woff";
				if (lowerUrl.contains("css")) return "text/css";
				return "application/javascript";
			}
			
			// نوع الرابط من رد الخادم: "i" صورة، "s" مكتبة/خط/CSS، وإلا null
			String probeKind(String urlStr, int timeoutMs) {
				java.net.HttpURLConnection c = null;
				try {
					c = open(urlStr, timeoutMs);
					if (c.getResponseCode() != 200) return null;
					String ct = c.getContentType();
					if (ct == null) return null;
					String m = ct.toLowerCase(java.util.Locale.US);
					if (m.startsWith("image/")) return "i";
					if (m.contains("javascript") || m.contains("ecmascript") || m.startsWith("text/css") || m.startsWith("font/")
					|| m.contains("font") || m.contains("application/wasm")) return "s";
					return null;
				} catch (Exception e) {
					return null;
				} finally {
					if (c != null) c.disconnect();
				}
			}
			
			// يرجّع النص أو null. statusOut[0]: كود الرد، أو -1 عند فشل الشبكة
			String fetchText(String urlStr, int timeoutMs, int[] statusOut) {
				java.net.HttpURLConnection c = null;
				try {
					c = open(urlStr, timeoutMs);
					int code = c.getResponseCode();
					if (statusOut != null) statusOut[0] = code;
					if (code != 200) return null;
					java.io.InputStream in = c.getInputStream();
					java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
					byte[] buf = new byte[8192];
					int r;
					while ((r = in.read(buf)) != -1) bo.write(buf, 0, r);
					in.close();
					return new String(bo.toByteArray(), "UTF-8");
				} catch (Exception e) {
					if (statusOut != null) statusOut[0] = -1;
					e.printStackTrace();
					return null;
				} finally {
					if (c != null) c.disconnect();
				}
			}
			
			boolean isOwnHost(String urlStr) {
				try {
					String h = new java.net.URL(urlStr).getHost();
					return h != null && h.equalsIgnoreCase(ASSET_BASE_HOST);
				} catch (Exception e) {
					return false;
				}
			}
			
			boolean isMediaExt(String c) {
				return c.endsWith(".mp4") || c.endsWith(".webm") || c.endsWith(".ogg") || c.endsWith(".mp3")
				|| c.endsWith(".wav") || c.endsWith(".mov") || c.endsWith(".avi") || c.endsWith(".mkv") || c.endsWith(".m4a");
			}
			
			// نفس شرط فرع الصور في shouldInterceptRequest (مصدر واحد للحقيقة)
			// === [إصلاح 1] قائمة امتدادات الصور الموسّعة (كانت JPG/JPEG/PNG/WEBP/GIF/SVG فقط) ===
			boolean isImageExt(String c) {
				return c.endsWith(".jpg") || c.endsWith(".jpeg") || c.endsWith(".jfif") || c.endsWith(".png") || c.endsWith(".apng")
				|| c.endsWith(".webp") || c.endsWith(".gif") || c.endsWith(".svg") || c.endsWith(".avif")
				|| c.endsWith(".bmp") || c.endsWith(".ico");
			}
			
			// MIME حسب الامتداد (null لو الامتداد غير معروف)
			String mimeForImageExt(String c) {
				if (c.endsWith(".png") || c.endsWith(".apng")) return "image/png";
				if (c.endsWith(".gif")) return "image/gif";
				if (c.endsWith(".webp")) return "image/webp";
				if (c.endsWith(".svg")) return "image/svg+xml";
				if (c.endsWith(".avif")) return "image/avif";
				if (c.endsWith(".bmp")) return "image/bmp";
				if (c.endsWith(".ico")) return "image/x-icon";
				if (c.endsWith(".jpg") || c.endsWith(".jpeg") || c.endsWith(".jfif")) return "image/jpeg";
				return null;
			}
			
			boolean isImageUrl(String lowerUrl, String c) {
				return isImageExt(c)
				|| lowerUrl.contains("/image") || lowerUrl.contains("/images") || lowerUrl.contains("giphy")
				|| lowerUrl.contains("unsplash") || lowerUrl.contains("picsum") || lowerUrl.contains("pexels")
				|| lowerUrl.contains("pixabay") || lowerUrl.contains("pxhere") || lowerUrl.contains("cloudinary");
			}
			
			// نفس شرط فرع المكتبات والخطوط
			boolean isStaticUrl(String lowerUrl, String c) {
				return c.endsWith(".ttf") || c.endsWith(".woff") || c.endsWith(".woff2")
				|| c.endsWith(".js") || c.endsWith(".css") || c.endsWith(".eot")
				|| c.endsWith(".mjs") || c.endsWith(".otf") || c.endsWith(".wasm")
				|| lowerUrl.contains("esm.sh") || lowerUrl.contains("skypack") || lowerUrl.contains("jspm")
				|| lowerUrl.contains("gstatic") || lowerUrl.contains("typekit") || lowerUrl.contains("polyfill")
				|| lowerUrl.contains("font") || lowerUrl.contains("cdn") || lowerUrl.contains("unpkg")
				|| lowerUrl.contains("jsdelivr") || lowerUrl.contains("cdnjs") || lowerUrl.contains("bootstrap")
				|| lowerUrl.contains("lucide") || lowerUrl.contains("fontawesome");
			}
			
			String staticExt(String lowerUrl, String c) {
				if (c.endsWith(".woff2") || lowerUrl.contains(".woff2") || lowerUrl.contains("woff2")) return ".woff2";
				if (c.endsWith(".woff") || lowerUrl.contains(".woff") || lowerUrl.contains("woff")) return ".woff";
				if (c.endsWith(".ttf") || lowerUrl.contains(".ttf")) return ".ttf";
				if (c.endsWith(".eot") || lowerUrl.contains(".eot")) return ".eot";
				if (c.endsWith(".js") || lowerUrl.contains(".js") || lowerUrl.contains("lucide")) return ".js";
				return ".css";
			}
			
			String staticMime(String ext) {
				if (ext.equals(".woff2")) return "font/woff2";
				if (ext.equals(".woff")) return "font/woff";
				if (ext.equals(".ttf")) return "font/ttf";
				if (ext.equals(".eot")) return "application/vnd.ms-fontobject";
				if (ext.equals(".js")) return "application/javascript";
				return "text/css";
			}
			
			// نوع الصورة: من رد الخادم (بدون ; charset) وإلا تخمين من الامتداد
			// === [إصلاح 6] الامتداد المعروف يحدد النوع أولاً (فلا يفسد SVG لو أرسله الخادم text/plain)،
			//     ثم Content-Type لو كان image/*، وإلا تخمين jpeg ===
			String imageMime(String ct, String lowerUrl, String c) {
				String byExt = mimeForImageExt(c);
				if (byExt != null) return byExt;
				if (ct != null) {
					String m = ct.split(";")[0].trim().toLowerCase(java.util.Locale.US);
					if (m.startsWith("image/")) return m;
				}
				if (lowerUrl.contains(".gif")) return "image/gif";
				return "image/jpeg";
			}
		}
		String defaultUa = "";
		try { defaultUa = android.webkit.WebSettings.getDefaultUserAgent(MainActivity.this); } catch (Exception uaEx) { defaultUa = ""; }
		final SafeIO safeIO = new SafeIO(defaultUa);
		
		// === [حالة مشتركة لإصلاح 7 و8] ===
		// appBlockedByStatus: true عندما تكون شاشة الإغلاق/الصيانة معروضة (فلا تستبدلها أي عملية تحميل أخرى)
		final boolean[] appBlockedByStatus = new boolean[1];
		// نافذة التقدم الحالية للتحديث، حتى نغلقها لو ظهرت شاشة الإغلاق أثناء التحديث
		final android.app.ProgressDialog[] activeProgressDialog = new android.app.ProgressDialog[1];
		// رابط الصفحة المطلوبة عند فتح التطبيق من إشعار الوسائط (يُقرأ مرة واحدة هنا ويُطبَّق بعد بدء التحميل الأساسي)
		final String[] pendingNotificationUrl = new String[1];
		{
			String notifTarget = getIntent() != null ? getIntent().getStringExtra("target_page_url") : null;
			if (notifTarget != null && notifTarget.length() > 0) pendingNotificationUrl[0] = notifTarget;
			// RosTrick: إشعار Firebase يطلب فتح صفحة من صفحات التطبيق (rt_page = اسم الملف، مثل about.html)
			try {
				String rtPage = getIntent() != null ? getIntent().getStringExtra("rt_page") : null;
				if (rtPage != null && rtPage.length() > 0 && rtPage.length() < 160 && rtPage.indexOf('/') < 0 && rtPage.indexOf('\\') < 0 && rtPage.indexOf("..") < 0) {
					java.io.File rtPageFile = new java.io.File(getApplicationContext().getFilesDir(), rtPage);
					if (rtPageFile.exists()) pendingNotificationUrl[0] = "file://" + rtPageFile.getAbsolutePath();
				}
			} catch (Throwable ignored) {}
			// RosTrick: رابط عميق فُتح به التطبيق من الصفر (rt_link من SplashActivity)
			try {
				String rtLink = getIntent() != null ? getIntent().getStringExtra("rt_link") : null;
				if (rtLink != null && rtLink.length() > 0 && rtLink.length() <= 2048) {
					rtLastLink = rtLink;
					String pg = rtLinkPageFile(rtLink);
					if (pg != null) pendingNotificationUrl[0] = pg;
				}
			} catch (Throwable ignored) {}
		}
		
		// 🔴 دالة عرض واجهة الصيانة أو الإغلاق التام بتصاميم تناسب JSON الخاص بك مع كافة الإضافات
		final Runnable displayAppStatusScreen = new Runnable() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						try {
							String baseLocalPath = MainActivity.this.getApplicationContext().getFilesDir().getAbsolutePath() + "/";
							java.io.File statusFile = new java.io.File(baseLocalPath + "app_status.json");
							if (!statusFile.exists() || statusFile.length() == 0) return;
							
							// === [إصلاح 8] نعلّم أن شاشة الإغلاق معروضة، ونغلق نافذة التحديث إن كانت ظاهرة فوقها ===
							appBlockedByStatus[0] = true;
							try {
								if (activeProgressDialog[0] != null && activeProgressDialog[0].isShowing()) activeProgressDialog[0].dismiss();
							} catch (Exception ignore) {}
							
							java.io.FileInputStream fis = new java.io.FileInputStream(statusFile);
							java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(fis, "UTF-8"));
							StringBuilder sb = new StringBuilder();
							String line;
							while ((line = reader.readLine()) != null) sb.append(line);
							reader.close();
							fis.close();
							
							org.json.JSONObject json = new org.json.JSONObject(sb.toString());
							boolean isClosed = json.optBoolean("is_closed", false);
							boolean isMaintenance = json.optBoolean("is_maintenance", false);
							
							java.io.File closedFile = new java.io.File(baseLocalPath + "Closed.html");
							java.io.File maintenanceFile = new java.io.File(baseLocalPath + "Maintenance.html");
							
							if (isClosed) {
								if (closedFile.exists() && closedFile.length() > 0) {
									dynamicWebView.loadUrl("file://" + closedFile.getAbsolutePath());
								} else {
									// --- استقبال البيانات الإضافية للحالة: مغلق ---
									String icon = "🚫";
									String statusLabel = RtI18n.t("التطبيق مغلق", "App closed");
									String badgeBg = "#ef4444";
									String title = json.optString("close_title", RtI18n.t("التطبيق متوقف حالياً", "The app is currently unavailable"));
									String message = json.optString("close_message", RtI18n.t("تم إغلاق التطبيق.", "The app has been closed."));
									
									// الإضافات المخصصة
									String logoUrl = json.optString("logo_url", "");
									String btnText = json.optString("btn_text", "");
									String btnUrl = json.optString("btn_url", "");
									String endTime = json.optString("end_time", "");
									
									String htmlContent = buildStatusPageHtml(icon, statusLabel, badgeBg, title, message, logoUrl, btnText, btnUrl, endTime);
									dynamicWebView.loadDataWithBaseURL(null, zoomInjector.inject(htmlContent), "text/html", "UTF-8", null);
								}
							} else if (isMaintenance) {
								if (maintenanceFile.exists() && maintenanceFile.length() > 0) {
									dynamicWebView.loadUrl("file://" + maintenanceFile.getAbsolutePath());
								} else {
									// --- استقبال البيانات الإضافية للحالة: صيانة ---
									String icon = "🛠️";
									String statusLabel = RtI18n.t("وضع الصيانة", "Maintenance mode");
									String badgeBg = "#f59e0b";
									String title = json.optString("maintenance_title", RtI18n.t("تطبيق تحت الصيانة", "App under maintenance"));
									String message = json.optString("maintenance_message", RtI18n.t("سنعود قريباً!", "We will be back soon!"));
									
									// الإضافات المخصصة
									String logoUrl = json.optString("logo_url", "");
									String btnText = json.optString("btn_text", "");
									String btnUrl = json.optString("btn_url", "");
									String endTime = json.optString("end_time", "");
									
									String htmlContent = buildStatusPageHtml(icon, statusLabel, badgeBg, title, message, logoUrl, btnText, btnUrl, endTime);
									dynamicWebView.loadDataWithBaseURL(null, zoomInjector.inject(htmlContent), "text/html", "UTF-8", null);
								}
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				});
			}
			
			// دالة مساعدة لبناء واجهة innerHTML الشاملة لجميع البيانات المخصصة
			private String buildStatusPageHtml(String icon, String badgeText, String badgeBg, String title, String message, String logoUrl, String btnText, String btnUrl, String endTime) {
				
				String logoHtml = "";
				if (logoUrl != null && !logoUrl.trim().isEmpty()) {
					logoHtml = "<img src='" + logoUrl.trim() + "' class='app-logo' alt='Logo' />";
				}
				
				String btnHtml = "";
				if (btnText != null && !btnText.trim().isEmpty() && btnUrl != null && !btnUrl.trim().isEmpty()) {
					btnHtml = "<a href='" + btnUrl.trim() + "' class='action-btn'>" + btnText.trim() + "</a>";
				}
				
				String timerHtml = "";
				String timerScript = "";
				if (endTime != null && !endTime.trim().isEmpty()) {
					timerHtml = "<div id='timer-container' class='timer-box'>"
					+ "  <div class='time-unit'><span id='days'>00</span><label>" + RtI18n.t("يوم", "Days") + "</label></div>"
					+ "  <div class='time-unit'><span id='hours'>00</span><label>" + RtI18n.t("ساعة", "Hours") + "</label></div>"
					+ "  <div class='time-unit'><span id='minutes'>00</span><label>" + RtI18n.t("دقيقة", "Min") + "</label></div>"
					+ "  <div class='time-unit'><span id='seconds'>00</span><label>" + RtI18n.t("ثانية", "Sec") + "</label></div>"
					+ "</div>";
					
					timerScript = "<script>"
					+ "  var targetDate = new Date('" + endTime.trim() + "').getTime();"
					+ "  if(!isNaN(targetDate)){"
					+ "    var x = setInterval(function() {"
					+ "      var now = new Date().getTime();"
					+ "      var distance = targetDate - now;"
					+ "      if (distance < 0) {"
					+ "        clearInterval(x);"
					+ "        document.getElementById('timer-container').innerHTML = '<div style=\"color:#10b981;font-weight:bold;\">" + RtI18n.t("انتهت المدة المحددة!", "The set time has ended!") + "</div>';"
					+ "        return;"
					+ "      }"
					+ "      document.getElementById('days').innerText = Math.floor(distance / (1000 * 60 * 60 * 24));"
					+ "      document.getElementById('hours').innerText = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));"
					+ "      document.getElementById('minutes').innerText = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));"
					+ "      document.getElementById('seconds').innerText = Math.floor((distance % (1000 * 60)) / 1000);"
					+ "    }, 1000);"
					+ "  }"
					+ "</script>";
				}
				
				return "<!DOCTYPE html><html dir='" + (RtI18n.en() ? "ltr" : "rtl") + "' lang='" + (RtI18n.en() ? "en" : "ar") + "'><head><meta charset='UTF-8'><meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no'>"
				+ "<style>"
				+ "body { margin: 0; padding: 20px; display: flex; justify-content: center; align-items: center; min-height: 100vh; background-color: #0f172a; font-family: system-ui, -apple-system, sans-serif; color: #f8fafc; text-align: center; box-sizing: border-box; }"
				+ ".card { background: #1e293b; padding: 30px 20px; border-radius: 20px; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.5); width: 100%; max-width: 400px; border: 1px solid #334155; display: flex; flex-direction: column; align-items: center; }"
				+ ".app-logo { max-width: 90px; max-height: 90px; margin-bottom: 15px; border-radius: 16px; object-fit: contain; }"
				+ ".icon { font-size: 50px; margin-bottom: 12px; }"
				+ ".badge { display: inline-block; background-color: " + badgeBg + "; color: #ffffff; font-size: 13px; font-weight: bold; padding: 5px 14px; border-radius: 50px; margin-bottom: 15px; }"
				+ "h2 { margin: 0 0 10px 0; font-size: 20px; color: #ffffff; font-weight: 700; }"
				+ "p { margin: 0 0 15px 0; font-size: 14px; color: #94a3b8; line-height: 1.6; word-wrap: break-word; }"
				+ ".action-btn { display: inline-block; width: 80%; margin-top: 15px; padding: 12px 20px; background-color: #3b82f6; color: #ffffff; font-weight: bold; font-size: 15px; text-decoration: none; border-radius: 12px; transition: background 0.3s; }"
				+ ".timer-box { display: flex; justify-content: center; gap: 8px; margin-top: 15px; width: 100%; }"
				+ ".time-unit { background: #0f172a; padding: 8px; border-radius: 10px; border: 1px solid #334155; min-width: 55px; }"
				+ ".time-unit span { display: block; font-size: 18px; font-weight: bold; color: #38bdf8; }"
				+ ".time-unit label { font-size: 10px; color: #64748b; }"
				+ "</style></head><body>"
				+ "<div class='card'>"
				+ logoHtml
				+ (logoHtml.isEmpty() ? "<div class='icon'>" + icon + "</div>" : "")
				+ "<div class='badge'>" + badgeText + "</div>"
				+ "<h2>" + title + "</h2>"
				+ "<p>" + message + "</p>"
				+ timerHtml
				+ btnHtml
				+ "</div>"
				+ timerScript
				+ "</body></html>";
			}
		};
		
		// 🔴 نسخة افتراضية مضمّنة من صفحة 404 (تُستخدم فقط إذا لم يوجد 404.html في filesDir - لا علاقة لها بـ assets إطلاقاً)
		final String default404Html =
		"<!DOCTYPE html>"
		+ "<html lang=\"" + (RtI18n.en() ? "en" : "ar") + "\" dir=\"" + (RtI18n.en() ? "ltr" : "rtl") + "\">"
		+ "<head>"
		+ "<meta charset=\"UTF-8\">"
		+ "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, user-scalable=no, maximum-scale=1.0\">"
		+ "<title>" + RtI18n.t("الصفحة غير موجودة", "Page not found") + "</title>"
		+ "<style>"
		+ ":root{--bg-color:#f5f5f5;--text-main:#171717;--text-sub:#737373;--primary:#171717;--primary-hover:#000000;--on-primary:#ffffff;--card-bg:#ffffff;--icon-bg:#ececec;}"
		+ "@media (prefers-color-scheme: dark){:root{--bg-color:#000000;--text-main:#fafafa;--text-sub:#a3a3a3;--primary:#ffffff;--primary-hover:#e5e5e5;--on-primary:#000000;--card-bg:#111111;--icon-bg:#262626;}}"
		+ "*{box-sizing:border-box;margin:0;padding:0;user-select:none;-webkit-tap-highlight-color:transparent;}"
		+ "body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;background-color:var(--bg-color);color:var(--text-main);height:100vh;display:flex;justify-content:center;align-items:center;padding:20px;overflow:hidden;}"
		+ ".container{text-align:center;max-width:360px;width:100%;background-color:var(--card-bg);padding:32px 24px;border-radius:24px;box-shadow:0 10px 25px -5px rgba(0,0,0,0.05);animation:fadeIn 0.4s ease-out;}"
		+ ".icon-box{width:90px;height:90px;background-color:var(--icon-bg);border-radius:50%;display:flex;justify-content:center;align-items:center;margin:0 auto 20px;}"
		+ ".icon-box svg{width:48px;height:48px;fill:var(--primary);}"
		+ ".error-code{font-size:14px;font-weight:700;color:var(--primary);letter-spacing:1px;margin-bottom:8px;text-transform:uppercase;}"
		+ "h1{font-size:20px;font-weight:700;margin-bottom:8px;}"
		+ "p{font-size:14px;color:var(--text-sub);line-height:1.5;margin-bottom:24px;}"
		+ ".btn-group{display:flex;flex-direction:column;gap:10px;}"
		+ ".btn{width:100%;padding:12px 16px;border-radius:12px;font-size:14px;font-weight:600;border:none;cursor:pointer;transition:background-color 0.2s, transform 0.1s;}"
		+ ".btn:active{transform:scale(0.98);}"
		+ ".btn-primary{background-color:var(--primary);color:var(--on-primary);}"
		+ ".btn-secondary{background-color:transparent;color:var(--text-sub);}"
		+ ".btn-gray{background-color:#e5e5e5;color:#404040;}"
		+ "@media (prefers-color-scheme: dark){.btn-gray{background-color:#262626;color:#e5e5e5;}}"
		+ ".info-box{max-height:0;overflow:hidden;opacity:0;margin-top:0;border-radius:12px;transition:max-height 0.3s ease, opacity 0.3s ease, margin-top 0.3s ease, padding 0.3s ease;text-align:start;}"
		+ ".info-box.show{max-height:220px;opacity:1;margin-top:12px;padding:14px 16px;background-color:var(--icon-bg);}"
		+ ".info-box p{font-size:13px;color:var(--text-main);line-height:1.7;margin-bottom:0;}"
		+ "@keyframes fadeIn{from{opacity:0;transform:translateY(12px);}to{opacity:1;transform:translateY(0);}}"
		+ "</style>"
		+ "</head>"
		+ "<body>"
		+ "<div class=\"container\">"
		+ "<div class=\"icon-box\">"
		+ "<svg viewBox=\"0 0 24 24\"><path d=\"M11 15h2v2h-2zm0-8h2v6h-2zm1-5C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z\"/></svg>"
		+ "</div>"
		+ "<div class=\"error-code\">" + RtI18n.t("تعذّر الوصول", "Unable to reach") + "</div>"
		+ "<h1>" + RtI18n.t("الصفحة غير موجودة", "Page not found") + "</h1>"
		+ "<p>" + RtI18n.t("الصفحة التي تحاول الوصول إليها غير متوفرة حالياً.", "The page you are trying to reach is currently unavailable.") + "</p>"
		+ "<div class=\"btn-group\">"
		+ "<button class=\"btn btn-primary\" onclick=\"goHome()\">" + RtI18n.t("الرجوع للرئيسية", "Back to home") + "</button>"
		+ "<button class=\"btn btn-gray\" onclick=\"toggleInfo()\">" + RtI18n.t("معلومات أكثر", "More info") + "</button>"
		+ "</div>"
		+ "<div class=\"info-box\" id=\"infoBox\">"
		+ "<p>" + RtI18n.t("هذه المشكلة قد تحدث لعدة أسباب: هذه الصفحة تمت إزالتها أو استبدالها في نسخة أحدث من التطبيق، أو أن الملف الذي يحاول التطبيق فتحه تالف أو غير مكتمل. من الممكن أيضاً أن يكون لديك نسخة قديمة من بيانات التطبيق محفوظة على جهازك ولم تُحدَّث بشكل صحيح. إذا استمرت المشكلة معك، جرّب حذف بيانات التطبيق من إعدادات جهازك ثم افتحه من جديد.", "This problem can happen for several reasons: this page was removed or replaced in a newer version of the app, or the file the app is trying to open is damaged or incomplete. You may also have an old copy of the app data on your device that was not updated correctly. If the problem continues, try clearing the app data from your device settings and then open it again.") + "</p>"
		+ "</div>"
		+ "</div>"
		+ "<script>"
		+ "function goHome(){"
		+ "  try{"
		+ "    if (typeof Android !== 'undefined' && Android.openLocalPage) {"
		+ "      Android.openLocalPage('home.html');"
		+ "    } else {"
		+ "      window.location.href = 'home.html';"
		+ "    }"
		+ "  } catch(e) {}"
		+ "}"
		+ "function toggleInfo(){ document.getElementById('infoBox').classList.toggle('show'); }"
		+ "</script>"
		+ "</body></html>";
		
		// 🔴 دالة التوجيه لصفحة 404
		// === [مُعدَّل] تبحث فقط داخل filesDir، وإن لم توجد هناك تعرض النسخة الافتراضية المضمّنة أعلاه
		// لم تعد تستدعي 404.html من assets نهائياً بأي شكل ===
		final Runnable load404Page = new Runnable() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						String baseLocalPath = MainActivity.this.getApplicationContext().getFilesDir().getAbsolutePath() + "/";
						java.io.File file404 = new java.io.File(baseLocalPath + "404.html");
						
						if (file404.exists() && file404.length() > 0) {
							dynamicWebView.loadUrl("file://" + baseLocalPath + "404.html");
						} else {
							dynamicWebView.loadDataWithBaseURL(null, zoomInjector.inject(default404Html), "text/html", "UTF-8", null);
						}
					}
				});
			}
		};
		
		dynamicWebView.addJavascriptInterface(new Object() {
			@android.webkit.JavascriptInterface
			public String readLocalFile(final String fileName) {
				if (fileName == null) return "";
				try {
					String baseLocalPath = MainActivity.this.getApplicationContext().getFilesDir().getAbsolutePath() + "/";
					java.io.File file = new java.io.File(baseLocalPath + fileName.trim());
					if (file.exists() && file.length() > 0) {
						java.io.FileInputStream fis = new java.io.FileInputStream(file);
						java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(fis, "UTF-8"));
						java.lang.StringBuilder sb = new java.lang.StringBuilder();
						String line;
						while ((line = reader.readLine()) != null) {
							sb.append(line).append("\n");
						}
						reader.close();
						fis.close();
						return sb.toString();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				return "";
			}
			
			// === [جديد] بدل تشغيل الفيديو/الصوت عبر اعتراض يدوي للطلبات (shouldInterceptRequest + Range يدوي)
			// نرجّع مسار file:// حقيقي للملف المحلي لو موجود، عشان الـ <video>/<audio> tag يشتغل بمشغّل النظام
			// الطبيعي مباشرة (نفس ما لو كان ملف محلي 100% من الأساس) - ده بيدّي seek/range دعم كامل تلقائياً
			// من نظام أندرويد نفسه، بدل الاعتماد على منطق Range مكتوب يدوياً ومعرّض للأخطاء ===
			@android.webkit.JavascriptInterface
			public String getLocalMediaFileUri(final String remoteUrl) {
				try {
					if (remoteUrl == null || remoteUrl.trim().isEmpty()) return "";
					// أصلاً محلي أو data: - مفيش داعي للتحويل
					if (remoteUrl.startsWith("file://") || remoteUrl.startsWith("data:") || remoteUrl.startsWith("blob:")) return "";
					
					String lowerUrl = remoteUrl.toLowerCase();
					String cleanUrlForExt = lowerUrl.split("\\?")[0].split("#")[0];
					
					String ext = null;
					if (cleanUrlForExt.endsWith(".mp4")) ext = ".mp4";
					else if (cleanUrlForExt.endsWith(".webm")) ext = ".webm";
					else if (cleanUrlForExt.endsWith(".ogg")) ext = ".ogg";
					else if (cleanUrlForExt.endsWith(".mp3")) ext = ".mp3";
					else if (cleanUrlForExt.endsWith(".wav")) ext = ".wav";
					else if (cleanUrlForExt.endsWith(".mov")) ext = ".mov";
					else if (cleanUrlForExt.endsWith(".avi")) ext = ".avi";
					else if (cleanUrlForExt.endsWith(".mkv")) ext = ".mkv";
					else if (cleanUrlForExt.endsWith(".m4a")) ext = ".m4a";
					if (ext == null) return "";
					
					// === [مُعدَّل] نفس آلية تسمية الصور/الملفات الثابتة تمامًا: اسم مبني على hash الرابط الكامل
					// بدل اسم الملف الأصلي - يتفادى تصادم الأسماء، ولازم يطابق نفس اسم الحفظ في خدمة التحميل ===
					String fileName = "media_" + Math.abs(remoteUrl.hashCode()) + ext;
					
					String baseLocalPath = MainActivity.this.getApplicationContext().getFilesDir().getAbsolutePath() + "/";
					java.io.File localFile = new java.io.File(baseLocalPath + fileName);
					
					if (localFile.exists() && localFile.length() > 0) {
						return "file://" + localFile.getAbsolutePath();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				return "";
			}
			
			// === [جديد] يُستدعى من سكربت القفل: يفتح/يقفل الـ zoom على مستوى الـ WebView حسب الصفحة الحالية (opt-in عبر allow-zoom) ===
			@android.webkit.JavascriptInterface
			public void setZoomAllowed(final boolean allowed) {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						dynamicWebView.getSettings().setSupportZoom(allowed);
						dynamicWebView.getSettings().setBuiltInZoomControls(allowed);
						dynamicWebView.getSettings().setDisplayZoomControls(false);
					}
				});
			}
			
			@android.webkit.JavascriptInterface
			public void callAndroidBlock(final String message) {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						if (message != null) {
							String trimmed = message.trim();
							if (trimmed.startsWith("{") || trimmed.startsWith("[") || trimmed.contains("students") || trimmed.startsWith("data:")) {
								return;
							}
							SketchwareUtil.showMessage(getApplicationContext(), message);
						}
					}
				});
			}
			
			@android.webkit.JavascriptInterface
			public void openLocalPage(final String fileName) {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						if (fileName != null) {
							String cleanName = fileName.trim();
							String baseLocalPath = MainActivity.this.getApplicationContext().getFilesDir().getAbsolutePath() + "/";
							java.io.File targetFile = new java.io.File(baseLocalPath + cleanName);
							
							if (targetFile.exists() && targetFile.length() > 0) {
								dynamicWebView.loadUrl("file://" + baseLocalPath + cleanName);
							} else {
								copyAssetToLocal(cleanName, baseLocalPath + cleanName);
								java.io.File copiedFile = new java.io.File(baseLocalPath + cleanName);
								if (copiedFile.exists() && copiedFile.length() > 0) {
									dynamicWebView.loadUrl("file://" + baseLocalPath + cleanName);
								} else {
									load404Page.run();
								}
							}
						}
					}
				});
			}
			
			// === [إضافة] تحميل ملف من مجلد assets ونسخه فعلياً إلى مجلد Downloads ===
			@android.webkit.JavascriptInterface
			public void downloadAssetFile(final String fileName) {
				// === [إصلاح] النسخ كان يتم على الـ UI thread (تجميد/ANR مع الملفات الكبيرة) وبدون إغلاق الـ streams عند الخطأ.
				//     الآن في خيط خلفي، مع حذف الإدخال الناقص من MediaStore عند الفشل ===
				new Thread(new Runnable() {
					@Override
					public void run() {
						java.io.InputStream inputStream = null;
						java.io.OutputStream outputStream = null;
						android.net.Uri createdUri = null;
						boolean success = false;
						try {
							inputStream = MainActivity.this.getAssets().open(fileName);
							
							String assetMimeType = "application/octet-stream";
							String lowerAssetName = fileName.toLowerCase();
							if (lowerAssetName.endsWith(".apk")) assetMimeType = "application/vnd.android.package-archive";
							else if (lowerAssetName.endsWith(".pdf")) assetMimeType = "application/pdf";
							else if (lowerAssetName.endsWith(".zip")) assetMimeType = "application/zip";
							
							if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
								android.content.ContentValues values = new android.content.ContentValues();
								values.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, fileName);
								values.put(android.provider.MediaStore.MediaColumns.MIME_TYPE, assetMimeType);
								values.put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS);
								createdUri = MainActivity.this.getContentResolver().insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
								if (createdUri != null) {
									outputStream = MainActivity.this.getContentResolver().openOutputStream(createdUri);
								}
							} else {
								java.io.File downloadsFolder = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS);
								if (!downloadsFolder.exists()) downloadsFolder.mkdirs();
								outputStream = new java.io.FileOutputStream(new java.io.File(downloadsFolder, fileName));
							}
							
							if (outputStream == null) {
								toast(RtI18n.t("❌ فشل حفظ الملف في مجلد Downloads", "❌ Failed to save the file to Downloads"));
							} else {
								byte[] buffer = new byte[8192];
								int length;
								while ((length = inputStream.read(buffer)) > 0) {
									outputStream.write(buffer, 0, length);
								}
								outputStream.flush();
								outputStream.close();
								outputStream = null;
								success = true;
								toast(RtI18n.t("✅ تم حفظ الملف بنجاح في مجلد Downloads: ", "✅ File saved successfully to Downloads: ") + fileName);
							}
						} catch (Exception e) {
							toast(RtI18n.t("❌ خطأ أثناء تحميل الملف: ", "❌ Error while downloading the file: ") + e.getMessage());
						} finally {
							try { if (inputStream != null) inputStream.close(); } catch (Exception ignore) {}
							try { if (outputStream != null) outputStream.close(); } catch (Exception ignore) {}
							if (!success && createdUri != null) {
								try { MainActivity.this.getContentResolver().delete(createdUri, null, null); } catch (Exception ignore) {}
							}
						}
					}
				}).start();
			}
			
			// إظهار Toast بأمان من أي خيط
			private void toast(final String msg) {
				runOnUiThread(new Runnable() {
					@Override
					public void run() { SketchwareUtil.showMessage(getApplicationContext(), msg); }
				});
			}
			
			// === [إضافة جديدة] استقبال روابط الفيديو/الصوت المكتشفة بالصفحة، وعرض نافذة تحميل جماعي بالحجم الكلي ===
			@android.webkit.JavascriptInterface
			public void reportMediaFiles(final String jsonArray, final String pageUrl) {
				if (jsonArray == null || jsonArray.trim().isEmpty()) return;
				if (hasShownMediaAlert[0]) return; // مرة وحدة بس لكل صفحة (يُعاد ضبطها بـ onPageStarted)
				hasShownMediaAlert[0] = true;
				
				// === [إضافة جديدة] احترام خيار RtI18n.t("لا تظهر لمدة 30 يوم", "Do not show for 30 days") لو المستخدم فعّله سابقاً
				android.content.SharedPreferences mediaDialogPrefs = MainActivity.this.getSharedPreferences("media_dialog_pref", android.content.Context.MODE_PRIVATE);
				long snoozeUntil = mediaDialogPrefs.getLong("snooze_until", 0);
				if (System.currentTimeMillis() < snoozeUntil) return;
				
				new Thread(new Runnable() {
					@Override
					public void run() {
						final java.util.ArrayList<String> mediaUrls = new java.util.ArrayList<>();
						// === [إصلاح] تحليل JSON حقيقي بدل split(",") (الروابط التي فيها فاصلة كانت تتكسر) ===
						try {
							org.json.JSONArray urlsArray = new org.json.JSONArray(jsonArray);
							for (int i = 0; i < urlsArray.length(); i++) {
								String cleaned = urlsArray.optString(i, "").trim();
								if ((cleaned.startsWith("http://") || cleaned.startsWith("https://")) && !mediaUrls.contains(cleaned)) {
									mediaUrls.add(cleaned);
								}
							}
						} catch (Exception e) { e.printStackTrace(); }
						
						if (mediaUrls.isEmpty()) return;
						
						// === [إضافة جديدة] استبعاد أي ملف محمّل مسبقاً بالتخزين المحلي (filesDir) - نفس منطق تسمية الملفات المستخدم بالتحميل
						final String baseLocalPath = MainActivity.this.getApplicationContext().getFilesDir().getAbsolutePath() + "/";
						final java.util.ArrayList<String> missingUrls = new java.util.ArrayList<>();
						
						for (String mediaUrl : mediaUrls) {
							// === [مُعدَّل] نفس اسم hash المستخدم في getLocalMediaFileUri وshouldInterceptRequest بالأسفل ===
							String lowerMediaUrl = mediaUrl.toLowerCase();
							String cleanUrlForExt = lowerMediaUrl.split("\\?")[0].split("#")[0];
							
							String ext = null;
							if (cleanUrlForExt.endsWith(".mp4")) ext = ".mp4";
							else if (cleanUrlForExt.endsWith(".webm")) ext = ".webm";
							else if (cleanUrlForExt.endsWith(".ogg")) ext = ".ogg";
							else if (cleanUrlForExt.endsWith(".mp3")) ext = ".mp3";
							else if (cleanUrlForExt.endsWith(".wav")) ext = ".wav";
							else if (cleanUrlForExt.endsWith(".mov")) ext = ".mov";
							else if (cleanUrlForExt.endsWith(".avi")) ext = ".avi";
							else if (cleanUrlForExt.endsWith(".mkv")) ext = ".mkv";
							else if (cleanUrlForExt.endsWith(".m4a")) ext = ".m4a";
							
							if (ext == null) {
								missingUrls.add(mediaUrl); // امتداد غير معروف - يمر للفحص العادي (HEAD) بالأسفل
								continue;
							}
							
							String fileName = "media_" + Math.abs(mediaUrl.hashCode()) + ext;
							java.io.File existingFile = new java.io.File(baseLocalPath + fileName);
							if (!existingFile.exists() || existingFile.length() <= 0) {
								missingUrls.add(mediaUrl);
							}
						}
						
						if (missingUrls.isEmpty()) return; // كل الملفات محمّلة مسبقاً - لا داعي لإزعاج المستخدم بنفس النافذة مرة ثانية
						
						final java.util.ArrayList<String> validUrls = new java.util.ArrayList<>();
						final java.util.ArrayList<Long> sizes = new java.util.ArrayList<>();
						long totalBytes = 0;
						
						for (String mediaUrl : missingUrls) {
							long len = probeMediaSize(mediaUrl, pageUrl);
							if (len > 0) {
								validUrls.add(mediaUrl);
								sizes.add(len);
								totalBytes += len;
							}
						}
						
						if (validUrls.isEmpty()) return;
						
						final long finalTotalBytes = totalBytes;
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								// === [إصلاح كراش] لو المستخدم غادر/أغلق الشاشة قبل ما ينتهي فحص الملفات (اللي يصير بخيط منفصل ومهلته قد تطول)،
								// لا تحاول تعرض أي نافذة، لأن نافذة الـ Activity تكون غير صالحة فيصير كراش BadTokenException
								boolean activityStillValid = !MainActivity.this.isFinishing();
								if (activityStillValid && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN_MR1) {
									activityStillValid = !MainActivity.this.isDestroyed();
								}
								if (!activityStillValid) return;
								
								showMediaDownloadDialog(validUrls, sizes, finalTotalBytes, pageUrl);
							}
						});
					}
				}).start();
			}
			
			private String formatFileSize(long bytes) {
				if (bytes < 1024) return bytes + " B";
				if (bytes < 1024 * 1024) return String.format(java.util.Locale.US, "%.1f KB", bytes / 1024.0);
				if (bytes < 1024 * 1024 * 1024) return String.format(java.util.Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0));
				return String.format(java.util.Locale.US, "%.2f GB", bytes / (1024.0 * 1024.0 * 1024.0));
			}
			
			// === [إصلاح] getContentLengthLong() تحتاج API 24 (NoSuchMethodError غير ملتقط على الإصدارات الأقدم)،
			//     وبعض الخوادم ترفض HEAD أو لا ترجع الحجم، فنجرّب GET بنطاق بايت واحد ونقرأ الحجم الكلي من Content-Range ===
			private long probeMediaSize(String mediaUrl, String pageUrl) {
				long len = -1;
				java.net.HttpURLConnection conn = null;
				try {
					conn = safeIO.open(mediaUrl, 5000);
					conn.setRequestMethod("HEAD");
					if (pageUrl != null) conn.setRequestProperty("Referer", pageUrl);
					int code = conn.getResponseCode();
					if (code >= 200 && code < 300) len = conn.getContentLength();
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					if (conn != null) conn.disconnect();
				}
				if (len > 0) return len;
				
				conn = null;
				try {
					conn = safeIO.open(mediaUrl, 5000);
					conn.setRequestProperty("Range", "bytes=0-0");
					if (pageUrl != null) conn.setRequestProperty("Referer", pageUrl);
					int code = conn.getResponseCode();
					if (code == 206) {
						String cr = conn.getHeaderField("Content-Range");
						if (cr != null && cr.indexOf('/') != -1) {
							String total = cr.substring(cr.lastIndexOf('/') + 1).trim();
							if (!total.equals("*")) len = Long.parseLong(total);
						}
					} else if (code == 200) {
						len = conn.getContentLength();
					}
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					if (conn != null) conn.disconnect();
				}
				return len;
			}
			
			private void showMediaDownloadDialog(final java.util.ArrayList<String> urls, final java.util.ArrayList<Long> sizes, final long totalBytes, final String pageUrl) {
				// === [إصلاح كراش] فحص إضافي أخير قبل البناء والعرض مباشرة، كخط دفاع ثانٍ ضد أي تسابق توقيت (race condition)
				boolean activityStillValid = !MainActivity.this.isFinishing();
				if (activityStillValid && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN_MR1) {
					activityStillValid = !MainActivity.this.isDestroyed();
				}
				if (!activityStillValid) return;
				
				StringBuilder message = new StringBuilder();
				message.append(RtI18n.t("تحتوي هذه الصفحة على ", "This page contains ")).append(urls.size()).append(urls.size() == 1 ? RtI18n.t(" ملف وسائط (فيديو/صوت)", " media file (video/audio)") : RtI18n.t(" ملفات وسائط (فيديو/صوت)", " media files (video/audio)"));
				message.append(RtI18n.t("\nالحجم الكلي: ", "\nTotal size: ")).append(formatFileSize(totalBytes));
				message.append(RtI18n.t("\n\nلتشغيلها بدون اتصال بالإنترنت لاحقاً، يجب تحميلها الآن.", "\n\nTo play them offline later, they must be downloaded now."));
				
				try {
					new android.app.AlertDialog.Builder(MainActivity.this)
					.setTitle(RtI18n.t("تحميل الوسائط", "Download media"))
					.setMessage(message.toString())
					.setCancelable(true)
					.setPositiveButton(RtI18n.t("تحميل", "Download"), new android.content.DialogInterface.OnClickListener() {
						@Override
						public void onClick(android.content.DialogInterface dialog, int which) {
							downloadMediaGroup(urls, sizes, totalBytes, pageUrl);
						}
					})
					.setNegativeButton(RtI18n.t("لا شكراً", "No thanks"), null)
					.setNeutralButton(RtI18n.t("لا تظهر لمدة 30 يوم", "Do not show for 30 days"), new android.content.DialogInterface.OnClickListener() {
						@Override
						public void onClick(android.content.DialogInterface dialog, int which) {
							android.content.SharedPreferences mediaDialogPrefs = MainActivity.this.getSharedPreferences("media_dialog_pref", android.content.Context.MODE_PRIVATE);
							long snoozeUntil = System.currentTimeMillis() + (30L * 24 * 60 * 60 * 1000);
							mediaDialogPrefs.edit().putLong("snooze_until", snoozeUntil).apply();
						}
					})
					.show();
				} catch (Exception e) {
					// لو صار أي تسابق توقيت نادر رغم الفحص أعلاه (مثلاً الشاشة أُغلقت بنفس اللحظة)، نتجاهله بدل ما يكرش التطبيق
					e.printStackTrace();
				}
			}
			
			/* يحمّل كل روابط الميديا فعلياً كـ bytes خام إلى تخزين التطبيق الخاص (filesDir) - نفس مكان بقية أصول التطبيق،
       وليس مجلد Downloads العام - عشان الـ WebView يقدر يشغّلها لاحقاً بدون إنترنت عبر file:// */
			/* === تعديل: الآن تبدأ Foreground Service بدل تشغيل Thread داخل النشاط ===
       الفرق المهم: هذا الـ Thread القديم كان ينتهي فوراً لو أغلق المستخدم التطبيق (Swipe Away)،
       بينما الـ Service الجديد (MediaDownloadService) يستمر بالخلفية حتى لو أُغلق التطبيق بالكامل */
			private void downloadMediaGroup(final java.util.ArrayList<String> urls, final java.util.ArrayList<Long> expectedSizes, final long totalExpectedBytes, final String pageUrl) {
				android.content.Intent serviceIntent = new android.content.Intent(MainActivity.this, MediaDownloadService.class);
				serviceIntent.putStringArrayListExtra("urls", urls);
				serviceIntent.putExtra("total_bytes", totalExpectedBytes);
				serviceIntent.putExtra("page_url", pageUrl);
				
				// === [إصلاح] خدمة التنزيل صارت اختيارية (تُفعَّل من اللوحة): لو عُطِّلت، لن تكون معلَنة في
				// AndroidManifest.xml ومحاولة تشغيلها ترمي استثناءً. نحتوي هذا بدل ما يكرش التطبيق. ===
				try {
					if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
						MainActivity.this.startForegroundService(serviceIntent);
					} else {
						MainActivity.this.startService(serviceIntent);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			
			private void copyAssetToLocal(String assetName, String localPath) {
				// === [إصلاح] نسخ ذرّي: لو توقف النسخ في المنتصف لا يبقى ملف ناقص يُعتبر سليماً ===
				try {
					java.io.InputStream in = MainActivity.this.getAssets().open(assetName);
					safeIO.saveStream(in, new java.io.File(localPath), -1, false);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			// === [إصلاح] استقبال ملفات data: URI مع اسمها الحقيقي من خاصية download="..." بالـ HTML
			// (onDownloadStart ما يقدر يقرأ الاسم من data: أبداً لأن Content-Disposition خاص بالشبكة فقط،
			// فكان يطيح دايماً على backup.<ext> كحل احتياطي أخير) ===
			@android.webkit.JavascriptInterface
			public void downloadDataUri(final String rawData, final String mimeType, final String rawFileName, final boolean isBase64) {
				new Thread(new Runnable() {
					@Override
					public void run() {
						try {
							byte[] fileBytes;
							if (isBase64) {
								// === [إصلاح] تنظيف الـ base64 من أي مسافات أو أسطر زائدة قبل فك الترميز ===
								String cleanBase64 = rawData == null ? "" : rawData.trim().replaceAll("\\s", "");
								fileBytes = android.util.Base64.decode(cleanBase64, android.util.Base64.DEFAULT);
							} else {
								// === [إصلاح] data: غير مشفّر base64 (نص عادي URL-encoded مثل data:text/plain,Hello%20World)
								// فك ترميز الـ percent-encoding بدل تمريره غلطاً لـ Base64.decode ===
								String decodedText = android.net.Uri.decode(rawData == null ? "" : rawData);
								fileBytes = decodedText.getBytes("UTF-8");
							}
							
							String finalMimeType = (mimeType == null || mimeType.trim().isEmpty()) ? "application/octet-stream" : mimeType.trim();
							
							// === [إصلاح] تنظيف اسم الملف من الرموز الممنوعة في نظام الملفات/MediaStore ===
							String rawName = (rawFileName == null || rawFileName.trim().isEmpty()) ? "downloaded_file" : rawFileName.trim();
							String safeFileName = rawName.replaceAll("[/\\\\:*?\"<>|]", "_");
							
							// فصل الاسم عن الامتداد عشان نقدر نضيف رقم تسلسلي عند التعارض (مثال: file(1).pdf)
							String baseName = safeFileName;
							String extension = "";
							int dotIndex = safeFileName.lastIndexOf(".");
							if (dotIndex > 0 && dotIndex < safeFileName.length() - 1) {
								baseName = safeFileName.substring(0, dotIndex);
								extension = safeFileName.substring(dotIndex);
							}
							
							if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
								android.net.Uri externalUri = android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI;
								android.net.Uri fileUri = null;
								String attemptName = safeFileName;
								
								// === [إصلاح] لو الاسم موجود مسبقاً، insert() قد يرجع null أو يرمي استثناء
								// بدل ما يستبدل الملف -> نجرب أسماء بديلة (file(1).ext, file(2).ext...) ===
								for (int attempt = 0; attempt <= 20 && fileUri == null; attempt++) {
									if (attempt > 0) {
										attemptName = baseName + "(" + attempt + ")" + extension;
									}
									android.content.ContentValues values = new android.content.ContentValues();
									values.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, attemptName);
									values.put(android.provider.MediaStore.MediaColumns.MIME_TYPE, finalMimeType);
									values.put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS);
									try {
										fileUri = MainActivity.this.getContentResolver().insert(externalUri, values);
									} catch (Exception dupEx) {
										fileUri = null; // نجرب الاسم التالي
									}
								}
								
								if (fileUri != null) {
									try {
										java.io.OutputStream outputStream = MainActivity.this.getContentResolver().openOutputStream(fileUri);
										outputStream.write(fileBytes);
										outputStream.close();
									} catch (Exception writeEx) {
										// === [إصلاح] لا نترك ملفاً فارغاً/ناقصاً في Downloads عند فشل الكتابة ===
										try { MainActivity.this.getContentResolver().delete(fileUri, null, null); } catch (Exception ignore) {}
										throw writeEx;
									}
									toast(RtI18n.t("✅ تم حفظ الملف بنجاح: ", "✅ File saved successfully: ") + attemptName);
								} else {
									toast(RtI18n.t("❌ فشل حفظ الملف: تعذّر إنشاء الملف في Downloads (رجع null من MediaStore)", "❌ Failed to save the file: could not create the file in Downloads (MediaStore returned null)"));
								}
							} else {
								java.io.File downloadsFolder = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS);
								java.io.File file = new java.io.File(downloadsFolder, safeFileName);
								int attempt = 0;
								while (file.exists() && attempt < 20) {
									attempt++;
									file = new java.io.File(downloadsFolder, baseName + "(" + attempt + ")" + extension);
								}
								java.io.FileOutputStream fos = new java.io.FileOutputStream(file);
								fos.write(fileBytes);
								fos.close();
								toast(RtI18n.t("✅ تم حفظ الملف بنجاح: ", "✅ File saved successfully: ") + file.getName());
							}
						} catch (Exception e) {
							e.printStackTrace();
							// === [إصلاح] نعرض سبب الفشل الحقيقي بدل رسالة عامة، عشان تقدر تشخّص المشكلة ===
							String reason = e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName();
							toast(RtI18n.t("❌ فشل حفظ الملف: ", "❌ Failed to save the file: ") + reason);
						}
					}
				}).start();
			}
			
		}, "Android");
		
		MainActivity.this.getWindow().getDecorView().setTag(mUploadMessage);
		
		// === [جديد] سكربتات مشتركة: قفل الـ Zoom + اعتراض تحميل data:/blob: (تُحقن بـ onPageCommitVisible و onPageFinished) ===
		final String zoomLockJs = ""
		+ "(function(){"
		+ "try{"
		+ "var allowed=function(){"
		+ "var a=document.querySelector('meta[name=\"allow-zoom\"]');"
		+ "return !!(a&&/^\\s*true\\s*$/i.test(a.getAttribute('content')||''));"
		+ "};"
		+ "var report=function(v){"
		+ "try{ if(window.Android&&window.Android.setZoomAllowed){ window.Android.setZoomAllowed(v); } }catch(e0){}"
		+ "};"
		+ "if(allowed()){ report(true); return; }"
		+ "report(false);"
		+ "var build=function(old){"
		+ "var keep=[],scale=null,hasMeta=false;"
		+ "if(old&&old.trim()){"
		+ "hasMeta=true;"
		+ "old.split(/[,;]/).forEach(function(t){"
		+ "t=t.trim(); if(!t){return;}"
		+ "var eq=t.indexOf('=');"
		+ "var k=(eq>0?t.substring(0,eq):t).trim().toLowerCase();"
		+ "var v=eq>0?t.substring(eq+1).trim():'';"
		+ "if(k==='user-scalable'||k==='maximum-scale'||k==='minimum-scale'){return;}"
		+ "if(k==='initial-scale'){scale=v;}"
		+ "keep.push(t);"
		+ "});"
		+ "}"
		+ "if(!hasMeta){keep.push('width=device-width');keep.push('initial-scale=1.0');scale='1.0';}"
		+ "if(scale!==null){keep.push('minimum-scale='+scale);keep.push('maximum-scale='+scale);}"
		+ "keep.push('user-scalable=no');"
		+ "return keep.join(', ');"
		+ "};"
		+ "var apply=function(){"
		+ "if(allowed()){ return; }"
		+ "var root=document.head||document.documentElement; if(!root) return;"
		+ "var m=document.querySelector('meta[name=viewport]');"
		+ "if(!m){m=document.createElement('meta');m.name='viewport';root.appendChild(m);}"
		+ "var want=build(m.getAttribute('content'));"
		+ "if(m.getAttribute('content')!==want){m.setAttribute('content',want);}"
		+ "};"
		+ "apply();"
		+ "if(!window.__zoomLocked){"
		+ "window.__zoomLocked=true;"
		+ "var st=document.createElement('style');"
		+ "st.textContent='html,body{touch-action:pan-x pan-y !important;}';"
		+ "(document.head||document.documentElement).appendChild(st);"
		+ "document.addEventListener('touchmove',function(e){ if(!allowed()&&e.touches&&e.touches.length>1){e.preventDefault();} },{passive:false});"
		+ "['gesturestart','gesturechange','gestureend'].forEach(function(t){ document.addEventListener(t,function(e){ if(!allowed()){e.preventDefault();} }); });"
		+ "}"
		+ "if(document.head && !window.__zoomObs){"
		+ "window.__zoomObs=true;"
		+ "new MutationObserver(apply).observe(document.head,{childList:true,subtree:true,attributes:true,attributeFilter:['content']});"
		+ "}"
		+ "}catch(e){}"
		+ "})();";
		
		final String downloadHookJs = ""
		+ "(function(){"
		+ "try{"
		+ "if(window.__dlHooked) return;"
		+ "window.__dlHooked=true;"
		+ "function sendData(raw,mime,name,isB64){ window.Android.downloadDataUri(raw,mime,name,isB64); }"
		+ "function handle(a){"
		+ "var href=a.getAttribute('href')||a.href||'';"
		+ "var name=a.getAttribute('download')||'downloaded_file';"
		+ "if(href.indexOf('data:')===0){"
		+ "var ci=href.indexOf(',');"
		+ "var header=href.substring(5,ci);"
		+ "sendData(href.substring(ci+1),header.split(';')[0],name,header.toLowerCase().indexOf(';base64')!==-1);"
		+ "return true;"
		+ "}"
		+ "if(href.indexOf('blob:')===0){"
		+ "var xhr=new XMLHttpRequest();"
		+ "xhr.open('GET',href,true);"
		+ "xhr.responseType='blob';"
		+ "xhr.onload=function(){"
		+ "var blob=xhr.response;"
		+ "var r=new FileReader();"
		+ "r.onloadend=function(){"
		+ "var s=String(r.result);"
		+ "var i=s.indexOf(',');"
		+ "sendData(s.substring(i+1),(blob.type||'application/octet-stream').split(';')[0],name,true);"
		+ "};"
		+ "r.readAsDataURL(blob);"
		+ "};"
		+ "xhr.onerror=function(){ window.Android.callAndroidBlock('" + RtI18n.t("❌ تعذر قراءة الملف", "❌ Could not read the file") + "'); };"
		+ "xhr.send();"
		+ "return true;"
		+ "}"
		+ "return false;"
		+ "}"
		+ "document.addEventListener('click',function(e){"
		+ "var a=e.target&&e.target.closest?e.target.closest('a'):null;"
		+ "if(a&&a.hasAttribute('download')&&handle(a)){ e.preventDefault(); }"
		+ "},true);"
		+ "var oc=HTMLAnchorElement.prototype.click;"
		+ "HTMLAnchorElement.prototype.click=function(){"
		+ "if(this.hasAttribute('download')&&handle(this)){ return; }"
		+ "return oc.apply(this,arguments);"
		+ "};"
		+ "}catch(e){}"
		+ "})();";
		
		dynamicWebView.setWebViewClient(new android.webkit.WebViewClient() {
			
			// === [إضافة جديدة] توجيه أي رابط خارج نطاق المشروع إلى المتصفح الحقيقي للمستخدم ===
			// يبقى داخل التطبيق فقط: ملفات file:// المحلية، ونطاق Cloudflare Worker (محتوى المشروع)
			@Override
			public boolean shouldOverrideUrlLoading(android.webkit.WebView view, android.webkit.WebResourceRequest request) {
				String scheme = request.getUrl().getScheme();
				String host = request.getUrl().getHost();
				
				if ("file".equals(scheme)) {
					return false;
				}
				
				if (host != null && host.equalsIgnoreCase(ASSET_BASE_HOST)) {
					return false;
				}
				
				try {
					android.content.Intent intent = new android.content.Intent(android.content.Intent.ACTION_VIEW, request.getUrl());
					MainActivity.this.startActivity(intent);
				} catch (Exception e) {
					e.printStackTrace();
					SketchwareUtil.showMessage(getApplicationContext(), RtI18n.t("تعذر فتح الرابط", "Could not open the link"));
				}
				return true;
			}
			
			@Override
			public void onPageStarted(android.webkit.WebView view, String url, android.graphics.Bitmap favicon) {
				super.onPageStarted(view, url, favicon);
				hasShownMediaAlert[0] = false; // نسمح بعرض نافذة تحميل الوسائط مرة وحدة لكل صفحة جديدة
			}
			
			// === [جديد] يُستدعى أول ما الصفحة الجديدة تبدأ تظهر (قبل onPageFinished) -> نقفل الـ Zoom ونثبّت اعتراض التحميل مبكراً ===
			@Override
			public void onPageCommitVisible(android.webkit.WebView view, String url) {
				super.onPageCommitVisible(view, url);
				view.evaluateJavascript(zoomLockJs, null);
				view.evaluateJavascript(downloadHookJs, null);
				view.evaluateJavascript(RT_VIBRATE_JS, null);
				view.evaluateJavascript(RT_ADS_JS, null);
				view.evaluateJavascript(RT_UNITY_ADS_JS, null);
				view.evaluateJavascript(RT_FB_ADS_JS, null);
				view.evaluateJavascript(RT_PAGES_JS, null);
				view.evaluateJavascript(RT_ASSETS_JS, null);
				view.evaluateJavascript(RT_PUSH_JS, null);
				view.evaluateJavascript(RT_BILL_JS, null);
				view.evaluateJavascript(RT_SHARE_JS, null);
				view.evaluateJavascript(RT_LINKS_JS, null);
				view.evaluateJavascript(RT_REVIEW_JS, null);
				if (rtWebApiJs().length() > 0) view.evaluateJavascript(rtWebApiJs(), null);
				if (RtHw.ENABLED && rtHwJs().length() > 0) view.evaluateJavascript(rtHwJs(), null);
				rtReadOrientationFromPage(view);
			}
			
			@Override
			public void onPageFinished(android.webkit.WebView view, String url) {
				super.onPageFinished(view, url);
				
				// === [جديد] تتبع سجل تصفح ذكي (Smart Back Stack) لتفادي إعادة التنقل بشكل مزعج بين
				// نفس الصفحات المتكررة عند الرجوع للخلف (مثال: home -> z -> home -> search -> view -> home...)
				// نخزّنه في SharedPreferences عشان يبقى متاح لكود onBackPressed المنفصل بنفس الـ Activity
				try {
					// === [جديد] استبعاد splash.html نهائياً من السجل، حتى ما يصير فيه احتمال الرجوع لها إطلاقاً عبر onBackPressed
					boolean isSplashPage = url != null && url.toLowerCase().endsWith("/splash.html");
					
					if (url != null && !url.trim().isEmpty() && !url.equalsIgnoreCase("about:blank") && !isSplashPage) {
						android.content.SharedPreferences backStackPrefs = MainActivity.this.getSharedPreferences("smart_back_stack", android.content.Context.MODE_PRIVATE);
						org.json.JSONArray backStackArray = new org.json.JSONArray(backStackPrefs.getString("stack", "[]"));
						
						String lastUrlInStack = backStackArray.length() > 0 ? backStackArray.optString(backStackArray.length() - 1, "") : "";
						
						// لو نفس الصفحة الحالية بالضبط (تحديث/إعادة تحميل)، لا تكرّرها بالسجل
						if (!url.equals(lastUrlInStack)) {
							// لو الصفحة موجودة مسبقاً بأي مكان بالسجل، معناها المستخدم رجع لصفحة زارها من قبل
							// ضمن نفس الجلسة -> نقصّ كل اللي بعدها بدل ما نكدّسها من جديد، فتنحل الحلقة المتكررة تلقائياً
							int existingIndex = -1;
							for (int i = 0; i < backStackArray.length(); i++) {
								if (url.equals(backStackArray.optString(i, ""))) {
									existingIndex = i;
									break;
								}
							}
							
							org.json.JSONArray updatedStack = new org.json.JSONArray();
							if (existingIndex >= 0) {
								for (int i = 0; i <= existingIndex; i++) {
									updatedStack.put(backStackArray.optString(i, ""));
								}
							} else {
								for (int i = 0; i < backStackArray.length(); i++) {
									updatedStack.put(backStackArray.optString(i, ""));
								}
								updatedStack.put(url);
							}
							
							backStackPrefs.edit().putString("stack", updatedStack.toString()).apply();
						}
					}
				} catch (Exception e) { e.printStackTrace(); }
				
				// === [مُعدَّل] اعتراض تحميل data: و blob: (مع اسم الملف من download="...") + قفل الـ Zoom ===
				view.evaluateJavascript(downloadHookJs, null);
				view.evaluateJavascript(RT_VIBRATE_JS, null);
				view.evaluateJavascript(RT_ADS_JS, null);
				view.evaluateJavascript(RT_UNITY_ADS_JS, null);
				view.evaluateJavascript(RT_FB_ADS_JS, null);
				view.evaluateJavascript(RT_PAGES_JS, null);
				view.evaluateJavascript(RT_ASSETS_JS, null);
				view.evaluateJavascript(RT_PUSH_JS, null);
				view.evaluateJavascript(RT_BILL_JS, null);
				view.evaluateJavascript(RT_SHARE_JS, null);
				view.evaluateJavascript(RT_LINKS_JS, null);
				view.evaluateJavascript(RT_REVIEW_JS, null);
				if (rtWebApiJs().length() > 0) view.evaluateJavascript(rtWebApiJs(), null);
				if (RtHw.ENABLED && rtHwJs().length() > 0) view.evaluateJavascript(rtHwJs(), null);
				rtReadOrientationFromPage(view);
				
				// === [مُعدَّل] نفس الفكرة لكن تحافظ على width/initial-scale الخاصة بالصفحة بدل ما تفرض device-width على الكل ===
				view.evaluateJavascript(zoomLockJs, null);
				
				// === [إضافة جديدة] فحص الصفحة بحثاً عن فيديو/صوت وإرسال روابطها لجافا لعرض نافذة التحميل الجماعي
				view.evaluateJavascript(
				"(function(){"
				+ "try{"
				+ "var mediaUrls=[];"
				+ "var addUrl=function(src){ if(src && src.indexOf('file://')!==0 && mediaUrls.indexOf(src)===-1){ mediaUrls.push(src); } };"
				+ "var videos=document.querySelectorAll('video');"
				+ "for(var i=0;i<videos.length;i++){"
				+ "  if(videos[i].currentSrc){addUrl(videos[i].currentSrc);} else if(videos[i].src){addUrl(videos[i].src);}"
				+ "  var vs=videos[i].querySelectorAll('source');"
				+ "  for(var j=0;j<vs.length;j++){ if(vs[j].src){addUrl(vs[j].src);} }"
				+ "}"
				+ "var audios=document.querySelectorAll('audio');"
				+ "for(var i=0;i<audios.length;i++){"
				+ "  if(audios[i].currentSrc){addUrl(audios[i].currentSrc);} else if(audios[i].src){addUrl(audios[i].src);}"
				+ "  var as=audios[i].querySelectorAll('source');"
				+ "  for(var j=0;j<as.length;j++){ if(as[j].src){addUrl(as[j].src);} }"
				+ "}"
				+ "if(mediaUrls.length>0 && window.Android && Android.reportMediaFiles){"
				+ "  Android.reportMediaFiles(JSON.stringify(mediaUrls), location.href);"
				+ "}"
				+ "}catch(e){}"
				+ "})();",
				null
				);
				
				// === [جديد] لو الفيديو/الصوت متوفر محلياً بالفعل (filesDir)، نستبدل الـ src بمسار file:// حقيقي
				// فيشتغل بمشغّل النظام الطبيعي بدعم seekbar/range كامل من نظام أندرويد نفسه، بدل الاعتماد
				// على اعتراض الطلبات يدوياً (اللي كان يقطع التشغيل بعد ثانية واحدة بسبب أخطاء Range اليدوية) ===
				view.evaluateJavascript(
				"(function(){"
				+ "try{"
				+ "function tryLocalize(el){"
				+ "  if(!el || !el.getAttribute) return;"
				+ "  var src = el.currentSrc || el.getAttribute('src');"
				+ "  if(src && window.Android && Android.getLocalMediaFileUri){"
				+ "    var localUri = Android.getLocalMediaFileUri(src);"
				+ "    if(localUri && localUri!=='' && el.src!==localUri){"
				+ "      var wasPlaying = !el.paused;"
				+ "      var savedTime = el.currentTime || 0;"
				+ "      el.src = localUri;"
				+ "      el.load();"
				+ "      el.addEventListener('loadedmetadata', function onMeta(){"
				+ "        el.removeEventListener('loadedmetadata', onMeta);"
				+ "        try{ el.currentTime = savedTime; }catch(e2){}"
				+ "        if(wasPlaying){ var p = el.play(); if(p && p.catch){ p.catch(function(){}); } }"
				+ "      });"
				+ "    }"
				+ "  }"
				+ "  var sources = el.querySelectorAll ? el.querySelectorAll('source') : [];"
				+ "  for(var i=0;i<sources.length;i++){"
				+ "    var ssrc = sources[i].getAttribute('src');"
				+ "    if(ssrc && window.Android && Android.getLocalMediaFileUri){"
				+ "      var localSrcUri = Android.getLocalMediaFileUri(ssrc);"
				+ "      if(localSrcUri && localSrcUri!==''){ sources[i].setAttribute('src', localSrcUri); }"
				+ "    }"
				+ "  }"
				+ "}"
				+ "function scanAll(){"
				+ "  var mediaEls = document.querySelectorAll('video, audio');"
				+ "  for(var i=0;i<mediaEls.length;i++){ tryLocalize(mediaEls[i]); }"
				+ "}"
				+ "scanAll();"
				+ "if(window.MutationObserver && document.body){"
				+ "  var observer = new MutationObserver(function(mutations){"
				+ "    for(var m=0;m<mutations.length;m++){"
				+ "      var added = mutations[m].addedNodes;"
				+ "      for(var n=0;n<added.length;n++){"
				+ "        var node = added[n];"
				+ "        if(!node || node.nodeType!==1) continue;"
				+ "        if(node.tagName==='VIDEO' || node.tagName==='AUDIO'){ tryLocalize(node); }"
				+ "        var nested = node.querySelectorAll ? node.querySelectorAll('video, audio') : [];"
				+ "        for(var k=0;k<nested.length;k++){ tryLocalize(nested[k]); }"
				+ "      }"
				+ "    }"
				+ "  });"
				+ "  observer.observe(document.body, {childList:true, subtree:true});"
				+ "}"
				+ "}catch(e){}"
				+ "})();",
				null
				);
			}
			
			@Override
			public void onReceivedError(android.webkit.WebView view, int errorCode, String description, String failingUrl) {
				super.onReceivedError(view, errorCode, description, failingUrl);
				if (failingUrl != null && !failingUrl.endsWith("404.html")) {
					load404Page.run();
				}
			}
			
			@Override
			public void onReceivedHttpError(android.webkit.WebView view, android.webkit.WebResourceRequest request, android.webkit.WebResourceResponse errorResponse) {
				super.onReceivedHttpError(view, request, errorResponse);
				if (request.isForMainFrame() && errorResponse.getStatusCode() == 404) {
					load404Page.run();
				}
			}
			
			@Override
			public android.webkit.WebResourceResponse shouldInterceptRequest(android.webkit.WebView view, android.webkit.WebResourceRequest request) {
				String url = request.getUrl().toString();
				String lowerUrl = url.toLowerCase();
				String cleanUrlForExt = lowerUrl.split("\\?")[0].split("#")[0];
				
				// === [جديد] صفحات HTML المحلية (file://): نقرأها ونحقن فيها قفل الـ Zoom قبل التسليم للـ WebView ===
				if ("file".equals(request.getUrl().getScheme()) && cleanUrlForExt.endsWith(".html")) {
					try {
						java.io.File htmlFile = new java.io.File(request.getUrl().getPath());
						if (htmlFile.exists() && htmlFile.length() > 0) {
							return new android.webkit.WebResourceResponse("text/html", "UTF-8", zoomInjector.wrap(new java.io.FileInputStream(htmlFile)));
						}
					} catch (Exception e) { e.printStackTrace(); }
				}
				
				// === [إصلاح] لا نعترض إلا طلبات GET على http/https. كان أي POST/fetch يحوي "cdn" أو "font" أو "/image"
				//     يتحول إلى GET ويُخزَّن للأبد، وملفات file:// المحلية كانت تسبب ClassCastException عند كل مورد ===
				String reqScheme = request.getUrl().getScheme();
				if (!"GET".equalsIgnoreCase(request.getMethod()) || !("http".equalsIgnoreCase(reqScheme) || "https".equalsIgnoreCase(reqScheme))) {
					return super.shouldInterceptRequest(view, request);
				}
				
				// 1. فحص الميديا - لو الملف محمّل مسبقاً بالتخزين المحلي (filesDir)، قدّمه من هناك مباشرة بدل الإنترنت
				// === [إصلاح] أُضيفت .mov/.avi/.mkv/.m4a هنا لأن منطق تحديد الـ mimeType بالأسفل كان يدعمها بالفعل
				//     لكن هذا الشرط الخارجي كان يستثنيها فعلياً فلا يصل الكود لها إطلاقاً ===
				final boolean hasMediaExt = safeIO.isMediaExt(cleanUrlForExt);
				if (hasMediaExt || lowerUrl.contains("/video") || lowerUrl.contains("/audio") || lowerUrl.contains("stream")) {
					
					try {
						// === [مُعدَّل] اسم الملف المحلي الآن مبني على hash الرابط الكامل (نفس آلية تسمية الصور/CSS/JS)
						// بدل اسم الملف الأصلي - لضمان اسم فريد دائمًا ومطابقة اسم الحفظ في خدمة التحميل ===
						String ext = ".mp4";
						if (cleanUrlForExt.endsWith(".webm")) ext = ".webm";
						else if (cleanUrlForExt.endsWith(".ogg")) ext = ".ogg";
						else if (cleanUrlForExt.endsWith(".mp3")) ext = ".mp3";
						else if (cleanUrlForExt.endsWith(".wav")) ext = ".wav";
						else if (cleanUrlForExt.endsWith(".mov")) ext = ".mov";
						else if (cleanUrlForExt.endsWith(".avi")) ext = ".avi";
						else if (cleanUrlForExt.endsWith(".mkv")) ext = ".mkv";
						else if (cleanUrlForExt.endsWith(".m4a")) ext = ".m4a";
						
						String cleanName = "media_" + Math.abs(url.hashCode()) + ext;
						
						String localBase = MainActivity.this.getApplicationContext().getFilesDir().getAbsolutePath() + "/";
						java.io.File localMediaFile = new java.io.File(localBase + cleanName);
						
						if (localMediaFile.exists() && localMediaFile.length() > 0) {
							String lowerName = cleanName.toLowerCase();
							String mimeType = "video/mp4";
							if (lowerName.endsWith(".webm")) mimeType = "video/webm";
							else if (lowerName.endsWith(".ogg")) mimeType = "video/ogg";
							else if (lowerName.endsWith(".mp3")) mimeType = "audio/mpeg";
							else if (lowerName.endsWith(".wav")) mimeType = "audio/wav";
							else if (lowerName.endsWith(".mov")) mimeType = "video/quicktime";
							else if (lowerName.endsWith(".avi")) mimeType = "video/x-msvideo";
							else if (lowerName.endsWith(".mkv")) mimeType = "video/x-matroska";
							else if (lowerName.endsWith(".m4a")) mimeType = "audio/mp4";
							
							long fileLength = localMediaFile.length();
							String rangeHeader = request.getRequestHeaders().get("Range");
							
							// === [إصلاح شامل] دعم Range Requests (206 Partial Content) بصيغه الثلاث:
							//     bytes=start-end | bytes=start- | bytes=-suffixLength (آخر N بايت، كانت تفشل بصمت قبل كده)
							//     + رفض الـ Range غير المنطقي بـ 416 بدل تجاهله بصمت ===
							if (rangeHeader != null && rangeHeader.startsWith("bytes=")) {
								try {
									String rangeValue = rangeHeader.substring("bytes=".length()).trim();
									
									// نتعامل مع أول range بس لو المشغّل طلب أكتر من واحد بفاصلة (نادر جداً مع الفيديو)
									int commaIdx = rangeValue.indexOf(',');
									if (commaIdx != -1) rangeValue = rangeValue.substring(0, commaIdx).trim();
									
									long startByte;
									long endByteTemp;
									
									if (rangeValue.startsWith("-")) {
										// === [إصلاح] صيغة "آخر N بايت" (bytes=-N) - يستخدمها بعض المشغّلات لقراءة
										//     الـ metadata من نهاية ملف الـ MP4 عند فتحه لأول مرة ===
										long suffixLength = Long.parseLong(rangeValue.substring(1).trim());
										if (suffixLength <= 0) throw new NumberFormatException("suffix length invalid");
										if (suffixLength > fileLength) suffixLength = fileLength;
										startByte = fileLength - suffixLength;
										endByteTemp = fileLength - 1;
									} else {
										String[] rangeParts = rangeValue.split("-", 2);
										startByte = Long.parseLong(rangeParts[0].trim());
										endByteTemp = (rangeParts.length > 1 && !rangeParts[1].trim().isEmpty())
										? Long.parseLong(rangeParts[1].trim())
										: (fileLength - 1);
									}
									
									if (startByte < 0) startByte = 0;
									if (endByteTemp >= fileLength) endByteTemp = fileLength - 1;
									
									// === [إصلاح] Range غير منطقي (خارج حدود الملف) -> نرجّع 416 صراحة بدل ما نكسر
									//     التشغيل بإرجاع الملف كامل أو استثناء غير متوقع ===
									if (fileLength <= 0 || startByte > endByteTemp || startByte >= fileLength) {
										java.util.Map<String, String> invalidRangeHeaders = new java.util.HashMap<>();
										invalidRangeHeaders.put("Content-Range", "bytes */" + fileLength);
										return new android.webkit.WebResourceResponse(mimeType, null, 416, "Range Not Satisfiable", invalidRangeHeaders, null);
									}
									
									final long finalStartByte = startByte;
									final long finalEndByte = endByteTemp;
									final long contentLength = finalEndByte - finalStartByte + 1;
									
									final java.io.RandomAccessFile randomAccessFile = new java.io.RandomAccessFile(localMediaFile, "r");
									randomAccessFile.seek(finalStartByte);
									
									java.io.InputStream partialStream = new java.io.InputStream() {
										long remaining = contentLength;
										
										@Override
										public int read() throws java.io.IOException {
											if (remaining <= 0) return -1;
											int b = randomAccessFile.read();
											if (b != -1) remaining--;
											return b;
										}
										
										@Override
										public int read(byte[] buffer, int offset, int length) throws java.io.IOException {
											if (remaining <= 0) return -1;
											int toRead = (int) Math.min(length, remaining);
											int actuallyRead = randomAccessFile.read(buffer, offset, toRead);
											if (actuallyRead != -1) remaining -= actuallyRead;
											return actuallyRead;
										}
										
										@Override
										public void close() throws java.io.IOException {
											randomAccessFile.close();
										}
									};
									
									java.util.Map<String, String> responseHeaders = new java.util.HashMap<>();
									responseHeaders.put("Accept-Ranges", "bytes");
									responseHeaders.put("Content-Range", "bytes " + finalStartByte + "-" + finalEndByte + "/" + fileLength);
									responseHeaders.put("Content-Length", String.valueOf(contentLength));
									
									return new android.webkit.WebResourceResponse(mimeType, null, 206, "Partial Content", responseHeaders, partialStream);
								} catch (Exception rangeEx) {
									rangeEx.printStackTrace();
									// فشل تحليل الـ Range لأي سبب - نكمل بالطريقة العادية (الملف كاملاً) بدل ما نفشل تماماً
								}
							}
							
							java.util.Map<String, String> fullHeaders = new java.util.HashMap<>();
							fullHeaders.put("Accept-Ranges", "bytes");
							fullHeaders.put("Content-Length", String.valueOf(fileLength));
							
							java.io.FileInputStream localMediaStream = new java.io.FileInputStream(localMediaFile);
							return new android.webkit.WebResourceResponse(mimeType, null, 200, "OK", fullHeaders, localMediaStream);
						}
					} catch (Exception e) { e.printStackTrace(); }
					
					// === [إصلاح] روابط الميديا الحقيقية تُبثّ من الإنترنت؛ أما غيرها (مثل stream.js) فتكمل لبقية القواعد بدل أن تُستثنى من التخزين ===
					if (hasMediaExt) return null;
				}
				
				// 2. معالجة HTML من Cloudflare Worker
				if (lowerUrl.contains(ASSET_BASE_HOST.toLowerCase()) && (cleanUrlForExt.endsWith(".html"))) {
					try {
						java.net.URL rawUrl = new java.net.URL(url);
						java.net.HttpURLConnection connection = (java.net.HttpURLConnection) rawUrl.openConnection();
						connection.setConnectTimeout(5000);
						connection.setReadTimeout(5000);
						connection.connect();
						
						if (connection.getResponseCode() == java.net.HttpURLConnection.HTTP_OK) {
							return new android.webkit.WebResourceResponse("text/html", "UTF-8", zoomInjector.wrap(connection.getInputStream()));
						} else {
							return null;
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				
				// 3. معالجة كافة الصور والـ GIFs
				// === [إصلاح] التنزيل ذرّي (ملف مؤقت ثم rename) فلا تُخدم صورة مبتورة، وتُسجَّل الـ MIME بعد النجاح فقط ===
				// === [إصلاح 3] الصور بلا امتداد (مثل photo?id=5): نعرفها من هيدر Accept الذي يرسله المتصفح لطلبات الصور ===
				boolean acceptsImage = false;
				try {
					java.util.Map<String, String> reqHeaders = request.getRequestHeaders();
					if (reqHeaders != null) {
						for (java.util.Map.Entry<String, String> h : reqHeaders.entrySet()) {
							if ("accept".equalsIgnoreCase(h.getKey()) && h.getValue() != null && h.getValue().toLowerCase().startsWith("image/")) acceptsImage = true;
						}
					}
				} catch (Exception ignore) {}
				if (safeIO.isImageUrl(lowerUrl, cleanUrlForExt) || acceptsImage) {
					try {
						String fileName = "img_secured_" + Math.abs(url.hashCode());
						final String localImgPath = MainActivity.this.getApplicationContext().getFilesDir().getAbsolutePath() + "/" + fileName;
						java.io.File file = new java.io.File(localImgPath);
						
						android.content.SharedPreferences mimePrefs = MainActivity.this.getSharedPreferences("secured_images_mime", android.content.Context.MODE_PRIVATE);
						android.content.SharedPreferences urlMapPrefs = MainActivity.this.getSharedPreferences("secured_images_url_map", android.content.Context.MODE_PRIVATE);
						
						if (file.exists() && file.length() > 0) {
							String savedMimeType = mimePrefs.getString(fileName, "image/jpeg");
							return new android.webkit.WebResourceResponse(savedMimeType, "UTF-8", new java.io.FileInputStream(file));
						}
						
						String[] ctOut = new String[1];
						int dlRes = safeIO.downloadToFile(url, file, 10000, 1, ctOut, false);
						if (dlRes == safeIO.OK) {
							String contentType = safeIO.imageMime(ctOut[0], lowerUrl, cleanUrlForExt);
							mimePrefs.edit().putString(fileName, contentType).apply();
							urlMapPrefs.edit().putString(fileName, url).apply();
							return new android.webkit.WebResourceResponse(contentType, "UTF-8", new java.io.FileInputStream(file));
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				
				// 4. الاعتراض الشامل لجميع المكاتب والخطوط والـ CDN
				// === [إصلاح 10] اسم الملف بلا امتداد + النوع محفوظ من رد الخادم؛ ويُخدَّم أيضاً أي رابط مجهول ثبت وقت التحديث أنه مكتبة/خط ===
				{
					String stName = "static_" + Math.abs(url.hashCode());
					java.io.File stFile = new java.io.File(MainActivity.this.getApplicationContext().getFilesDir().getAbsolutePath() + "/" + stName);
					android.content.SharedPreferences stPrefs = MainActivity.this.getSharedPreferences("secured_static_mime", android.content.Context.MODE_PRIVATE);
					String stMime = stPrefs.getString(stName, null);
					boolean stCached = stMime != null && stFile.exists() && stFile.length() > 0;
					if (stCached || safeIO.isStaticUrl(lowerUrl, cleanUrlForExt)) {
						try {
							if (!stCached) {
								String[] stCt = new String[1];
								if (safeIO.downloadToFile(url, stFile, 8000, 1, stCt, true) == safeIO.OK) {
									stMime = safeIO.staticMimeFor(stCt[0], lowerUrl, cleanUrlForExt, stFile);
									stPrefs.edit().putString(stName, stMime).apply();
									stCached = true;
								}
							}
							if (stCached) {
								java.util.Map<String, String> responseHeaders = new java.util.HashMap<>();
								responseHeaders.put("Access-Control-Allow-Origin", "*");
								return new android.webkit.WebResourceResponse(stMime, "UTF-8", 200, "OK", responseHeaders, new java.io.FileInputStream(stFile));
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				}
				return super.shouldInterceptRequest(view, request);
			}
		});
		
		// === RosTrick: جسر الاهتزاز — navigator.vibrate() القياسي لا يعمل في كثير من إصدارات WebView،
		//     فنستبدله (انظر RT_VIBRATE_JS) باستدعاء اهتزاز الجهاز الحقيقي، وصفحاتك تستخدم navigator.vibrate() كالمعتاد ===
		dynamicWebView.addJavascriptInterface(new Object() {
			@android.webkit.JavascriptInterface
			public String vibrate(String json) {
				return rtVibrate("alarm", json, dynamicWebView);
			}
			
			// للتشخيص: يجرّب أسلوب اهتزاز محدداً (alarm / touch / notification / media / unknown / legacy / haptic)
			@android.webkit.JavascriptInterface
			public String vibrateWith(String mode, String json) {
				return rtVibrate(mode, json, dynamicWebView);
			}
		}, "RosTrickDevice");
		
		// === RosTrick: جسر الإعلانات (AdMob) — الواجهة للصفحات هي window.RosTrickAds (انظر RT_ADS_JS) ===
		dynamicWebView.addJavascriptInterface(new Object() {
			@android.webkit.JavascriptInterface
			public boolean enabled() { return RtAds.ENABLED && rtAds != null; }
			
			@android.webkit.JavascriptInterface
			public void showBanner(String position) { if (rtAds != null) rtAds.showBanner(position); }
			
			@android.webkit.JavascriptInterface
			public void hideBanner() { if (rtAds != null) rtAds.hideBanner(); }
			
			@android.webkit.JavascriptInterface
			public boolean isReady(String type) { return rtAds != null && rtAds.isReady(type); }
			
			@android.webkit.JavascriptInterface
			public void showInterstitial(int id) { if (rtAds != null) rtAds.showInterstitial(id); }
			
			@android.webkit.JavascriptInterface
			public void showRewarded(int id) { if (rtAds != null) rtAds.showRewarded(id); }
		}, "RosTrickAdsBridge");

		// === RosTrick: جسر إعلانات Unity Ads — الواجهة للصفحات هي window.RosTrickUnityAds (انظر RT_UNITY_ADS_JS) ===
		dynamicWebView.addJavascriptInterface(new Object() {
			@android.webkit.JavascriptInterface
			public boolean enabled() { return RtUnityAds.ENABLED && rtUnityAds != null; }

			@android.webkit.JavascriptInterface
			public void showBanner(String position) { if (rtUnityAds != null) rtUnityAds.showBanner(position); }

			@android.webkit.JavascriptInterface
			public void hideBanner() { if (rtUnityAds != null) rtUnityAds.hideBanner(); }

			@android.webkit.JavascriptInterface
			public boolean isReady(String type) { return rtUnityAds != null && rtUnityAds.isReady(type); }

			@android.webkit.JavascriptInterface
			public void showInterstitial(int id) { if (rtUnityAds != null) rtUnityAds.showInterstitial(id); }

			@android.webkit.JavascriptInterface
			public void showRewarded(int id) { if (rtUnityAds != null) rtUnityAds.showRewarded(id); }
		}, "RosTrickUnityAdsBridge");

		// === RosTrick: جسر إعلانات فيسبوك (Meta Audience Network) — الواجهة للصفحات هي window.RosTrickFbAds (انظر RT_FB_ADS_JS) ===
		dynamicWebView.addJavascriptInterface(new Object() {
			@android.webkit.JavascriptInterface
			public boolean enabled() { return RtFbAds.ENABLED && rtFbAds != null; }

			@android.webkit.JavascriptInterface
			public void showBanner(String position) { if (rtFbAds != null) rtFbAds.showBanner(position); }

			@android.webkit.JavascriptInterface
			public void hideBanner() { if (rtFbAds != null) rtFbAds.hideBanner(); }

			@android.webkit.JavascriptInterface
			public boolean isReady(String type) { return rtFbAds != null && rtFbAds.isReady(type); }

			@android.webkit.JavascriptInterface
			public void showInterstitial(int id) { if (rtFbAds != null) rtFbAds.showInterstitial(id); }

			@android.webkit.JavascriptInterface
			public void showRewarded(int id) { if (rtFbAds != null) rtFbAds.showRewarded(id); }
		}, "RosTrickFbAdsBridge");

		// === RosTrick: جسر الصفحات اليدوية — الواجهة للصفحات هي window.RosTrickPages (انظر RT_PAGES_JS)
		//     يتيح تحميل صفحة غير مسجّلة بـ apppages.json عند الطلب فقط، وفتحها محلياً بعد التحميل ===
		dynamicWebView.addJavascriptInterface(new Object() {
			private String rtPagesBaseLocalPath() { return MainActivity.this.getApplicationContext().getFilesDir().getAbsolutePath() + "/"; }
			private String rtPagesClean(String path) {
				String clean = (path == null) ? "" : path.trim();
				if (clean.length() == 0 || clean.contains("..") || clean.startsWith("/") || clean.contains("\\")) return null;
				return clean;
			}

			@android.webkit.JavascriptInterface
			public boolean isDownloaded(String path) {
				try {
					String clean = rtPagesClean(path);
					if (clean == null) return false;
					java.io.File f = new java.io.File(rtPagesBaseLocalPath() + clean);
					return f.exists() && f.length() > 0;
				} catch (Throwable t) { return false; }
			}

			@android.webkit.JavascriptInterface
			public void download(final String path, final int id) {
				new Thread(new Runnable() {
					@Override public void run() {
						boolean ok = false;
						try {
							String clean = rtPagesClean(path);
							if (clean != null) {
								java.io.File target = new java.io.File(rtPagesBaseLocalPath() + clean);
								java.io.File parent = target.getParentFile();
								if (parent != null && !parent.exists()) parent.mkdirs();
								String remote = ASSET_BASE_URL + android.net.Uri.encode(clean, "/");
								ok = safeIO.downloadToFile(remote, target, 15000, 2, null, true) == safeIO.OK;
							}
						} catch (Throwable t) { t.printStackTrace(); ok = false; }
						final boolean fok = ok;
						runOnUiThread(new Runnable() {
							@Override public void run() {
								try { dynamicWebView.evaluateJavascript("window.__rtPageDownloadEvent && window.__rtPageDownloadEvent(" + id + "," + fok + ");", null); } catch (Throwable ignore) {}
							}
						});
					}
				}).start();
			}

			@android.webkit.JavascriptInterface
			public void openPage(final String path) {
				runOnUiThread(new Runnable() {
					@Override public void run() {
						try {
							String clean = rtPagesClean(path);
							if (clean == null) return;
							java.io.File f = new java.io.File(rtPagesBaseLocalPath() + clean);
							if (f.exists() && f.length() > 0) dynamicWebView.loadUrl("file://" + f.getAbsolutePath());
						} catch (Throwable ignore) {}
					}
				});
			}
		}, "RosTrickPagesBridge");

		// === RosTrick: جسر Assets داخل الـ APK — الواجهة للصفحات هي window.RosTrickAssets (انظر RT_ASSETS_JS)
		//     يقرأ ملفات مُحقَنة وقت البناء مباشرة في جذر assets/ عبر AssetManager (bundle محلي، لا شبكة) ===
		dynamicWebView.addJavascriptInterface(new Object() {
			private String rtAssetsClean(String path) {
				String clean = (path == null) ? "" : path.trim();
				if (clean.length() == 0 || clean.contains("..") || clean.startsWith("/") || clean.contains("\\")) return null;
				return clean;
			}

			@android.webkit.JavascriptInterface
			public boolean exists(String path) {
				try {
					String clean = rtAssetsClean(path);
					if (clean == null) return false;
					java.io.InputStream is = MainActivity.this.getAssets().open(clean);
					is.close();
					return true;
				} catch (Throwable t) { return false; }
			}

			@android.webkit.JavascriptInterface
			public String read(String path) {
				java.io.InputStream is = null;
				try {
					String clean = rtAssetsClean(path);
					if (clean == null) return null;
					is = MainActivity.this.getAssets().open(clean);
					java.io.ByteArrayOutputStream buf = new java.io.ByteArrayOutputStream();
					byte[] tmp = new byte[8192];
					int n;
					while ((n = is.read(tmp)) != -1) buf.write(tmp, 0, n);
					return android.util.Base64.encodeToString(buf.toByteArray(), android.util.Base64.NO_WRAP);
				} catch (Throwable t) {
					return null;
				} finally {
					if (is != null) try { is.close(); } catch (Throwable ignore) {}
				}
			}
		}, "RosTrickAssetsBridge");

		// === RosTrick: جسر الإشعارات (Firebase) — الواجهة للصفحات هي window.RosTrickPush (انظر RT_PUSH_JS) ===
		dynamicWebView.addJavascriptInterface(new Object() {
			@android.webkit.JavascriptInterface
			public boolean enabled() { return RtPush.ENABLED && rtPush != null; }
			
			@android.webkit.JavascriptInterface
			public void getToken(int id) { if (rtPush != null) rtPush.getToken(id); }
			
			@android.webkit.JavascriptInterface
			public void subscribe(int id, String topic) { if (rtPush != null) rtPush.subscribe(id, topic); }
			
			@android.webkit.JavascriptInterface
			public void unsubscribe(int id, String topic) { if (rtPush != null) rtPush.unsubscribe(id, topic); }
			
			@android.webkit.JavascriptInterface
			public void requestPermission(int id) { if (rtPush != null) rtPush.requestPermission(id); }
		}, "RosTrickPushBridge");
		
		// === RosTrick: جسر الشراء داخل التطبيق (Google Play Billing) — الواجهة للصفحات هي window.RosTrickBilling (انظر RT_BILL_JS) ===
		dynamicWebView.addJavascriptInterface(new Object() {
			@android.webkit.JavascriptInterface
			public boolean enabled() { return RtBilling.ENABLED && rtBilling != null; }
			
			@android.webkit.JavascriptInterface
			public void getProducts(int id, String idsJson, String type) { if (rtBilling != null) rtBilling.getProducts(id, idsJson, type); }
			
			@android.webkit.JavascriptInterface
			public void buy(int id, String productId, String type, boolean consumable, String offerToken) { if (rtBilling != null) rtBilling.buy(id, productId, type, consumable, offerToken); }
			
			@android.webkit.JavascriptInterface
			public void getPurchases(int id) { if (rtBilling != null) rtBilling.getPurchases(id); }
			
			@android.webkit.JavascriptInterface
			public void consume(int id, String token) { if (rtBilling != null) rtBilling.consume(id, token); }
		}, "RosTrickBillingBridge");
		
		// === RosTrick: جسر المشاركة — الواجهة للصفحات هي window.RosTrickShare (انظر RT_SHARE_JS) ===
		dynamicWebView.addJavascriptInterface(new Object() {
			@android.webkit.JavascriptInterface
			public void share(final int id, final String title, final String text, final String url, final String fileB64, final String fileName, final String mime) {
				runOnUiThread(new Runnable() {
					@Override public void run() {
						boolean ok = false;
						try { ok = rtShare(title, text, url, fileB64, fileName, mime); } catch (Throwable t) { ok = false; }
						final boolean fok = ok;
						try { dynamicWebView.evaluateJavascript("window.__rtShare&&window.__rtShare(" + id + "," + fok + ")", null); } catch (Throwable ignore) {}
					}
				});
			}
		}, "RosTrickShareBridge");
		
		// === RosTrick: جسر الروابط العميقة — الواجهة للصفحات هي window.RosTrickLinks (انظر RT_LINKS_JS) ===
		dynamicWebView.addJavascriptInterface(new Object() {
			@android.webkit.JavascriptInterface
			public String getInitial() { return rtLastLink == null ? "" : rtLastLink; }
			
			@android.webkit.JavascriptInterface
			public void clear() { rtLastLink = null; }
		}, "RosTrickLinksBridge");
		
		// === RosTrick: جسر التقييم — الواجهة للصفحات هي window.RosTrickReview (انظر RT_REVIEW_JS) ===
		dynamicWebView.addJavascriptInterface(new Object() {
			@android.webkit.JavascriptInterface
			public boolean enabled() { return RtReview.ENABLED && rtReview != null; }
			
			@android.webkit.JavascriptInterface
			public void request(final int id) {
				runOnUiThread(new Runnable() {
					@Override public void run() { if (rtReview != null) rtReview.request(id); }
				});
			}
			
			// يفتح صفحة التطبيق في متجر Play (للتقييم اليدوي) — يعمل دائماً
			@android.webkit.JavascriptInterface
			public boolean openStore() {
				try {
					String pkg = getPackageName();
					android.content.Intent i = new android.content.Intent(android.content.Intent.ACTION_VIEW, Uri.parse("market://details?id=" + pkg));
					i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
					try { startActivity(i); }
					catch (android.content.ActivityNotFoundException e) {
						android.content.Intent w = new android.content.Intent(android.content.Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + pkg));
						w.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
						startActivity(w);
					}
					return true;
				} catch (Throwable t) { return false; }
			}
		}, "RosTrickReviewBridge");
		
		// === RosTrick: جسر واجهات المتصفح القياسية — تُحقن من assets/rt-webapi.js ===
		try {
			rtWebApi = new RtWebApi(MainActivity.this, dynamicWebView);
			dynamicWebView.addJavascriptInterface(rtWebApi, "RosTrickWebApiBridge");
		} catch (Throwable e) { e.printStackTrace(); }
		// واجهات العتاد (Web Bluetooth / WebUSB / Web Serial): تعمل فقط إذا فُعّلت في إعدادات البناء
		try {
			if (RtHw.ENABLED) {
				rtHw = new RtHw(MainActivity.this, dynamicWebView);
				dynamicWebView.addJavascriptInterface(rtHw, "RosTrickHwBridge");
			}
		} catch (Throwable e) { e.printStackTrace(); }
		
		dynamicWebView.setWebChromeClient(new android.webkit.WebChromeClient() {
			
			// === RosTrick: كاميرا/ميكروفون (getUserMedia) والموقع للصفحات ===
			@Override
			public void onPermissionRequest(final android.webkit.PermissionRequest request) {
				MainActivity.this.runOnUiThread(new Runnable() { @Override public void run() { rtHandleWebPermission(request); } });
			}
			
			@Override
			public void onGeolocationPermissionsShowPrompt(final String origin, final android.webkit.GeolocationPermissions.Callback callback) {
				MainActivity.this.runOnUiThread(new Runnable() { @Override public void run() { rtHandleGeoPermission(origin, callback); } });
			}
			
			// === [إضافة جديدة] دعم ملء الشاشة (Fullscreen) لفيديوهات HTML5 وعنصر JavaScript's requestFullscreen() ===
			@Override
			public void onShowCustomView(android.view.View view, android.webkit.WebChromeClient.CustomViewCallback callback) {
				if (customFullscreenView[0] != null) {
					callback.onCustomViewHidden();
					return;
				}
				
				customFullscreenView[0] = view;
				customFullscreenCallback[0] = callback;
				view.setTag(callback); // يسمح لدالة onBackPressed المنفصلة بالوصول لنفس الـ callback لاحقاً
				
				dynamicWebView.setVisibility(android.view.View.GONE);
				rootFullscreenContainer.addView(view, new android.widget.FrameLayout.LayoutParams(
				android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
				android.widget.FrameLayout.LayoutParams.MATCH_PARENT
				));
				
				// إخفاء أشرطة النظام (شريط الحالة والتنقل) لملء شاشة حقيقي
				MainActivity.this.getWindow().getDecorView().setSystemUiVisibility(
				android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
				| android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
				| android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
				| android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
				| android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
				| android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
				);
				
				MainActivity.this.getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
			}
			
			@Override
			public void onHideCustomView() {
				if (customFullscreenView[0] == null) return;
				
				rootFullscreenContainer.removeView(customFullscreenView[0]);
				dynamicWebView.setVisibility(android.view.View.VISIBLE);
				
				// استرجاع أشرطة النظام لوضعها الطبيعي
				MainActivity.this.getWindow().getDecorView().setSystemUiVisibility(android.view.View.SYSTEM_UI_FLAG_VISIBLE);
				MainActivity.this.getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
				
				if (customFullscreenCallback[0] != null) {
					customFullscreenCallback[0].onCustomViewHidden();
				}
				
				customFullscreenView[0] = null;
				customFullscreenCallback[0] = null;
			}
			
			// === [إضافة جديدة] معالجة target="_blank" و window.open() بتوجيهها للمتصفح الخارجي
			// بدل ما تبقى "ميتة" بلا استجابة، بنفس منطق shouldOverrideUrlLoading تمامًا
			@Override
			public boolean onCreateWindow(android.webkit.WebView view, boolean isDialog, boolean isUserGesture, android.os.Message resultMsg) {
				final android.webkit.WebView tempWebView = new android.webkit.WebView(MainActivity.this);
				
				tempWebView.setWebViewClient(new android.webkit.WebViewClient() {
					// === [إصلاح تسرّب] الـ WebView المؤقتة لا تُضاف لأي شاشة، وكانت تبقى حيّة في الذاكرة بعد تسليم الرابط.
					//     نؤجل destroy() لما بعد انتهاء النداء الحالي (تدميرها داخل نداءها نفسه يسبب كراش) ===
					private void destroyLater(final android.webkit.WebView w) {
						new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
							@Override
							public void run() {
								try { w.stopLoading(); w.destroy(); } catch (Exception ignore) {}
							}
						});
					}
					
					@Override
					public boolean shouldOverrideUrlLoading(android.webkit.WebView view2, android.webkit.WebResourceRequest request) {
						String scheme = request.getUrl().getScheme();
						String host = request.getUrl().getHost();
						
						// window.open() بلا رابط ثم تعيين location لاحقاً: ننتظر الرابط الحقيقي ولا ندمّر النافذة الآن
						if ("about".equals(scheme)) return true;
						
						// نفس منطق الروابط العادية بالضبط: أبقِ الروابط الداخلية (المحلية أو نطاق المشروع) داخل التطبيق
						if ("file".equals(scheme) || (host != null && host.equalsIgnoreCase(ASSET_BASE_HOST))) {
							dynamicWebView.loadUrl(request.getUrl().toString());
							destroyLater(view2);
							return true;
						}
						
						try {
							android.content.Intent intent = new android.content.Intent(android.content.Intent.ACTION_VIEW, request.getUrl());
							MainActivity.this.startActivity(intent);
						} catch (Exception e) {
							e.printStackTrace();
							SketchwareUtil.showMessage(getApplicationContext(), RtI18n.t("تعذر فتح الرابط", "Could not open the link"));
						}
						destroyLater(view2);
						return true;
					}
				});
				
				android.webkit.WebView.WebViewTransport transport = (android.webkit.WebView.WebViewTransport) resultMsg.obj;
				transport.setWebView(tempWebView);
				resultMsg.sendToTarget();
				return true;
			}
			
			// === [إصلاح تسرّب] تنظيف النوافذ المنبثقة عند إغلاقها من الصفحة (window.close()).
			//     لا ندمّر الـ WebView الرئيسية أبداً لو استدعت الصفحة window.close() على نفسها ===
			@Override
			public void onCloseWindow(android.webkit.WebView window) {
				if (window != null && window != dynamicWebView) {
					try { window.stopLoading(); window.destroy(); } catch (Exception ignore) {}
				}
			}
			
			// === [إضافة جديدة] دعم alert() من JavaScript كـ Dialog حقيقي ===
			@Override
			public boolean onJsAlert(android.webkit.WebView view, String url, String message, final android.webkit.JsResult result) {
				android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(MainActivity.this);
				builder.setMessage(message);
				builder.setPositiveButton(RtI18n.t("موافق", "OK"), new android.content.DialogInterface.OnClickListener() {
					@Override
					public void onClick(android.content.DialogInterface dialog, int which) {
						result.confirm();
					}
				});
				builder.setCancelable(false);
				builder.create().show();
				return true;
			}
			
			// === [إضافة جديدة] دعم confirm() من JavaScript كـ Dialog حقيقي بخيارين ===
			@Override
			public boolean onJsConfirm(android.webkit.WebView view, String url, String message, final android.webkit.JsResult result) {
				android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(MainActivity.this);
				builder.setMessage(message);
				builder.setPositiveButton(RtI18n.t("موافق", "OK"), new android.content.DialogInterface.OnClickListener() {
					@Override
					public void onClick(android.content.DialogInterface dialog, int which) {
						result.confirm();
					}
				});
				builder.setNegativeButton(RtI18n.t("إلغاء", "Cancel"), new android.content.DialogInterface.OnClickListener() {
					@Override
					public void onClick(android.content.DialogInterface dialog, int which) {
						result.cancel();
					}
				});
				builder.setCancelable(false);
				builder.create().show();
				return true;
			}
			
			// === [إضافة جديدة] دعم prompt() من JavaScript مع حقل إدخال نصي ===
			@Override
			public boolean onJsPrompt(android.webkit.WebView view, String url, String message, String defaultValue, final android.webkit.JsPromptResult result) {
				android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(MainActivity.this);
				builder.setMessage(message);
				
				final android.widget.EditText input = new android.widget.EditText(MainActivity.this);
				input.setText(defaultValue);
				builder.setView(input);
				
				builder.setPositiveButton(RtI18n.t("موافق", "OK"), new android.content.DialogInterface.OnClickListener() {
					@Override
					public void onClick(android.content.DialogInterface dialog, int which) {
						result.confirm(input.getText().toString());
					}
				});
				builder.setNegativeButton(RtI18n.t("إلغاء", "Cancel"), new android.content.DialogInterface.OnClickListener() {
					@Override
					public void onClick(android.content.DialogInterface dialog, int which) {
						result.cancel();
					}
				});
				builder.setCancelable(false);
				builder.create().show();
				return true;
			}
			
			@Override
			public boolean onShowFileChooser(android.webkit.WebView webView, android.webkit.ValueCallback<android.net.Uri[]> filePathCallback, android.webkit.WebChromeClient.FileChooserParams fileChooserParams) {
				if (mUploadMessage[0] != null) {
					mUploadMessage[0].onReceiveValue(null);
				}
				mUploadMessage[0] = filePathCallback;
				
				android.content.Intent intent = null;
				
				// محاولة استخدام القصد (Intent) القادم من الـ HTML مباشرة لمعرفة نوع الملفات المطلوبة
				if (android.os.Build.VERSION.SDK_INT >= 21) {
					intent = fileChooserParams.createIntent();
				}
				
				// في حال عدم وجود Intent مجهز من الـ HTML، يتم إنشاء Intent عام لجميع أنواع الملفات
				if (intent == null) {
					intent = new android.content.Intent(android.content.Intent.ACTION_GET_CONTENT);
					intent.addCategory(android.content.Intent.CATEGORY_OPENABLE);
					intent.setType("*/*"); // قبول جميع أنواع الملفات دون استثناء
				}
				
				try {
					MainActivity.this.startActivityForResult(android.content.Intent.createChooser(intent, RtI18n.t("اختر الملف", "Choose a file")), 101);
				} catch (Exception e) {
					mUploadMessage[0] = null;
					return false;
				}
				return true;
			}
		});
		
		// =======================================================
		// ⬇️ معالج التحميل الموحّد (Download) — data: و http/https معاً
		// يستخرج اسم الملف/امتداده ديناميكياً من Content-Disposition أولاً (مثل المتصفح تماماً)،
		// ولا يفرض اسماً أو امتداداً ثابتاً إلا كحل احتياطي أخير لو تعذّر تحديدهما
		// =======================================================
		// === [جديد] فاحص الشبكة للتحميل: hasNetwork = فيه شبكة بقدرة INTERNET، isValidated = أندرويد تحقق فعلياً أن الإنترنت يعمل ===
		class DownloadNetCheck {
			boolean hasNetwork() {
				try {
					android.net.ConnectivityManager cm = (android.net.ConnectivityManager) MainActivity.this.getSystemService(android.content.Context.CONNECTIVITY_SERVICE);
					if (cm == null) return true;
					if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
						android.net.Network n = cm.getActiveNetwork();
						if (n == null) return false;
						android.net.NetworkCapabilities nc = cm.getNetworkCapabilities(n);
						return nc != null && nc.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET);
					} else {
						android.net.NetworkInfo ni = cm.getActiveNetworkInfo();
						return ni != null && ni.isConnected();
					}
				} catch (Exception e) { return true; }
			}
			boolean isValidated() {
				try {
					if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
						android.net.ConnectivityManager cm = (android.net.ConnectivityManager) MainActivity.this.getSystemService(android.content.Context.CONNECTIVITY_SERVICE);
						if (cm == null) return true;
						android.net.Network n = cm.getActiveNetwork();
						if (n == null) return false;
						android.net.NetworkCapabilities nc = cm.getNetworkCapabilities(n);
						return nc != null && nc.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_VALIDATED);
					}
					return hasNetwork();
				} catch (Exception e) { return true; }
			}
		}
		final DownloadNetCheck dlNet = new DownloadNetCheck();
		
		dynamicWebView.setDownloadListener(new android.webkit.DownloadListener() {
			@Override
			public void onDownloadStart(String url, String userAgent, String contentDisposition, String mimeType, long contentLength) {
				try {
					boolean isDataUri = url != null && url.startsWith("data:");
					boolean isBlobUri = url != null && url.startsWith("blob:");
					android.net.Uri parsedUri = isDataUri ? null : android.net.Uri.parse(url);
					
					String fileName = null;
					
					// 1. الأولوية القصوى دائماً: استخراج filename من Content-Disposition
					//    (يشتغل مع data: و http/https بنفس الطريقة لأن WebView يمرره تلقائياً لو فيه download="...")
					if (contentDisposition != null && !contentDisposition.isEmpty()) {
						java.util.regex.Matcher m1 = java.util.regex.Pattern
						.compile("filename\\*=UTF-8''([^;]+)", java.util.regex.Pattern.CASE_INSENSITIVE)
						.matcher(contentDisposition);
						java.util.regex.Matcher m2 = java.util.regex.Pattern
						.compile("filename=\"?([^\";]+)\"?", java.util.regex.Pattern.CASE_INSENSITIVE)
						.matcher(contentDisposition);
						
						if (m1.find()) {
							try {
								fileName = java.net.URLDecoder.decode(m1.group(1).trim(), "UTF-8");
							} catch (Exception decEx) {
								fileName = m1.group(1).trim(); // ترميز % غير صالح: نستخدم الاسم كما هو بدل إفشال التحميل كله
							}
						} else if (m2.find()) {
							fileName = m2.group(1).trim();
						}
					}
					
					// 2. لو ما زال فاضي، وكان الرابط http/https، خذ الاسم من آخر جزء بالمسار
					if ((fileName == null || fileName.isEmpty()) && !isDataUri && !isBlobUri) {
						String lastSegment = parsedUri.getLastPathSegment();
						if (lastSegment != null && !lastSegment.isEmpty()) {
							fileName = lastSegment;
						}
					}
					
					// 3. تحديد الـ MIME الفعلي: لو data:، استخرجه من رأس الرابط نفسه (data:<mime>;base64,...)
					String finalMimeType = mimeType;
					String dataHeader = null;
					if (isDataUri) {
						int commaIndex = url.indexOf(",");
						dataHeader = url.substring(5, commaIndex);
						String declaredMime = dataHeader.split(";")[0].trim();
						if (!declaredMime.isEmpty()) {
							finalMimeType = declaredMime;
						}
					}
					
					boolean hasExtension = fileName != null && fileName.contains(".")
					&& fileName.lastIndexOf(".") < fileName.length() - 1;
					
					if (fileName != null) {
						String lowerName = fileName.toLowerCase();
						if (lowerName.endsWith(".apk")) finalMimeType = "application/vnd.android.package-archive";
						else if (lowerName.endsWith(".swb")) finalMimeType = "application/octet-stream";
						else if (lowerName.endsWith(".pdf")) finalMimeType = "application/pdf";
						else if (lowerName.endsWith(".zip")) finalMimeType = "application/zip";
						else if (lowerName.endsWith(".json")) finalMimeType = "application/json";
						else if (lowerName.endsWith(".mp3")) finalMimeType = "audio/mpeg";
						else if (lowerName.endsWith(".mp4")) finalMimeType = "video/mp4";
						else if (lowerName.endsWith(".docx")) finalMimeType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
						else if (lowerName.endsWith(".doc")) finalMimeType = "application/msword";
						else if (lowerName.endsWith(".xlsx")) finalMimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
						else if (lowerName.endsWith(".pptx")) finalMimeType = "application/vnd.openxmlformats-officedocument.presentationml.presentation";
					}
					
					// 4. لو ما زال بدون امتداد نهائياً -> استنتجه من الـ MIME ونلحقه بالاسم
					if (fileName == null || !hasExtension) {
						String guessedExt = android.webkit.MimeTypeMap.getSingleton()
						.getExtensionFromMimeType(finalMimeType);
						
						if (guessedExt == null || guessedExt.isEmpty()) {
							guessedExt = "bin";
						}
						
						String defaultBaseName = isDataUri ? "backup" : "downloaded_file";
						fileName = (fileName == null || fileName.isEmpty() ? defaultBaseName : fileName) + "." + guessedExt;
					}
					
					// === [إصلاح] تنظيف اسم الملف (الاسم القادم من Content-Disposition أو الرابط قد يحوي / أو : فيفشل الحفظ) ===
					if (fileName != null) {
						fileName = fileName.replaceAll("[/\\\\:*?\"<>|]", "_").trim();
						if (fileName.length() == 0) fileName = "downloaded_file";
					}
					
					// ============================================================
					// === الحفظ الفعلي: حسب نوع المصدر (data: مقابل http/https) ===
					// ============================================================
					// === [جديد] روابط blob: لا يقدر DownloadManager يحمّلها أبداً (يقبل http/https فقط) ->
					// نقرأ محتوى الـ blob من داخل الصفحة نفسها ونرسله بالـ base64 لدالة downloadDataUri ===
					if (isBlobUri) {
						String safeBlobUrl = url.replace("\\", "").replace("'", "%27");
						String blobJs = "(function(){try{"
						+ "var x=new XMLHttpRequest();"
						+ "x.open('GET','" + safeBlobUrl + "',true);"
						+ "x.responseType='blob';"
						+ "x.onload=function(){"
						+ "var b=x.response;var r=new FileReader();"
						+ "r.onloadend=function(){"
						+ "var s=String(r.result);var i=s.indexOf(',');"
						+ "window.Android.downloadDataUri(s.substring(i+1),(b.type||" + org.json.JSONObject.quote(finalMimeType == null ? "application/octet-stream" : finalMimeType) + ").split(';')[0]," + org.json.JSONObject.quote(fileName) + ",true);"
						+ "};"
						+ "r.readAsDataURL(b);"
						+ "};"
						+ "x.onerror=function(){window.Android.callAndroidBlock('" + RtI18n.t("❌ تعذر قراءة الملف", "❌ Could not read the file") + "');};"
						+ "x.send();"
						+ "}catch(err){window.Android.callAndroidBlock('" + RtI18n.t("❌ تعذر قراءة الملف", "❌ Could not read the file") + "');}})();";
						dynamicWebView.evaluateJavascript(blobJs, null);
						return;
					}
					
					if (isDataUri) {
						String dataString = url.substring(url.indexOf(",") + 1);
						byte[] fileBytes;
						if (dataHeader.toLowerCase().contains("base64")) {
							fileBytes = android.util.Base64.decode(dataString, android.util.Base64.DEFAULT);
						} else {
							fileBytes = android.net.Uri.decode(dataString).getBytes("UTF-8");
						}
						
						if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
							android.content.ContentValues values = new android.content.ContentValues();
							values.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, fileName);
							values.put(android.provider.MediaStore.MediaColumns.MIME_TYPE, finalMimeType);
							values.put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS);
							
							android.net.Uri externalUri = android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI;
							android.net.Uri fileUri = MainActivity.this.getContentResolver().insert(externalUri, values);
							
							if (fileUri != null) {
								java.io.OutputStream outputStream = MainActivity.this.getContentResolver().openOutputStream(fileUri);
								outputStream.write(fileBytes);
								outputStream.close();
								SketchwareUtil.showMessage(getApplicationContext(), RtI18n.t("✅ تم حفظ الملف بنجاح: ", "✅ File saved successfully: ") + fileName);
							} else {
								SketchwareUtil.showMessage(getApplicationContext(), RtI18n.t("❌ فشل حفظ الملف في Downloads", "❌ Failed to save the file to Downloads"));
							}
						} else {
							java.io.File downloadsFolder = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS);
							java.io.File file = new java.io.File(downloadsFolder, fileName);
							java.io.FileOutputStream fos = new java.io.FileOutputStream(file);
							fos.write(fileBytes);
							fos.close();
							SketchwareUtil.showMessage(getApplicationContext(), RtI18n.t("✅ تم حفظ الملف بنجاح: ", "✅ File saved successfully: ") + fileName);
						}
						
					} else {
						// رابط http/https عادي -> فحص وصول فعلي للخادم ثم DownloadManager
						// === [مُعدَّل] بدون أي مهلة اعتباطية: نجرّب الاتصال بالخادم فعلياً أولاً،
						// لو رفضه الخادم (HTTP >= 400) أو تعذّر الوصول إليه -> "تعذر التنزيل" فوراً ولا يبدأ التحميل ===
						if (!dlNet.hasNetwork()) {
							SketchwareUtil.showMessage(getApplicationContext(), RtI18n.t("⚠️ تعذر التنزيل", "⚠️ Download failed"));
							return;
						}
						
						final String fUrl = url;
						final String fUa = userAgent;
						final String fFileName = fileName;
						final String fMime = finalMimeType;
						final android.net.Uri fUri = parsedUri;
						
						// الجزء المسؤول عن بدء التحميل فعلياً + مراقبة فشله (يعمل على الـ UI Thread)
						final Runnable startDownloadManager = new Runnable() {
							@Override
							public void run() {
								try {
									android.app.DownloadManager.Request request = new android.app.DownloadManager.Request(fUri);
									request.setMimeType(fMime);
									request.addRequestHeader("User-Agent", fUa);
									try {
										String ck = android.webkit.CookieManager.getInstance().getCookie(fUrl);
										if (ck != null && !ck.isEmpty()) request.addRequestHeader("Cookie", ck);
									} catch (Exception ignoreCookie) {}
									request.setDescription(RtI18n.t("جاري تحميل الملف...", "Downloading the file..."));
									request.setTitle(fFileName);
									request.allowScanningByMediaScanner();
									request.setNotificationVisibility(android.app.DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
									request.setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_DOWNLOADS, fFileName);
									
									final android.app.DownloadManager dmRef = (android.app.DownloadManager) MainActivity.this.getSystemService(android.content.Context.DOWNLOAD_SERVICE);
									final long dlId = dmRef.enqueue(request);
									
									SketchwareUtil.showMessage(getApplicationContext(), RtI18n.t("بدأ تحميل: ", "Download started: ") + fFileName);
									
									// مراقبة حالة التحميل (كل ثانية) بدون إلغاء بالمهلة: نتصرف فقط حسب حالة DownloadManager الفعلية
									final android.os.Handler dlHandler = new android.os.Handler(android.os.Looper.getMainLooper());
									final int[] dlTries = {0};
									final boolean[] dlWarned = {false};
									dlHandler.postDelayed(new Runnable() {
										@Override
										public void run() {
											boolean keepWatching = true;
											android.database.Cursor c = null;
											try {
												c = dmRef.query(new android.app.DownloadManager.Query().setFilterById(dlId));
												if (c != null && c.moveToFirst()) {
													int status = c.getInt(c.getColumnIndex(android.app.DownloadManager.COLUMN_STATUS));
													int reason = c.getInt(c.getColumnIndex(android.app.DownloadManager.COLUMN_REASON));
													long soFar = c.getLong(c.getColumnIndex(android.app.DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR));
													
													if (status == android.app.DownloadManager.STATUS_SUCCESSFUL) {
														keepWatching = false;
													} else if (status == android.app.DownloadManager.STATUS_FAILED) {
														keepWatching = false;
														// أي فشل (رفض الخادم، خطأ بيانات، ...) -> نفس الرسالة
														SketchwareUtil.showMessage(getApplicationContext(), RtI18n.t("⚠️ تعذر التنزيل", "⚠️ Download failed"));
													} else if (status == android.app.DownloadManager.STATUS_PAUSED
													&& (reason == android.app.DownloadManager.PAUSED_WAITING_TO_RETRY
													|| reason == android.app.DownloadManager.PAUSED_WAITING_FOR_NETWORK)) {
														if (soFar <= 0) {
															// DownloadManager نفسه قال إنه ما قدر يوصل للخادم -> نلغيه ونبلّغ
															SketchwareUtil.showMessage(getApplicationContext(), RtI18n.t("⚠️ تعذر التنزيل", "⚠️ Download failed"));
															dmRef.remove(dlId);
															keepWatching = false;
														} else if (!dlWarned[0]) {
															dlWarned[0] = true;
															SketchwareUtil.showMessage(getApplicationContext(), RtI18n.t("⚠️ انقطع الإنترنت، سيُستكمل التحميل تلقائياً عند عودته", "⚠️ Internet connection lost. The download will resume automatically when it returns."));
														}
													}
												} else {
													keepWatching = false; // التحميل انحذف (مثلاً المستخدم ألغاه من الإشعار)
												}
											} catch (Exception watchEx) {
												keepWatching = false;
											} finally {
												if (c != null) c.close();
											}
											
											if (keepWatching && ++dlTries[0] < 1800) {
												dlHandler.postDelayed(this, 1000);
											}
										}
									}, 1000);
								} catch (Exception enqueueEx) {
									enqueueEx.printStackTrace();
									SketchwareUtil.showMessage(getApplicationContext(), RtI18n.t("⚠️ تعذر التنزيل", "⚠️ Download failed"));
								}
							}
						};
						
						if (fUrl != null && fUrl.toLowerCase().startsWith("https://")) {
							// فحص وصول حقيقي للخادم في خيط خلفي (طلب GET بحجم بايت واحد فقط، لا يحمّل الملف)
							new Thread(new Runnable() {
								@Override
								public void run() {
									boolean reachable = false;
									java.net.HttpURLConnection conn = null;
									try {
										conn = (java.net.HttpURLConnection) new java.net.URL(fUrl).openConnection();
										conn.setConnectTimeout(10000);
										conn.setReadTimeout(10000);
										conn.setRequestMethod("GET");
										conn.setRequestProperty("User-Agent", fUa);
										conn.setRequestProperty("Range", "bytes=0-0");
										String ck = android.webkit.CookieManager.getInstance().getCookie(fUrl);
										if (ck != null && !ck.isEmpty()) conn.setRequestProperty("Cookie", ck);
										int code = conn.getResponseCode();
										// 2xx/3xx = تمام، و416 يعني ملف فارغ مع Range (ما زال موجوداً)
										reachable = (code >= 200 && code < 400) || code == 416;
									} catch (Exception probeEx) {
										reachable = false; // تعذر الوصول للخادم (DNS / لا إنترنت / رفض اتصال / SSL ...)
									} finally {
										if (conn != null) conn.disconnect();
									}
									final boolean ok = reachable;
									runOnUiThread(new Runnable() {
										@Override
										public void run() {
											if (ok) {
												startDownloadManager.run();
											} else {
												SketchwareUtil.showMessage(getApplicationContext(), RtI18n.t("⚠️ تعذر التنزيل", "⚠️ Download failed"));
											}
										}
									});
								}
							}).start();
						} else {
							// رابط http عادي (غير مشفّر): قد يمنعه HttpURLConnection بسياسة cleartext، فنترك DownloadManager يتولاه مباشرة
							startDownloadManager.run();
						}
					}
					
				} catch (Exception e) {
					e.printStackTrace();
					SketchwareUtil.showMessage(getApplicationContext(), RtI18n.t("تعذر بدء التحميل", "Could not start the download"));
				}
			}
		});
		
		rootFullscreenContainer.addView(dynamicWebView, new android.widget.FrameLayout.LayoutParams(
		android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
		android.widget.FrameLayout.LayoutParams.MATCH_PARENT
		));
		setContentView(rootFullscreenContainer);
		
		// === RosTrick: تهيئة طبقة الإعلانات (فارغة إن لم تُفعَّل الإعلانات في إعدادات البناء) ===
		try {
			rtAds = new RtAds(MainActivity.this, rootFullscreenContainer, dynamicWebView);
			rtAds.setListener(new RtAds.Listener() {
				@Override
				public void onEvent(final String type, final String event, final int id, final boolean ok) {
					dynamicWebView.post(new Runnable() {
						@Override
						public void run() {
							dynamicWebView.evaluateJavascript("window.__rtAdEvent&&window.__rtAdEvent('" + type + "','" + event + "'," + id + "," + ok + ");", null);
						}
					});
				}
			});
			rtAds.init();
		} catch (Throwable e) { e.printStackTrace(); }

		// === RosTrick: تهيئة طبقة إعلانات Unity Ads (فارغة إن لم تُفعَّل في إعدادات البناء) ===
		try {
			rtUnityAds = new RtUnityAds(MainActivity.this, rootFullscreenContainer, dynamicWebView);
			rtUnityAds.setListener(new RtUnityAds.Listener() {
				@Override
				public void onEvent(final String type, final String event, final int id, final boolean ok) {
					dynamicWebView.post(new Runnable() {
						@Override
						public void run() {
							dynamicWebView.evaluateJavascript("window.__rtUnityAdEvent&&window.__rtUnityAdEvent('" + type + "','" + event + "'," + id + "," + ok + ");", null);
						}
					});
				}
			});
			rtUnityAds.init();
		} catch (Throwable e) { e.printStackTrace(); }

		// === RosTrick: تهيئة طبقة إعلانات فيسبوك (Meta Audience Network) (فارغة إن لم تُفعَّل في إعدادات البناء) ===
		try {
			rtFbAds = new RtFbAds(MainActivity.this, rootFullscreenContainer, dynamicWebView);
			rtFbAds.setListener(new RtFbAds.Listener() {
				@Override
				public void onEvent(final String type, final String event, final int id, final boolean ok) {
					dynamicWebView.post(new Runnable() {
						@Override
						public void run() {
							dynamicWebView.evaluateJavascript("window.__rtFbAdEvent&&window.__rtFbAdEvent('" + type + "','" + event + "'," + id + "," + ok + ");", null);
						}
					});
				}
			});
			rtFbAds.init();
		} catch (Throwable e) { e.printStackTrace(); }

		// === RosTrick: الإشعارات (Firebase) والشراء داخل التطبيق — نسخ فارغة إن لم تُفعَّل في إعدادات البناء ===
		try {
			rtPush = new RtPush(MainActivity.this, new RtPush.Callback() {
				@Override
				public void done(final int id, final String json) {
					dynamicWebView.post(new Runnable() {
						@Override
						public void run() {
							dynamicWebView.evaluateJavascript("window.__rtPush&&window.__rtPush(" + id + "," + org.json.JSONObject.quote(json) + ");", null);
						}
					});
				}
			});
			rtPush.init();
		} catch (Throwable e) { e.printStackTrace(); }
		try {
			rtBilling = new RtBilling(MainActivity.this, new RtBilling.Callback() {
				@Override
				public void done(final int id, final String json) {
					dynamicWebView.post(new Runnable() {
						@Override
						public void run() {
							dynamicWebView.evaluateJavascript("window.__rtBill&&window.__rtBill(" + id + "," + org.json.JSONObject.quote(json) + ");", null);
						}
					});
				}
			});
			rtBilling.init();
		} catch (Throwable e) { e.printStackTrace(); }
		try {
			rtReview = new RtReview(MainActivity.this, new RtReview.Callback() {
				@Override
				public void done(final int id, final String json) {
					dynamicWebView.post(new Runnable() {
						@Override
						public void run() {
							dynamicWebView.evaluateJavascript("window.__rtReview&&window.__rtReview(" + id + "," + org.json.JSONObject.quote(json) + ");", null);
						}
					});
				}
			});
		} catch (Throwable e) { e.printStackTrace(); }
		
		// === RosTrick: التطبيقات التي تستهدف API 35+ تُرسم خلف أشرطة النظام (edge-to-edge) إجبارياً على أندرويد 15+،
		//     فنضيف هوامش بقدر أشرطة النظام (والكيبورد) وإلا غطّى الشريط العلوي/السفلي محتوى الصفحة ===
		try {
			rootFullscreenContainer.setBackgroundColor(getResources().getColor(R.color.colorPrimaryDark));
			rootFullscreenContainer.setOnApplyWindowInsetsListener(new android.view.View.OnApplyWindowInsetsListener() {
				@Override
				public android.view.WindowInsets onApplyWindowInsets(android.view.View v, android.view.WindowInsets insets) {
					int l, t, r, b;
					if (android.os.Build.VERSION.SDK_INT >= 30) {
						android.graphics.Insets bars = insets.getInsets(android.view.WindowInsets.Type.systemBars() | android.view.WindowInsets.Type.displayCutout());
						android.graphics.Insets ime = insets.getInsets(android.view.WindowInsets.Type.ime());
						l = bars.left; t = bars.top; r = bars.right; b = Math.max(bars.bottom, ime.bottom);
						v.setPadding(l, t, r, b);
						return android.view.WindowInsets.CONSUMED;
					} else {
						l = insets.getSystemWindowInsetLeft(); t = insets.getSystemWindowInsetTop();
						r = insets.getSystemWindowInsetRight(); b = insets.getSystemWindowInsetBottom();
						v.setPadding(l, t, r, b);
						return insets.consumeSystemWindowInsets();
					}
				}
			});
			rootFullscreenContainer.requestApplyInsets();
		} catch (Throwable e) { e.printStackTrace(); }
		
		// =======================================================
		// 🔑 دالة تشغيل التطبيق الطبيعي (تُستدعى فقط إذا كان التطبيق نشطاً)
		// =======================================================
		final String baseLocalPath = MainActivity.this.getApplicationContext().getFilesDir().getAbsolutePath() + "/";
		final String local_path = baseLocalPath + "home.html";
		
		// =======================================================
		// 🖼️ [جديد] دالة إبطال ذاكرة التخزين المؤقت الخاصة بصورة/صور اللوجو (app-assets/) فقط
		// تُستدعى كل مرة يتم فيها اكتشاف إصدار (version.txt) أحدث من النسخة المحلية،
		// حتى لو بقي اسم ملف اللوجو كما هو، سيُعاد تنزيله من جديد بدل الاعتماد على النسخة المخزنة مسبقاً على الجهاز
		// =======================================================
		final Runnable purgeLogoAssetCache = new Runnable() {
			@Override
			public void run() {
				try {
					android.content.SharedPreferences urlMapPrefs = MainActivity.this.getSharedPreferences("secured_images_url_map", android.content.Context.MODE_PRIVATE);
					android.content.SharedPreferences mimePrefs = MainActivity.this.getSharedPreferences("secured_images_mime", android.content.Context.MODE_PRIVATE);
					java.util.Map<String, ?> allEntries = urlMapPrefs.getAll();
					
					android.content.SharedPreferences.Editor urlEditor = urlMapPrefs.edit();
					android.content.SharedPreferences.Editor mimeEditor = mimePrefs.edit();
					boolean changed = false;
					
					for (java.util.Map.Entry<String, ?> entry : allEntries.entrySet()) {
						String fileName = entry.getKey();
						Object valObj = entry.getValue();
						String storedUrl = (valObj != null) ? valObj.toString() : "";
						
						// نستهدف فقط الملفات التي مصدرها مجلد لوجو التطبيق (app-assets/)
						if (storedUrl.toLowerCase().contains("app-assets/")) {
							java.io.File cachedFile = new java.io.File(baseLocalPath + fileName);
							if (cachedFile.exists()) cachedFile.delete();
							urlEditor.remove(fileName);
							mimeEditor.remove(fileName);
							changed = true;
						}
					}
					
					if (changed) {
						urlEditor.apply();
						mimeEditor.apply();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		};
		
		// 🖼️ [جديد] دالة فتح home.html كالمعتاد (منفصلة لتُستدعى أيضاً من فحص splash.html بالأسفل)
		final Runnable openIndexHtmlFlow = new Runnable() {
			@Override
			public void run() {
				java.io.File localFile = new java.io.File(local_path);
				if (localFile.exists() && localFile.length() > 0) {
					dynamicWebView.loadUrl("file://" + local_path);
				} else {
					boolean copySuccess = false;
					try {
						java.io.InputStream in = MainActivity.this.getAssets().open("home.html");
						copySuccess = (safeIO.saveStream(in, localFile, -1, false) == safeIO.OK);
					} catch (Exception e) { e.printStackTrace(); }
					
					if (copySuccess && localFile.exists() && localFile.length() > 0) {
						dynamicWebView.loadUrl("file://" + local_path);
					} else {
						load404Page.run();
					}
				}
			}
		};
		
		// =======================================================
		// 🔗 [جديد] تحميل صفحات HTML خارجية عبر app_linked_pages.json
		// الصيغة داخل الملف: { "الاسم_المحلي.html": "الرابط_الفعلي_لأي_صفحة" }
		// كل رابط يُحمَّل ويُحفظ محلياً باسمه المحلي (وليس باسمه الأصلي بالرابط)،
		// فيصبح href="الاسم_المحلي.html" يعمل أوفلاين تماماً كأنه من ملفات ASSET_BASE_HOST
		// [مُهم] هذه الدالة تُستدعى فقط من داخل performSaveAndFinish، أي فقط لما يتغيّر version.txt
		// بالضبط زي أي ملف تحديث عادي (بدون فحص "موجود من قبل" - نفس سلوك downloadAllSyncFiles تماماً،
		// فتُعاد كتابتها من جديد كل مرة يطلع فيها إصدار جديد، حتى لو الرابط الخارجي اتغيّر)
		// =======================================================
		// === [إصلاح] صارت متزامنة (تُستدعى من خيط خلفي فقط) وتكتب ذرّياً، ولا تعتمد على contains("404") ===
		//     linkedPagesFailures: عدد الفشل المؤقت (شبكة/5xx)؛ غياب ملف app_linked_pages.json (4xx) ليس فشلاً
		final java.util.concurrent.atomic.AtomicInteger linkedPagesFailures = new java.util.concurrent.atomic.AtomicInteger(0);
		final Runnable downloadLinkedPagesFlow = new Runnable() {
			@Override
			public void run() {
				int[] status = new int[1];
				String json = safeIO.fetchText(ASSET_BASE_URL + "app_linked_pages.json", 10000, status);
				if (json == null) {
					if (status[0] < 0 || status[0] >= 500) linkedPagesFailures.incrementAndGet();
					return;
				}
				if (safeIO.looksLikeNotFound(json)) return;
				try {
					org.json.JSONObject linkedPagesJson = new org.json.JSONObject(json);
					java.util.Iterator<String> keysIterator = linkedPagesJson.keys();
					while (keysIterator.hasNext()) {
						String localPageName = keysIterator.next();
						String remotePageUrl = linkedPagesJson.optString(localPageName, "");
						if (localPageName == null || localPageName.length() == 0 || remotePageUrl.length() == 0) continue;
						if (localPageName.contains("..") || localPageName.contains("/") || localPageName.contains("\\")) continue;
						if (!remotePageUrl.startsWith("http://") && !remotePageUrl.startsWith("https://")) continue;
						int res = safeIO.downloadToFile(remotePageUrl, new java.io.File(baseLocalPath + localPageName), 10000, 2, null, true);
						if (res == safeIO.FAIL) linkedPagesFailures.incrementAndGet();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		};
		
		final Runnable startNormalAppFlow = new Runnable() {
			@Override
			public void run() {
				// === [إصلاح] حذف بقايا ملفات .tmp من تنزيلات انقطعت سابقاً (قبل بدء أي تنزيل جديد) ===
				try {
					java.io.File[] staleFiles = new java.io.File(baseLocalPath).listFiles();
					if (staleFiles != null) {
						for (java.io.File sf : staleFiles) {
							if (sf.getName().endsWith(".tmp")) sf.delete();
						}
					}
					java.io.File[] staleImg = MainActivity.this.getApplicationContext().getFilesDir().listFiles();
					if (staleImg != null) {
						for (java.io.File sf : staleImg) {
							if (sf.getName().endsWith(".tmp")) sf.delete();
						}
					}
				} catch (Exception ignore) {}
				
				// 1. فحص وجود splash.html: إن وُجد يتم فتحه مباشرة، وإلا يتم فتح home.html كالمعتاد
				final String splash_local_path = baseLocalPath + "splash.html";
				java.io.File splashFile = new java.io.File(splash_local_path);
				
				if (pendingNotificationUrl[0] != null) {
					// === [إصلاح 7] الفتح من إشعار: نتخطى splash (لأنه ينتقل لـ home بعد انتهائه ويمحو الصفحة المطلوبة)،
					//     ونحمّل home.html أولاً (يضمن وجوده) ثم نفتح الصفحة المطلوبة مباشرة بلا تأخير زمني تخميني ===
					openIndexHtmlFlow.run();
					dynamicWebView.loadUrl(pendingNotificationUrl[0]);
				} else if (splashFile.exists() && splashFile.length() > 0) {
					// splash.html موجود مسبقاً في مساحة التخزين المحلية للتطبيق
					dynamicWebView.loadUrl("file://" + splash_local_path);
				} else {
					// لا يوجد splash.html محلياً، نتحقق إن كان موجوداً ضمن أصول التطبيق (assets)
					boolean splashCopySuccess = false;
					try {
						java.io.InputStream splashIn = MainActivity.this.getAssets().open("splash.html");
						splashCopySuccess = (safeIO.saveStream(splashIn, splashFile, -1, false) == safeIO.OK);
					} catch (Exception e) {
						// splash.html غير موجود ضمن assets، لا مشكلة - سيتم فتح home.html بدلاً منه
						splashCopySuccess = false;
					}
					
					if (splashCopySuccess && splashFile.exists() && splashFile.length() > 0) {
						dynamicWebView.loadUrl("file://" + splash_local_path);
					} else {
						// لا يوجد splash.html إطلاقاً (لا محلياً ولا في assets) -> فتح home.html مباشرة
						openIndexHtmlFlow.run();
					}
				}
				
				// 2. تنظيف ملفات HTML المفتقرة (المصدر: apppages.json عبر Workers.dev)
				// [مُهم] قبل أي تنظيف، نجيب أسماء صفحات app_linked_pages.json ونستثنيها من الحذف
				// === [إصلاح] لو فشل جلب القائمة لسبب شبكة نتخطى التنظيف كلياً (كانت القائمة تصير فارغة فتُحذف الصفحات المرتبطة).
				//     وتحليل JSON هو المعيار بدل contains("404") ===
				RequestNetwork linkedNamesGuard = new RequestNetwork(MainActivity.this);
				String linkedNamesGuardUrl = ASSET_BASE_URL + "app_linked_pages.json";
				
				linkedNamesGuard.startRequestNetwork(RequestNetworkController.GET, linkedNamesGuardUrl, "linked_pages_guard", new RequestNetwork.RequestListener() {
					@Override
					public void onResponse(String tag, String response, java.util.HashMap<String, Object> responseHeaders) {
						final java.util.HashSet<String> protectedLinkedPageNames = new java.util.HashSet<>();
						boolean guardTrusted = false;
						
						if (safeIO.looksLikeNotFound(response)) {
							guardTrusted = true; // لا يوجد ملف صفحات مرتبطة أصلاً
						} else {
							try {
								org.json.JSONObject linkedPagesJson = new org.json.JSONObject(response);
								java.util.Iterator<String> it = linkedPagesJson.keys();
								while (it.hasNext()) protectedLinkedPageNames.add(it.next());
								guardTrusted = true;
							} catch (Exception e) {
								e.printStackTrace(); // رد غير مفهوم (مثلاً بوابة شبكة) → لا نحذف شيئاً
							}
						}
						
						if (guardTrusted) fetchLazyPagesGuardThenCleanup(protectedLinkedPageNames);
					}

					// [جديد] صفحات app_lazy_pages.json: مسجّلة عمداً خارج apppages.json (لا تُحمَّل تلقائياً عند فتح
					// التطبيق، فقط عند طلب المستخدم عبر window.RosTrickPages.download) — يجب حمايتها من حذف
					// "الصفحات اليتيمة" بالأسفل بنفس منطق app_linked_pages.json تماماً، وإلا تُحذف نسختها المحلية
					// في أول إغلاق/فتح للتطبيق بعد تحميلها يدوياً فتضيع الفكرة كلها.
					private void fetchLazyPagesGuardThenCleanup(final java.util.HashSet<String> protectedLinkedPageNames) {
						RequestNetwork lazyPagesGuard = new RequestNetwork(MainActivity.this);
						lazyPagesGuard.startRequestNetwork(RequestNetworkController.GET, ASSET_BASE_URL + "app_lazy_pages.json", "lazy_pages_guard", new RequestNetwork.RequestListener() {
							@Override
							public void onResponse(String tag, String response, java.util.HashMap<String, Object> responseHeaders) {
								boolean lazyGuardTrusted = false;
								if (safeIO.looksLikeNotFound(response)) {
									lazyGuardTrusted = true; // لا توجد صفحات يدوية أصلاً
								} else {
									try {
										org.json.JSONObject lazyPagesJson = new org.json.JSONObject(response);
										java.util.Iterator<String> it2 = lazyPagesJson.keys();
										while (it2.hasNext()) protectedLinkedPageNames.add(it2.next());
										lazyGuardTrusted = true;
									} catch (Exception e) {
										e.printStackTrace(); // رد غير مفهوم → لا نحذف شيئاً هذه المرة لتجنّب حذف صفحة يدوية خطأً
									}
								}
								if (lazyGuardTrusted) runHtmlCleanup(protectedLinkedPageNames);
							}

							@Override
							public void onErrorResponse(String tag, String message) {
								// فشل الشبكة: لا نعرف الصفحات اليدوية المحمية، فنتخطى التنظيف هذه المرة بالكامل
							}
						});
					}

					@Override
					public void onErrorResponse(String tag, String message) {
						// فشل الشبكة: لا نعرف الصفحات المحمية، فنتخطى التنظيف هذه المرة
					}
					
					private void runHtmlCleanup(final java.util.HashSet<String> protectedLinkedPageNames) {
						RequestNetwork htmlCleanerAp = new RequestNetwork(MainActivity.this);
						htmlCleanerAp.startRequestNetwork(RequestNetworkController.GET, APP_PAGES_URL, "clean_html_files_ap", new RequestNetwork.RequestListener() {
							@Override
							public void onResponse(String tag, String response, java.util.HashMap<String, Object> responseHeaders) {
								java.util.HashSet<String> currentFiles = new java.util.HashSet<>();
								boolean appPagesOk = false;
								if (response != null && response.trim().length() > 0) {
									try {
										org.json.JSONObject pagesJson = new org.json.JSONObject(response);
										java.util.Iterator<String> keys = pagesJson.keys();
										while (keys.hasNext()) currentFiles.add(keys.next().trim());
										appPagesOk = true;
									} catch (Exception e) {
										e.printStackTrace();
									}
								}
								if (appPagesOk) cleanupLocalHtmlFiles(currentFiles);
							}
							
							@Override
							public void onErrorResponse(String tag, String message) {}
							
							private void cleanupLocalHtmlFiles(java.util.HashSet<String> keepFiles) {
								try {
									java.io.File dir = new java.io.File(baseLocalPath);
									java.io.File[] localFiles = dir.listFiles();
									if (localFiles != null) {
										boolean deletedAny = false;
										for (java.io.File file : localFiles) {
											String name = file.getName();
											if (name.toLowerCase().endsWith(".html")) {
												if (!keepFiles.contains(name) && !protectedLinkedPageNames.contains(name)) {
													file.delete();
													deletedAny = true;
												}
											}
										}
										if (deletedAny) {
											runOnUiThread(new Runnable() {
												@Override
												public void run() {
													try { dynamicWebView.clearCache(true); } catch (Exception ignore) {}
												}
											});
										}
									}
								} catch (Exception e) {
									e.printStackTrace();
								}
							}
						});
					}
				});
				
				// 3. التحقق من تحديثات الإصدار والتنزيل
				// === [إصلاح جذري] مبدأ "الإصدار آخر شيء":
				//     لا يُحفظ current_version إلا بعد نجاح تنزيل كل ملفات المشروع وأصوله، ثم يُنزَّل version.txt مرة أخيرة
				//     للتأكد أنه لم يتغير أثناء التحديث. أي فشل (انقطاع/مهلة/ملف مبتور) => لا يُحفظ الإصدار
				//     فيُعاد التحديث كاملاً عند الفتح التالي بدل اعتباره مكتملاً. ===
				final android.app.ProgressDialog progressDialog = new android.app.ProgressDialog(MainActivity.this);
				progressDialog.setMessage(RtI18n.t("جاري تحديث المكتبات والصور الشاملة...", "Updating libraries and images..."));
				progressDialog.setProgressStyle(android.app.ProgressDialog.STYLE_HORIZONTAL);
				progressDialog.setIndeterminate(true);
				progressDialog.setCancelable(false);
				activeProgressDialog[0] = progressDialog;
				
				final android.content.SharedPreferences sp = MainActivity.this.getSharedPreferences("app_version_pref", android.content.Context.MODE_PRIVATE);
				final String localVersion = sp.getString("current_version", "0");
				
				RequestNetwork versionChecker = new RequestNetwork(MainActivity.this);
				String versionUrl = ASSET_BASE_URL + "version.txt";
				
				versionChecker.startRequestNetwork(RequestNetworkController.GET, versionUrl, "version_tag", new RequestNetwork.RequestListener() {
					@Override
					public void onResponse(String tag, final String onlineVersionResponse, java.util.HashMap<String, Object> responseHeaders) {
						if (safeIO.looksLikeNotFound(onlineVersionResponse)) return;
						
						final String cleanOnlineVersion = onlineVersionResponse.trim();
						if (cleanOnlineVersion.equals(localVersion)) {
							// لا تحديث للملفات؛ لكن لو فشل تنزيل الصفحات المرتبطة آخر مرة نعيد المحاولة لها فقط
							retryPendingLinkedPages();
							retryPendingImages();
							return;
						}
						
						// === [إصلاح 5] لا مسح مسبق: كل الصور تُعاد وتُستبدل ذرّياً أثناء التحديث (فلا تبقى بلا صور لو انقطع التحديث) ===
						
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								if (!MainActivity.this.isFinishing() && !appBlockedByStatus[0]) {
									try { progressDialog.show(); } catch (Exception e) { e.printStackTrace(); }
								}
							}
						});
						
						RequestNetwork updater = new RequestNetwork(MainActivity.this);
						String indexUrl = ASSET_BASE_URL + "home.html";
						
						updater.startRequestNetwork(RequestNetworkController.GET, indexUrl, "update_tag", new RequestNetwork.RequestListener() {
							@Override
							public void onResponse(String tag, final String indexResponse, java.util.HashMap<String, Object> responseHeaders) {
								final String local_path = baseLocalPath + "home.html";
								
								if (safeIO.looksLikeNotFound(indexResponse)) {
									java.io.File f = new java.io.File(local_path);
									if (f.exists()) f.delete();
									sp.edit().putString("current_version", "0").commit();
									runOnUiThread(new Runnable() {
										@Override
										public void run() {
											try { if (progressDialog.isShowing()) progressDialog.dismiss(); } catch (Exception ignore) {}
											if (!appBlockedByStatus[0]) load404Page.run();
										}
									});
									return;
								}
								
								RequestNetwork listUpdaterAp = new RequestNetwork(MainActivity.this);
								listUpdaterAp.startRequestNetwork(RequestNetworkController.GET, APP_PAGES_URL, "list_tag_ap", new RequestNetwork.RequestListener() {
									@Override
									public void onResponse(String tag, String response, java.util.HashMap<String, Object> responseHeaders) {
										final java.util.ArrayList<String> allFilesToSync = new java.util.ArrayList<>();
										boolean appPagesOk = false;
										
										if (response != null && response.trim().length() > 0) {
											try {
												org.json.JSONObject pagesJson = new org.json.JSONObject(response);
												java.util.Iterator<String> keys = pagesJson.keys();
												while (keys.hasNext()) {
													String fileName = keys.next().trim();
													if (fileName.length() > 0 && !fileName.startsWith(".") && !fileName.equalsIgnoreCase("README.md")) {
														allFilesToSync.add(fileName);
													}
												}
												appPagesOk = true;
											} catch (Exception e) {
												e.printStackTrace();
											}
										}
										
										if (appPagesOk) {
											downloadAllSyncFiles(allFilesToSync, indexResponse, local_path, cleanOnlineVersion, sp, progressDialog);
										} else {
											abortUpdate(progressDialog);
										}
									}
									
									@Override
									public void onErrorResponse(String tag, String message) {
										abortUpdate(progressDialog);
									}
								});
							}
							
							@Override
							public void onErrorResponse(String tag, String message) {
								abortUpdate(progressDialog);
							}
						});
					}
					
					@Override
					public void onErrorResponse(String tag, String message) {}
					
					// ---------- أدوات مساعدة للواجهة ----------
					private void setProgressUi(final android.app.ProgressDialog pd, final String msg, final int max, final int value) {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								try {
									if (msg != null) pd.setMessage(msg);
									if (max > 0) { pd.setIndeterminate(false); pd.setMax(max); }
									pd.setProgress(value);
								} catch (Exception ignore) {}
							}
						});
					}
					
					private void abortUpdate(final android.app.ProgressDialog pd) {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								try { if (pd.isShowing()) pd.dismiss(); } catch (Exception ignore) {}
								if (!appBlockedByStatus[0]) SketchwareUtil.showMessage(getApplicationContext(), RtI18n.t("⚠️ تعذّر إكمال التحديث، سيُعاد تلقائياً عند الفتح التالي", "⚠️ Could not finish the update. It will retry automatically the next time you open the app."));
							}
						});
					}
					
					private void retryPendingLinkedPages() {
						if (!sp.getBoolean("linked_pages_pending", false)) return;
						new Thread(new Runnable() {
							@Override
							public void run() {
								linkedPagesFailures.set(0);
								downloadLinkedPagesFlow.run();
								sp.edit().putBoolean("linked_pages_pending", linkedPagesFailures.get() > 0).commit();
							}
						}).start();
					}
					
					// === [إصلاح 7] صور خارجية فشل تنزيلها أثناء التحديث: تُعاد المحاولة لها بالفتح التالي (بدل الفشل الصامت) ===
					private void retryPendingImages() {
						final android.content.SharedPreferences pp = MainActivity.this.getSharedPreferences("secured_images_pending", android.content.Context.MODE_PRIVATE);
						final java.util.Set<String> savedImgs = pp.getStringSet("urls", null);
						final java.util.Set<String> savedStatic = pp.getStringSet("static_urls", null);
						if ((savedImgs == null || savedImgs.isEmpty()) && (savedStatic == null || savedStatic.isEmpty())) return;
						final java.util.ArrayList<String> imgList = new java.util.ArrayList<>(savedImgs == null ? new java.util.HashSet<String>() : savedImgs);
						final java.util.ArrayList<String> staticList = new java.util.ArrayList<>(savedStatic == null ? new java.util.HashSet<String>() : savedStatic);
						new Thread(new Runnable() {
							@Override
							public void run() {
								java.util.HashSet<String> remainingImgs = new java.util.HashSet<>();
								java.util.HashSet<String> remainingStatic = new java.util.HashSet<>();
								try {
									android.content.SharedPreferences mp = MainActivity.this.getSharedPreferences("secured_images_mime", android.content.Context.MODE_PRIVATE);
									android.content.SharedPreferences up = MainActivity.this.getSharedPreferences("secured_images_url_map", android.content.Context.MODE_PRIVATE);
									android.content.SharedPreferences sp2 = MainActivity.this.getSharedPreferences("secured_static_mime", android.content.Context.MODE_PRIVATE);
									for (String u : imgList) {
										String lu = u.toLowerCase();
										String cu = lu.split("\\?")[0].split("#")[0];
										String name = "img_secured_" + Math.abs(u.hashCode());
										String[] ct = new String[1];
										int r = safeIO.downloadToFile(u, new java.io.File(baseLocalPath + name), 10000, 2, ct, false);
										if (r == safeIO.OK) {
											mp.edit().putString(name, safeIO.imageMime(ct[0], lu, cu)).apply();
											up.edit().putString(name, u).apply();
										} else if (r == safeIO.FAIL) {
											remainingImgs.add(u);
										}
									}
									for (String u : staticList) {
										String lu = u.toLowerCase();
										String cu = lu.split("\\?")[0].split("#")[0];
										String name = "static_" + Math.abs(u.hashCode());
										java.io.File f = new java.io.File(baseLocalPath + name);
										String[] ct = new String[1];
										int r = safeIO.downloadToFile(u, f, 10000, 2, ct, true);
										if (r == safeIO.OK) {
											sp2.edit().putString(name, safeIO.staticMimeFor(ct[0], lu, cu, f)).apply();
										} else if (r == safeIO.FAIL) {
											remainingStatic.add(u);
										}
									}
								} catch (Throwable t) {
									t.printStackTrace();
									remainingImgs.addAll(imgList);
									remainingStatic.addAll(staticList);
								}
								pp.edit().putStringSet("urls", remainingImgs).putStringSet("static_urls", remainingStatic).commit();
							}
						}).start();
					}
					
					// ---------- المرحلة 1: مزامنة ملفات المشروع (ذرّياً وبعدّاد فشل) ----------
					private void downloadAllSyncFiles(final java.util.ArrayList<String> allFilesToSync, final String indexResponse, final String local_path, final String cleanOnlineVersion, final android.content.SharedPreferences sp, final android.app.ProgressDialog progressDialog) {
						final java.util.concurrent.atomic.AtomicInteger failed = new java.util.concurrent.atomic.AtomicInteger(0);
						final java.util.ArrayList<String> htmlContentsList = new java.util.ArrayList<>();
						// === [إصلاح 2/4] كل عنصر = "رابط_القاعدة@@PB@@المحتوى" ليُحلّ المسار النسبي من مجلد الصفحة نفسها ===
						htmlContentsList.add(ASSET_BASE_URL + "@@PB@@" + indexResponse);
						
						final java.util.ArrayList<String> files = new java.util.ArrayList<>();
						for (String f : allFilesToSync) {
							String lower = f.toLowerCase();
							if (lower.equals("home.html") || lower.equals("version.txt") || safeIO.isMediaExt(lower)) continue;
							if (f.contains("..") || f.startsWith("/") || f.contains("\\")) continue;
							files.add(f);
						}
						
						final int totalFiles = files.size();
						if (totalFiles == 0) {
							scanAndDownloadAllAssetsDeep(htmlContentsList, indexResponse, local_path, cleanOnlineVersion, sp, progressDialog, failed);
							return;
						}
						
						setProgressUi(progressDialog, null, totalFiles, 0);
						final java.util.concurrent.atomic.AtomicInteger done = new java.util.concurrent.atomic.AtomicInteger(0);
						final java.util.concurrent.ExecutorService pool = java.util.concurrent.Executors.newFixedThreadPool(4);
						
						for (final String fileName : files) {
							pool.execute(new Runnable() {
								@Override
								public void run() {
									try {
										java.io.File target = new java.io.File(baseLocalPath + fileName);
										java.io.File parent = target.getParentFile();
										if (parent != null && !parent.exists()) parent.mkdirs();
										
										String remote = ASSET_BASE_URL + android.net.Uri.encode(fileName, "/");
										int res = safeIO.downloadToFile(remote, target, 15000, 2, null, true);
										if (res == safeIO.FAIL) {
											failed.incrementAndGet();
										} else if (res == safeIO.OK) {
											String lf = fileName.toLowerCase();
											boolean pageLike = lf.endsWith(".html") || lf.endsWith(".htm") || lf.endsWith(".css");
											boolean textLike = pageLike || lf.endsWith(".js") || lf.endsWith(".json") || lf.endsWith(".svg");
											if (textLike) {
												String txt = safeIO.readText(target);
												if (txt != null) {
													String dirPart = "";
													int slashIdx = fileName.lastIndexOf('/');
													if (slashIdx >= 0) dirPart = fileName.substring(0, slashIdx + 1);
													String pageBase = pageLike ? (ASSET_BASE_URL + android.net.Uri.encode(dirPart, "/")) : ASSET_BASE_URL;
													synchronized (htmlContentsList) { htmlContentsList.add(pageBase + "@@PB@@" + txt); }
												}
											}
										}
									} catch (Throwable t) {
										t.printStackTrace();
										failed.incrementAndGet();
									}
									
									int n = done.incrementAndGet();
									setProgressUi(progressDialog, null, 0, n);
									if (n == totalFiles) {
										pool.shutdown();
										if (failed.get() > 0) {
											abortUpdate(progressDialog);
										} else {
											scanAndDownloadAllAssetsDeep(htmlContentsList, indexResponse, local_path, cleanOnlineVersion, sp, progressDialog, failed);
										}
									}
								}
							});
						}
					}
					
					// ---------- المرحلة 2: استخراج روابط الصور والمكتبات والخطوط ----------
					// === [إصلاح 9] روابط مجهولة تُفحص بالخادم، وما ثبت أنه صورة يُنزَّل كصورة مهما كان موقعه ===
					private final java.util.LinkedHashSet<String> probeUrls = new java.util.LinkedHashSet<>();
					private final java.util.Set<String> forcedImageUrls = java.util.Collections.synchronizedSet(new java.util.HashSet<String>());
					private final java.util.Set<String> forcedStaticUrls = java.util.Collections.synchronizedSet(new java.util.HashSet<String>());
					
					private void collectAsset(String rawPath, String baseUrl, String pageBase, boolean probe, java.util.HashSet<String> urlsToDownloadSet, java.util.LinkedHashSet<String> cssUrlsToFetch) {
						if (rawPath == null) return;
						String fullUrl = rawPath.trim()
						.replace("&amp;", "&").replace("\\u0026", "&").replace("\\/", "/");
						if (fullUrl.length() == 0 || fullUrl.startsWith("data:") || fullUrl.startsWith("blob:") || fullUrl.startsWith("#")
						|| fullUrl.startsWith("javascript:") || fullUrl.startsWith("mailto:") || fullUrl.startsWith("tel:") || fullUrl.startsWith("file:")) return;
						
						if (fullUrl.startsWith("//")) {
							fullUrl = "https:" + fullUrl; // رابط بلا بروتوكول
						} else if (!fullUrl.startsWith("http://") && !fullUrl.startsWith("https://")) {
							// === [إصلاح 4] حلّ المسار النسبي من مجلد الصفحة الفعلي (يدعم ../ و ./ بشكل صحيح)،
							//     ويرجع للأسلوب القديم (من الجذر) لو كان المسار يبدأ بـ / أو خرج عن ASSET_BASE_URL ===
							String rel = fullUrl.replace(" ", "%20");
							String resolved = null;
							boolean externalBase = !pageBase.startsWith(baseUrl); // ملف CSS/JS خارجي: كل مساراته (حتى /x) تُحل من موقعه هو
							if (!rel.startsWith("/") || externalBase) {
								try {
									resolved = new java.net.URL(new java.net.URL(pageBase), rel).toString();
									if (!externalBase && !resolved.startsWith(baseUrl)) resolved = null;
								} catch (Exception e) {
									resolved = null;
								}
							}
							if (resolved == null) {
								String cleanPath = rel.replace("../", "").replace("./", "");
								if (cleanPath.startsWith("/")) cleanPath = cleanPath.substring(1);
								resolved = baseUrl + cleanPath;
							}
							fullUrl = resolved;
						}
						
						String lowerUrl = fullUrl.toLowerCase();
						String cleanUrlForExt = lowerUrl.split("\\?")[0].split("#")[0];
						
						// الميديا لها خدمتها المستقلة، والصفحات لا تُخزَّن كأصول
						if (safeIO.isMediaExt(cleanUrlForExt) || cleanUrlForExt.endsWith(".html") || cleanUrlForExt.endsWith(".htm") || cleanUrlForExt.endsWith(".php")) return;
						
						if (cleanUrlForExt.endsWith(".css") || lowerUrl.contains(".css") || lowerUrl.contains("fonts.googleapis.com/css")) {
							cssUrlsToFetch.add(fullUrl);
						}
						
						// === [إصلاح 8] الأهلية تتبع نفس شرط وقت العرض (isImageUrl): كان unsplash/picsum/pexels/pixabay/cloudinary
						//     وروابط /image تُرفض هنا رغم أن المعترض يعتبرها صوراً، فلا تُنزَّل أبداً وقت التحديث ===
						// === [إصلاح 10] نفس شرطَي وقت العرض بالضبط (صور + مكتبات/خطوط): مصدر واحد للحقيقة ===
						boolean eligible = safeIO.isImageUrl(lowerUrl, cleanUrlForExt) || safeIO.isStaticUrl(lowerUrl, cleanUrlForExt);
						if (eligible) {
							urlsToDownloadSet.add(fullUrl);
						} else if (probe && probeUrls.size() < 300 && (lowerUrl.startsWith("http://") || lowerUrl.startsWith("https://")) && !safeIO.skipProbe(lowerUrl, cleanUrlForExt)) {
							probeUrls.add(fullUrl);
						}
					}
					
					private String resolveCssUrl(String cssUrlNoQuery, String path) {
						try {
							if (path.startsWith("http://") || path.startsWith("https://")) return path;
							if (path.startsWith("//")) return "https:" + path;
							return new java.net.URL(new java.net.URL(cssUrlNoQuery), path).toString();
						} catch (Exception e) {
							return null;
						}
					}
					
					private void scanAndDownloadAllAssetsDeep(final java.util.ArrayList<String> pagesContent, final String indexData, final String path, final String newVersion, final android.content.SharedPreferences sharedPrefs, final android.app.ProgressDialog dialog, final java.util.concurrent.atomic.AtomicInteger failed) {
						final java.util.HashSet<String> urlsToDownloadSet = new java.util.HashSet<>();
						final java.util.LinkedHashSet<String> cssUrlsToFetch = new java.util.LinkedHashSet<>();
						final String baseUrl = ASSET_BASE_URL;
						
						setProgressUi(dialog, RtI18n.t("جاري فحص الأصول والخطوط...", "Checking assets and fonts..."), 0, 0);
						probeUrls.clear();
						forcedImageUrls.clear();
						forcedStaticUrls.clear();
						
						// روابط <a href> العادية (صفحات ومواقع) لا تُفحص بالخادم، حفاظاً على الأمان وعلى سرعة التحديث
						final java.util.HashSet<String> hrefUrls = new java.util.HashSet<>();
						java.util.regex.Pattern hrefOnly = java.util.regex.Pattern.compile("(?i)\\bhref\\s*=\\s*['\"]([^'\"]+)['\"]");
						for (String pe : pagesContent) {
							if (pe == null) continue;
							java.util.regex.Matcher hm = hrefOnly.matcher(pe);
							while (hm.find()) hrefUrls.add(hm.group(1).trim().replace("&amp;", "&"));
						}
						
						// === [إصلاح 2] نمط إضافي يلتقط أي نص بين علامتي اقتباس ينتهي بامتداد صورة (داخل JS/JSON/HTML المضمّن) ===
						java.util.regex.Pattern jsPattern = java.util.regex.Pattern.compile("(?i)['\"`]([^'\"`\\s<>()]+?)\\.(jpg|jpeg|jfif|png|apng|webp|gif|svg|avif|bmp|ico)(\\?[^'\"`\\s<>]*)?['\"`]");
						java.util.regex.Pattern urlTextPattern = java.util.regex.Pattern.compile("(?i)https?:(?://|\\\\/\\\\/)[^\\s'\"`<>()\\\\]+");
						java.util.regex.Pattern pattern = java.util.regex.Pattern.compile("(?i)\\b(src|srcset|href|data-src|data-srcset|data-bg|data-background|data-image|data-lazy|data-original|poster|xlink:href)\\s*=\\s*['\"]([^'\"]+)['\"]|url\\(['\"]?([^'\")]+)['\"]?\\)");
						for (String pageEntry : pagesContent) {
							if (pageEntry == null) continue;
							String pageBase = baseUrl;
							String htmlContent = pageEntry;
							int sepIdx = pageEntry.indexOf("@@PB@@");
							if (sepIdx >= 0) {
								pageBase = pageEntry.substring(0, sepIdx);
								htmlContent = pageEntry.substring(sepIdx + 6);
							}
							
							// === [إصلاح 8] أي رابط كامل داخل النص (حتى بلا امتداد، مثل روابط unsplash داخل JS/JSON) يُمرَّر لشرط الأهلية ===
							java.util.regex.Matcher urlMatcher = urlTextPattern.matcher(htmlContent);
							while (urlMatcher.find()) {
								String foundUrl = urlMatcher.group().replace("&amp;", "&");
								collectAsset(foundUrl, baseUrl, pageBase, !hrefUrls.contains(foundUrl), urlsToDownloadSet, cssUrlsToFetch);
							}
							
							java.util.regex.Matcher jsMatcher = jsPattern.matcher(htmlContent);
							while (jsMatcher.find()) {
								String jsPart = jsMatcher.group(1);
								if (jsPart == null || jsPart.contains("${") || jsPart.contains("{{")) continue;
								collectAsset(jsPart + "." + jsMatcher.group(2) + (jsMatcher.group(3) != null ? jsMatcher.group(3) : ""), baseUrl, pageBase, true, urlsToDownloadSet, cssUrlsToFetch);
							}
							
							java.util.regex.Matcher matcher = pattern.matcher(htmlContent);
							while (matcher.find()) {
								String attr = matcher.group(1);
								if (attr != null) {
									String val = matcher.group(2);
									if (val != null && (attr.equalsIgnoreCase("srcset") || attr.equalsIgnoreCase("data-srcset"))) {
										// srcset يحوي عدة روابط مفصولة بفواصل مع واصفات (2x / 480w)
										for (String cand : val.split(",")) {
											String u = cand.trim();
											int spaceIdx = u.indexOf(' ');
											if (spaceIdx > 0) u = u.substring(0, spaceIdx);
											collectAsset(u, baseUrl, pageBase, true, urlsToDownloadSet, cssUrlsToFetch);
										}
									} else {
										collectAsset(val, baseUrl, pageBase, !attr.equalsIgnoreCase("href"), urlsToDownloadSet, cssUrlsToFetch);
									}
								} else {
									collectAsset(matcher.group(3), baseUrl, pageBase, true, urlsToDownloadSet, cssUrlsToFetch);
								}
							}
						}
						
						new Thread(new Runnable() {
							@Override
							public void run() {
								try {
									// === [إصلاح 11] زحف تبعيات المكتبات حتى 3 مستويات (حد أقصى 150 ملفاً):
									//     CSS: url() و @import (حتى لو متداخل)، JS خارجي: import/export from/import()/importScripts ===
									java.util.regex.Pattern cssRefPattern = java.util.regex.Pattern.compile("(?i)url\\(\\s*['\"]?([^'\")]+?)['\"]?\\s*\\)|@import\\s+['\"]([^'\"]+)['\"]");
									java.util.regex.Pattern jsImportPattern = java.util.regex.Pattern.compile("(?:\\bfrom\\s*|\\bimport\\s*\\(?\\s*|\\bimportScripts\\s*\\(\\s*)['\"]([^'\"\\s]+)['\"]");
									java.util.HashSet<String> crawled = new java.util.HashSet<>();
									for (int round = 0; round < 3 && crawled.size() < 150; round++) {
										java.util.ArrayList<String> cssNow = new java.util.ArrayList<>();
										for (String cu : cssUrlsToFetch) if (!crawled.contains(cu)) cssNow.add(cu);
										java.util.ArrayList<String> jsNow = new java.util.ArrayList<>();
										synchronized (urlsToDownloadSet) {
											for (String du : urlsToDownloadSet) {
												String ld = du.toLowerCase();
												String cd = ld.split("\\?")[0].split("#")[0];
												boolean jsLike = cd.endsWith(".js") || cd.endsWith(".mjs") || ld.contains("esm.sh") || ld.contains("+esm") || ld.contains("skypack") || ld.contains("jspm");
												if (jsLike && !crawled.contains(du) && !safeIO.isOwnHost(du)) jsNow.add(du);
											}
										}
										if (cssNow.isEmpty() && jsNow.isEmpty()) break;
										
										for (String cssUrl : cssNow) {
											crawled.add(cssUrl);
											int[] st = new int[1];
											String cssText = safeIO.fetchText(cssUrl, 8000, st);
											if (cssText == null) {
												// فشل مؤقت في ملف CSS خاص بالمشروع يُحسب فشلاً؛ الروابط الخارجية best-effort
												if (safeIO.isOwnHost(cssUrl) && (st[0] < 0 || st[0] >= 500)) failed.incrementAndGet();
												continue;
											}
											String cssNoQuery = cssUrl.split("[?#]")[0];
											java.util.regex.Matcher cssMatcher = cssRefPattern.matcher(cssText);
											while (cssMatcher.find()) {
												String ref = cssMatcher.group(1) != null ? cssMatcher.group(1) : cssMatcher.group(2);
												if (ref == null) continue;
												collectAsset(ref.trim(), baseUrl, cssNoQuery, true, urlsToDownloadSet, cssUrlsToFetch);
											}
										}
										
										for (String jsUrl : jsNow) {
											crawled.add(jsUrl);
											int[] st = new int[1];
											String jsText = safeIO.fetchText(jsUrl, 8000, st);
											if (jsText == null) continue;
											if (jsText.length() > 3000000) jsText = jsText.substring(0, 3000000);
											String jsNoQuery = jsUrl.split("[?#]")[0];
											java.util.regex.Matcher jm = jsImportPattern.matcher(jsText);
											while (jm.find()) {
												String spec = jm.group(1);
												if (spec == null) continue;
												if (spec.startsWith("./") || spec.startsWith("../") || spec.startsWith("/") || spec.startsWith("http://") || spec.startsWith("https://")) {
													collectAsset(spec, baseUrl, jsNoQuery, true, urlsToDownloadSet, cssUrlsToFetch);
												}
											}
										}
									}
								} catch (Throwable t) {
									t.printStackTrace();
								}
								
								// === [إصلاح 9] فحص الروابط المجهولة (4 بالتوازي، مهلة 6 ثوانٍ لكل رابط، حد أقصى 300 رابط) ===
								try {
									if (!probeUrls.isEmpty()) {
										setProgressUi(dialog, RtI18n.t("جاري فحص روابط الصور...", "Checking image links..."), 0, 0);
										final java.util.ArrayList<String> probeList = new java.util.ArrayList<>(probeUrls);
										final java.util.concurrent.ExecutorService probePool = java.util.concurrent.Executors.newFixedThreadPool(4);
										for (final String pu : probeList) {
											probePool.execute(new Runnable() {
												@Override
												public void run() {
													try {
														String kind = safeIO.probeKind(pu, 6000);
														if ("i".equals(kind)) {
															forcedImageUrls.add(pu);
															synchronized (urlsToDownloadSet) { urlsToDownloadSet.add(pu); }
														} else if ("s".equals(kind)) {
															forcedStaticUrls.add(pu);
															synchronized (urlsToDownloadSet) { urlsToDownloadSet.add(pu); }
														}
													} catch (Throwable ignoreProbe) {}
												}
											});
										}
										probePool.shutdown();
										probePool.awaitTermination(90, java.util.concurrent.TimeUnit.SECONDS);
										probePool.shutdownNow();
									}
								} catch (Throwable t) {
									t.printStackTrace();
								}
								synchronized (urlsToDownloadSet) {
									startFinalDownload(new java.util.HashSet<String>(urlsToDownloadSet), indexData, path, newVersion, sharedPrefs, dialog, failed);
								}
							}
						}).start();
					}
					
					// ---------- المرحلة 3: تنزيل الأصول (ذرّياً + تسجيل MIME وخريطة الرابط للصور) ----------
					private void startFinalDownload(java.util.HashSet<String> finalUrls, final String indexData, final String path, final String newVersion, final android.content.SharedPreferences sharedPrefs, final android.app.ProgressDialog dialog, final java.util.concurrent.atomic.AtomicInteger failed) {
						final android.content.SharedPreferences mimePrefs = MainActivity.this.getSharedPreferences("secured_images_mime", android.content.Context.MODE_PRIVATE);
						final android.content.SharedPreferences urlMapPrefs = MainActivity.this.getSharedPreferences("secured_images_url_map", android.content.Context.MODE_PRIVATE);
						
						// === [إصلاح 5/3] الصور المخزّنة سابقاً (ومنها التي حُمّلت وقت التشغيل بلا امتداد أو من JS) تُحدَّث أيضاً مع كل إصدار ===
						final java.util.HashSet<String> cachedImageUrls = new java.util.HashSet<>();
						try {
							for (java.util.Map.Entry<String, ?> en : urlMapPrefs.getAll().entrySet()) {
								String su = (en.getValue() == null) ? "" : en.getValue().toString();
								if (su.startsWith("http://") || su.startsWith("https://")) cachedImageUrls.add(su);
							}
						} catch (Exception ignore) {}
						java.util.HashSet<String> mergedUrls = new java.util.HashSet<>(finalUrls);
						mergedUrls.addAll(cachedImageUrls);
						
						if (mergedUrls.isEmpty()) {
							performSaveAndFinish(indexData, path, newVersion, sharedPrefs, dialog, failed);
							return;
						}
						
						final java.util.ArrayList<String> downloadList = new java.util.ArrayList<>(mergedUrls);
						final int totalItems = downloadList.size();
						final java.util.concurrent.atomic.AtomicInteger itemsDone = new java.util.concurrent.atomic.AtomicInteger(0);
						final java.util.Set<String> failedExternal = java.util.Collections.synchronizedSet(new java.util.HashSet<String>());
						final java.util.Set<String> failedStaticExt = java.util.Collections.synchronizedSet(new java.util.HashSet<String>());
						final android.content.SharedPreferences stMimePrefs = MainActivity.this.getSharedPreferences("secured_static_mime", android.content.Context.MODE_PRIVATE);
						final String filesDirPath = MainActivity.this.getApplicationContext().getFilesDir().getAbsolutePath() + "/";
						
						setProgressUi(dialog, RtI18n.t("جاري تنزيل الصور والخطوط...", "Downloading images and fonts..."), totalItems, 0);
						final java.util.concurrent.ExecutorService pool = java.util.concurrent.Executors.newFixedThreadPool(4);
						
						for (final String downloadUrlString : downloadList) {
							pool.execute(new Runnable() {
								@Override
								public void run() {
									try {
										String lowerUrl = downloadUrlString.toLowerCase();
										String cleanUrlForExt = lowerUrl.split("\\?")[0].split("#")[0];
										
										// نفس تصنيف shouldInterceptRequest حتى يتطابق اسم الملف المحفوظ مع ما سيبحث عنه
										boolean asImage = safeIO.isImageUrl(lowerUrl, cleanUrlForExt) || cachedImageUrls.contains(downloadUrlString) || forcedImageUrls.contains(downloadUrlString);
										boolean asStatic = !asImage && (safeIO.isStaticUrl(lowerUrl, cleanUrlForExt) || forcedStaticUrls.contains(downloadUrlString));
										
										if (asImage || asStatic) {
											String localName;
											if (asImage) {
												localName = "img_secured_" + Math.abs(downloadUrlString.hashCode());
											} else {
												localName = "static_" + Math.abs(downloadUrlString.hashCode());
											}
											
											java.io.File file = new java.io.File(filesDirPath + localName);
											// === [إصلاح 5] الصور تُنزَّل دائماً من جديد (حتى بنفس الاسم)؛ التنزيل ذرّي فالنسخة القديمة تبقى لو فشل ===
											if (asImage || !(file.exists() && file.length() > 0 && stMimePrefs.contains(localName))) {
												String[] ctOut = new String[1];
												int res = safeIO.downloadToFile(downloadUrlString, file, 10000, 2, ctOut, asStatic);
												if (res == safeIO.OK) {
													if (asImage) {
														mimePrefs.edit().putString(localName, safeIO.imageMime(ctOut[0], lowerUrl, cleanUrlForExt)).apply();
														urlMapPrefs.edit().putString(localName, downloadUrlString).apply();
													} else {
														stMimePrefs.edit().putString(localName, safeIO.staticMimeFor(ctOut[0], lowerUrl, cleanUrlForExt, file)).apply();
													}
												} else if (res == safeIO.FAIL) {
													if (safeIO.isOwnHost(downloadUrlString)) {
														failed.incrementAndGet();
													} else if (asImage) {
														failedExternal.add(downloadUrlString); // تُعاد المحاولة بالفتح التالي
													} else {
														failedStaticExt.add(downloadUrlString); // مكتبة/خط خارجي: تُعاد المحاولة بالفتح التالي
													}
												} else if (res == safeIO.MISSING && asImage && safeIO.isOwnHost(downloadUrlString)) {
													// صورة حُذفت من الخادم: لا نُبقي نسخة قديمة
													file.delete();
													mimePrefs.edit().remove(localName).apply();
													urlMapPrefs.edit().remove(localName).apply();
												}
											}
										}
									} catch (Throwable t) {
										t.printStackTrace();
									}
									
									int n = itemsDone.incrementAndGet();
									setProgressUi(dialog, null, 0, n);
									if (n == totalItems) {
										pool.shutdown();
										try {
											if (!failedExternal.isEmpty() || !failedStaticExt.isEmpty()) {
												android.content.SharedPreferences pendPrefs = MainActivity.this.getSharedPreferences("secured_images_pending", android.content.Context.MODE_PRIVATE);
												java.util.HashSet<String> pendMerged = new java.util.HashSet<>(pendPrefs.getStringSet("urls", new java.util.HashSet<String>()));
												synchronized (failedExternal) { pendMerged.addAll(failedExternal); }
												java.util.HashSet<String> pendStatic = new java.util.HashSet<>(pendPrefs.getStringSet("static_urls", new java.util.HashSet<String>()));
												synchronized (failedStaticExt) { pendStatic.addAll(failedStaticExt); }
												pendPrefs.edit().putStringSet("urls", pendMerged).putStringSet("static_urls", pendStatic).commit();
											}
										} catch (Throwable ignore) {}
										performSaveAndFinish(indexData, path, newVersion, sharedPrefs, dialog, failed);
									}
								}
							});
						}
					}
					
					// ---------- المرحلة 4 (الأخيرة): حفظ home.html ثم تثبيت الإصدار ----------
					private void performSaveAndFinish(final String data, final String filePath, final String newVersion, final android.content.SharedPreferences prefs, final android.app.ProgressDialog dialog, final java.util.concurrent.atomic.AtomicInteger failed) {
						new Thread(new Runnable() {
							@Override
							public void run() {
								try {
									if (failed.get() > 0) {
										abortUpdate(dialog);
										return;
									}
									
									// 1) حفظ home.html ذرّياً
									if (!safeIO.writeTextAtomic(new java.io.File(filePath), data)) {
										abortUpdate(dialog);
										return;
									}
									
									// 2) آخر تنزيل: version.txt مرة ثانية. لو تغيّر أثناء التحديث فملفات هذه الجلسة قد تكون من إصدارين،
									//    فلا نثبّت شيئاً ويُعاد التحديث من جديد بالفتح التالي. (لو فشل الطلب نفسه نثبّت الإصدار الذي بدأنا به)
									String endVersion = safeIO.fetchText(ASSET_BASE_URL + "version.txt", 8000, null);
									if (endVersion != null && !safeIO.looksLikeNotFound(endVersion) && !endVersion.trim().equals(newVersion)) {
										abortUpdate(dialog);
										return;
									}
									
									// 3) تثبيت الإصدار (commit متزامن)
									prefs.edit().putString("current_version", newVersion).commit();
									
									// 4) الصفحات المرتبطة: best-effort، وعند الفشل تُعاد المحاولة لها وحدها بالفتح التالي
									linkedPagesFailures.set(0);
									downloadLinkedPagesFlow.run();
									prefs.edit().putBoolean("linked_pages_pending", linkedPagesFailures.get() > 0).commit();
									
									runOnUiThread(new Runnable() {
										@Override
										public void run() {
											try { if (dialog != null && dialog.isShowing()) dialog.dismiss(); } catch (Exception ignore) {}
											// === [إصلاح 7/8] لا نستبدل شاشة الإغلاق، ولو فُتح التطبيق من إشعار نعود لصفحته بدل home ===
											if (!appBlockedByStatus[0]) {
												String notifTargetNow = pendingNotificationUrl[0];
												dynamicWebView.loadUrl(notifTargetNow != null ? notifTargetNow : "file://" + filePath);
												SketchwareUtil.showMessage(getApplicationContext(), RtI18n.t("تم التحديث الشامل بنجاح!", "Full update completed successfully!"));
											}
										}
									});
								} catch (Exception e) {
									e.printStackTrace();
									abortUpdate(dialog);
								}
							}
						}).start();
					}
				});
			}
		};
		
		// =======================================================
		// ⚡ الخطوة الحاسمـة: فحص app_status.json أونلاين أولاً بالكامل
		// =======================================================
		RequestNetwork appStatusChecker = new RequestNetwork(MainActivity.this);
		String appStatusUrl = ASSET_BASE_URL + "app_status.json";
		
		// === [جديد] حارس زمني (Watchdog) لمنع الشاشة البيضاء عند الاتصال بشبكة بلا إنترنت فعلي (راوتر/أرضي بلا إنترنت)
		// المشكلة: إذا كان الجهاز متصلاً بشبكة (واي فاي/راوتر) بلا إنترنت فعلي، يعتقد أندرويد أن هناك اتصالاً
		// فتحاول مكتبة RequestNetwork الاتصال الفعلي بالخادم دون مهلة زمنية محددة، فقد ينتظر onResponse/onErrorResponse
		// لفترة طويلة جداً (أو غير محددة)، وخلال هذه الفترة لا يُعرض أي محتوى في الـ WebView -> شاشة بيضاء
		// الحل: مؤقّت احتياطي مدته 5 ثوانٍ فقط، أيهما يصل أولاً (رد الشبكة الحقيقي أو انتهاء المؤقّت) هو من يقرر
		final boolean[] appStatusHandled = {false};
		final Object appStatusLock = new Object();
		
		new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(new Runnable() {
			@Override
			public void run() {
				boolean shouldProceed = false;
				synchronized (appStatusLock) {
					if (!appStatusHandled[0]) {
						appStatusHandled[0] = true;
						shouldProceed = true;
					}
				}
				if (shouldProceed) {
					// لم يصل أي رد من الشبكة خلال 5 ثوانٍ (على الأغلب شبكة متصلة بلا إنترنت فعلي)
					// -> افحص الملف المحلي المحفوظ مسبقاً (نفس منطق onErrorResponse تماماً) ثم تابع بشكل طبيعي فوراً
					try {
						java.io.File statusFile = new java.io.File(baseLocalPath + "app_status.json");
						if (statusFile.exists() && statusFile.length() > 0) {
							java.io.FileInputStream fis = new java.io.FileInputStream(statusFile);
							java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(fis, "UTF-8"));
							StringBuilder sb = new StringBuilder();
							String line;
							while ((line = reader.readLine()) != null) sb.append(line);
							reader.close();
							fis.close();
							
							org.json.JSONObject json = new org.json.JSONObject(sb.toString());
							boolean isClosed = json.optBoolean("is_closed", false);
							boolean isMaintenance = json.optBoolean("is_maintenance", false);
							
							if (isClosed || isMaintenance) {
								displayAppStatusScreen.run();
								return;
							}
						}
					} catch (Exception e) { e.printStackTrace(); }
					
					startNormalAppFlow.run();
				}
			}
		}, 5000);
		
		appStatusChecker.startRequestNetwork(RequestNetworkController.GET, appStatusUrl, "app_status_check", new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String tag, String response, java.util.HashMap<String, Object> responseHeaders) {
				boolean alreadyHandled;
				synchronized (appStatusLock) {
					alreadyHandled = appStatusHandled[0];
					if (!alreadyHandled) appStatusHandled[0] = true;
				}
				// === [إصلاح 8] المؤقّت الاحتياطي (5 ثوانٍ) قد يسبق الرد: لا نتجاهل الرد المتأخر بعد الآن.
				//     نحفظه دائماً، ولو قال "مغلق/صيانة" نعرض الشاشة فوراً، ولو قال "مفتوح" وكنا قد عرضنا إغلاقاً من نسخة قديمة محفوظة نرفعه ===
				final boolean wasLate = alreadyHandled;
				
				final String finalResponse = response;
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						if (finalResponse != null && !finalResponse.trim().isEmpty()) {
							try {
								// 1. تحليل أولاً: لو الرد ليس JSON صالحاً (404 أو صفحة بوابة شبكة) لا نكتب فوق الملف المحفوظ
								org.json.JSONObject json = new org.json.JSONObject(finalResponse);
								
								// 2. حفظ الملف محلياً (ذرّياً)
								safeIO.writeTextAtomic(new java.io.File(baseLocalPath + "app_status.json"), finalResponse);
								boolean isClosed = json.optBoolean("is_closed", false);
								boolean isMaintenance = json.optBoolean("is_maintenance", false);
								
								if (isClosed || isMaintenance) {
									// التطبيق إما مغلق أو تحت الصيانة -> عرض الشاشة وإيقاف كل شيء
									displayAppStatusScreen.run();
									return;
								}
								
								if (wasLate && appBlockedByStatus[0]) {
									// الشاشة المعروضة كانت من نسخة محفوظة قديمة والخادم يقول الآن إن التطبيق مفتوح
									appBlockedByStatus[0] = false;
									startNormalAppFlow.run();
									return;
								}
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
						
						// الرد وصل في وقته والتطبيق سليم -> نبدأ التشغيل العادي (لو كان متأخراً فالتطبيق بدأ أصلاً)
						if (!wasLate) startNormalAppFlow.run();
					}
				});
			}
			
			@Override
			public void onErrorResponse(String tag, String message) {
				boolean alreadyHandled;
				synchronized (appStatusLock) {
					alreadyHandled = appStatusHandled[0];
					if (!alreadyHandled) appStatusHandled[0] = true;
				}
				// المؤقّت الاحتياطي سبقنا وتصرّف بالفعل -> تجاهل هذا الرد المتأخر
				if (alreadyHandled) return;
				
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						// في حال عدم وجود إنترنت، افحص الملف المحفوظ محلياً أوفلاين
						try {
							java.io.File statusFile = new java.io.File(baseLocalPath + "app_status.json");
							if (statusFile.exists() && statusFile.length() > 0) {
								java.io.FileInputStream fis = new java.io.FileInputStream(statusFile);
								java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.InputStreamReader(fis, "UTF-8"));
								StringBuilder sb = new StringBuilder();
								String line;
								while ((line = reader.readLine()) != null) sb.append(line);
								reader.close();
								fis.close();
								
								org.json.JSONObject json = new org.json.JSONObject(sb.toString());
								boolean isClosed = json.optBoolean("is_closed", false);
								boolean isMaintenance = json.optBoolean("is_maintenance", false);
								
								if (isClosed || isMaintenance) {
									displayAppStatusScreen.run();
									return;
								}
							}
						} catch (Exception e) { e.printStackTrace(); }
						
						// إذا لم يكن مغلقاً أوفلاين، استمر بالعمل العادي
						startNormalAppFlow.run();
					}
				});
			}
		});
		
		// === [إصلاح 7] كان الانتقال لصفحة الإشعار يتم بتأخير ثابت 1200ms، فإن تأخرت الشبكة (حتى 5 ثوانٍ) كان التحميل الأساسي
		//     يمحو الصفحة المطلوبة. صار الانتقال داخل startNormalAppFlow مباشرة (انظر pendingNotificationUrl) ===
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		if (rtWebApi != null && rtWebApi.onActivityResult(_requestCode, _resultCode, _data)) return;
		if (rtHw != null && rtHw.onActivityResult(_requestCode, _resultCode, _data)) return;
		// تمرير أي ملف مختار تلقائياً وباسم ونوع الملف الأصلي دون تقييد
		Object tag = getWindow().getDecorView().getTag();
		if (tag instanceof android.webkit.ValueCallback[]) {
			android.webkit.ValueCallback<android.net.Uri[]>[] rawContainer = (android.webkit.ValueCallback[]) tag;
			
			int actualRequestCode = 0;
			int actualResultCode = 0;
			android.content.Intent actualData = null;
			
			// جلب المتغيرات من بيئة سكتشوير ديناميكياً
			try { actualRequestCode = _requestCode; } catch (Exception e) { 
				try { java.lang.reflect.Field f = MainActivity.this.getClass().getDeclaredField("requestCode"); f.setAccessible(true); actualRequestCode = (int) f.get(MainActivity.this); } catch(Exception ex){}
			}
			try { actualResultCode = _resultCode; } catch (Exception e) {
				try { java.lang.reflect.Field f = MainActivity.this.getClass().getDeclaredField("resultCode"); f.setAccessible(true); actualResultCode = (int) f.get(MainActivity.this); } catch(Exception ex){}
			}
			try { actualData = _data; } catch (Exception e) {
				try { java.lang.reflect.Field f = MainActivity.this.getClass().getDeclaredField("data"); f.setAccessible(true); actualData = (android.content.Intent) f.get(MainActivity.this); } catch(Exception ex){}
			}
			
			if (rawContainer[0] != null) {
				android.net.Uri[] results = null;
				
				if (actualResultCode == android.app.Activity.RESULT_OK && actualData != null) {
					// 1. في حال اختيار عدة ملفات معاً
					if (actualData.getClipData() != null) {
						int count = actualData.getClipData().getItemCount();
						results = new android.net.Uri[count];
						for (int i = 0; i < count; i++) {
							results[i] = actualData.getClipData().getItemAt(i).getUri();
						}
					} 
					// 2. في حال اختيار ملف واحد (يتم أخذ الـ Uri الخاص بالملف الأصلي كما هو)
					else if (actualData.getData() != null) {
						results = new android.net.Uri[]{ actualData.getData() };
					}
				}
				
				// إرسال النتيجة للـ WebView (سواء كان ملفاً أو null في حال الإلغاء) لفك التجميد عن زر الـ HTML
				rawContainer[0].onReceiveValue(results);
				rawContainer[0] = null;
			}
		}
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	protected void onPause() {
		super.onPause();
		if (rtAds != null) rtAds.onPause();
		if (rtUnityAds != null) rtUnityAds.onPause();
		if (rtFbAds != null) rtFbAds.onPause();
		if (rtPush != null) rtPush.onPause();
	}

	@Override
	protected void onResume() {
		super.onResume();
		if (rtAds != null) rtAds.onResume();
		if (rtUnityAds != null) rtUnityAds.onResume();
		if (rtFbAds != null) rtFbAds.onResume();
		if (rtPush != null) rtPush.onResume();
	}

	@Override
	protected void onDestroy() {
		if (rtAds != null) rtAds.onDestroy();
		if (rtUnityAds != null) rtUnityAds.onDestroy();
		if (rtFbAds != null) rtFbAds.onDestroy();
		if (rtPush != null) rtPush.onDestroy();
		if (rtBilling != null) rtBilling.onDestroy();
		if (rtWebApi != null) rtWebApi.onDestroy();
		if (rtHw != null) rtHw.onDestroy();
		super.onDestroy();
	}
	
	@Override
	public void onBackPressed() {
		// البحث عن الـ WebView في الشاشة من خلال الرقم التعريفي الخاص به
		android.webkit.WebView myWebView = (android.webkit.WebView) findViewById(99999);
		
		// === [إضافة جديدة] لو فيه فيديو/عنصر بوضع ملء الشاشة (Fullscreen) شغال حالياً، اخرج منه فقط ولا تكمل لأي منطق ثاني
		if (myWebView != null) {
			android.view.ViewParent parentObj = myWebView.getParent();
			if (parentObj instanceof android.widget.FrameLayout) {
				android.widget.FrameLayout parentFrame = (android.widget.FrameLayout) parentObj;
				
				if (parentFrame.getChildCount() > 1) {
					android.view.View extraView = parentFrame.getChildAt(parentFrame.getChildCount() - 1);
					
					// استرجاع الـ callback المخزّن كـ tag على العنصر نفسه (نفس الـ callback اللي مرره WebChromeClient بـ onCreate)
					Object tagObj = extraView.getTag();
					if (tagObj instanceof android.webkit.WebChromeClient.CustomViewCallback) {
						((android.webkit.WebChromeClient.CustomViewCallback) tagObj).onCustomViewHidden();
					}
					
					parentFrame.removeView(extraView);
					myWebView.setVisibility(android.view.View.VISIBLE);
					
					// استرجاع أشرطة النظام لوضعها الطبيعي
					MainActivity.this.getWindow().getDecorView().setSystemUiVisibility(android.view.View.SYSTEM_UI_FLAG_VISIBLE);
					MainActivity.this.getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
					
					return; // توقف هنا - المستخدم خرج من ملء الشاشة بس، ما نرجع صفحة ولا نطلع من التطبيق
				}
			}
		}
		
		// === [جديد] رجوع ذكي يعتمد على سجل تصفح مُنظّف من التكرار (Smart Back Stack) بدل سجل WebView الافتراضي
		// الفكرة: onPageFinished بـ onCreate يخزّن كل صفحة تتم زيارتها، ولو رجعت لصفحة زرتها من قبل بنفس الجلسة
		// يتم "قص" كل اللي بعدها تلقائياً، فما يصير عندك تكرار مزعج بالرجوع خطوة خطوة عبر نفس الحلقة
		try {
			android.content.SharedPreferences backStackPrefs = MainActivity.this.getSharedPreferences("smart_back_stack", android.content.Context.MODE_PRIVATE);
			org.json.JSONArray backStackArray = new org.json.JSONArray(backStackPrefs.getString("stack", "[]"));
			
			if (backStackArray.length() > 1) {
				// احذف الصفحة الحالية (آخر عنصر بالسجل) وخذ اللي قبلها مباشرة كوجهة الرجوع
				backStackArray.remove(backStackArray.length() - 1);
				String previousUrl = backStackArray.optString(backStackArray.length() - 1, "");
				
				backStackPrefs.edit().putString("stack", backStackArray.toString()).apply();
				
				if (myWebView != null && previousUrl != null && !previousUrl.trim().isEmpty()) {
					myWebView.loadUrl(previousUrl);
				} else {
					finish();
				}
			} else {
				// ما فيه صفحة سابقة ذات معنى بالسجل الذكي -> اخرج من التطبيق بأمان
				finish();
			}
		} catch (Exception e) {
			e.printStackTrace();
			// خط دفاع أخير في حال أي خطأ غير متوقع: ارجع لسلوك WebView الافتراضي
			if (myWebView != null && myWebView.canGoBack()) {
				myWebView.goBack();
			} else {
				finish();
			}
		}
	}
}
