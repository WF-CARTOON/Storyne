/* RosTrick — واجهات الصفحات: شريط الحالة (RosTrickStatusBar) و WebView أصلي إضافي (RosTrickWebView).
   تُحقن بعد تحميل كل صفحة، وتتصل بالجسرين RosTrickStatusBarBridge و RosTrickWebViewBridge. */
(function () {
  if (window.__rtNat) return; window.__rtNat = 1;
  var SB = window.RosTrickStatusBarBridge, WV = window.RosTrickWebViewBridge;
  var RT_TOARGB = null;
  var PAGE = Math.random().toString(36).slice(2) + Date.now().toString(36);

  /* ================= شريط الحالة ================= */
  if (SB) (function () {
    var man = {}, last = null, evs = [];
    function norm(k) { return String(k || "").toLowerCase().replace(/[^a-z]/g, ""); }
    var ALIAS = { visibility: "mode", state: "mode", bg: "color", background: "color", iconstyle: "icons", iconcolor: "icons", draw: "overlay", behind: "overlay", animation: "anim", duration: "anim", transition: "anim" };
    function parseCfg(s) {
      var o = {};
      String(s || "").split(/[;,]/).forEach(function (p) {
        p = p.trim(); if (!p) return;
        var m = /^([a-z-]+)\s*[:=]\s*(.+)$/i.exec(p);
        if (m) { var k = norm(m[1]); k = ALIAS[k] || k; o[k] = m[2].trim(); return; }
        var b = p.toLowerCase();
        if (b === "visible" || b === "show") o.mode = "visible";
        else if (b === "hidden" || b === "hide") o.mode = "hidden";
        else if (b === "transparent") o.color = "transparent";
        else if (b === "overlay") o.overlay = "true";
      });
      return o;
    }
    function meta(n) { var m = document.querySelector('meta[name="' + n + '"]'); return m ? String(m.getAttribute("content") || "") : ""; }
    function visEl(e) {
      try {
        if (!e.isConnected) return false; if (e === document.documentElement || e === document.body) return true;
        if (!e.getClientRects().length) return false; var s = getComputedStyle(e);
        if (s.visibility === "hidden" || s.display === "none") return false;
        var b = e.getBoundingClientRect(); return b.width > 0 && b.height > 0;
      } catch (x) { return false; }
    }
    function merge(a, b) { for (var k in b) if (Object.prototype.hasOwnProperty.call(b, k)) a[k] = b[k]; return a; }
    function declared() {
      var c = {}, m = meta("rostrick-statusbar");
      if (m) merge(c, parseCfg(m));
      ["mode", "color", "icons", "overlay", "anim"].forEach(function (k) { var v = meta("rostrick-statusbar-" + k); if (v) c[k] = v.trim(); });
      var n = document.querySelectorAll('[screen="rt_statusbar"]');
      for (var i = 0; i < n.length; i++) { var e = n[i]; if (visEl(e)) merge(c, parseCfg(e.getAttribute("statusbar") || e.getAttribute("data-statusbar") || "")); }
      return c;
    }
    function hex2(h) { return parseInt(h.length === 1 ? h + h : h, 16); }
    function argb(a, r, g, b) { return ((Math.round(a) << 24) | (r << 16) | (g << 8) | b) | 0; }
    var cv;
    function toArgb(c) {
      if (c == null) return undefined; c = String(c).trim().toLowerCase(); if (!c) return undefined;
      if (c === "transparent") return 0;
      var m = /^#([0-9a-f]{3,8})$/.exec(c);
      if (m) {
        var h = m[1];
        if (h.length === 3 || h.length === 4) return argb(h.length === 4 ? hex2(h[3]) : 255, hex2(h[0]), hex2(h[1]), hex2(h[2]));
        if (h.length === 6) return argb(255, parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16));
        if (h.length === 8) return argb(parseInt(h.slice(6, 8), 16), parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16));
        return undefined;
      }
      m = /^rgba?\(\s*([\d.]+)[ ,]+([\d.]+)[ ,]+([\d.]+)(?:\s*[,/]\s*([\d.]+%?))?\s*\)$/.exec(c);
      if (m) { var al = m[4] == null ? 1 : (/%$/.test(m[4]) ? parseFloat(m[4]) / 100 : parseFloat(m[4])); return argb(Math.max(0, Math.min(1, al)) * 255, Math.round(+m[1]), Math.round(+m[2]), Math.round(+m[3])); }
      try {
        cv = cv || document.createElement("canvas"); cv.width = cv.height = 1; var x = cv.getContext("2d");
        x.clearRect(0, 0, 1, 1); x.fillStyle = "#010203"; x.fillStyle = c; x.fillRect(0, 0, 1, 1);
        var d = x.getImageData(0, 0, 1, 1).data;
        if (d[0] === 1 && d[1] === 2 && d[2] === 3 && d[3] === 255) return undefined;
        return argb(d[3], d[0], d[1], d[2]);
      } catch (e) { return undefined; }
    }
    RT_TOARGB = toArgb;
    function lumOf(v) { var r = (v >> 16) & 255, g = (v >> 8) & 255, b = v & 255; return (0.299 * r + 0.587 * g + 0.114 * b) / 255; }
    function pageBg() {
      try {
        var e = document.elementFromPoint(Math.max(1, innerWidth / 2), 2);
        while (e) { var v = toArgb(getComputedStyle(e).backgroundColor); if (v != null && ((v >>> 24) > 10)) return v; e = e.parentElement; }
        var bb = document.body && toArgb(getComputedStyle(document.body).backgroundColor); if (bb != null && bb !== undefined && ((bb >>> 24) > 10)) return bb;
        var r = toArgb(getComputedStyle(document.documentElement).backgroundColor); if (r != null && ((r >>> 24) > 10)) return r;
      } catch (x) {}
      return argb(255, 255, 255, 255);
    }
    function bool(v) { return /^(true|1|yes|on)$/i.test(String(v)); }
    /* الإعداد النهائي المُرسَل للتطبيق (null = لا تحكّم: القيم الافتراضية) */
    function build() {
      var c = merge(declared(), man), keys = Object.keys(c);
      if (!keys.length) return null;
      var p = {};
      if (c.mode != null) { var md = String(c.mode).toLowerCase(); p.mode = (md === "hidden" || md === "hide" || md === "false" || md === "0") ? "hidden" : "visible"; }
      var col = c.color == null ? null : String(c.color).trim().toLowerCase(), av = null, follow = false;
      if (col === "theme") col = meta("theme-color").trim().toLowerCase() || "default";
      if (col === "page" || col === "auto" || col === "follow") { av = pageBg(); follow = true; }
      else if (col && col !== "default") { av = toArgb(col); if (av === undefined) av = null; }
      if (c.color != null) p.argb = av;
      var ic = c.icons == null ? "auto" : String(c.icons).toLowerCase(); p.icons = (ic === "dark" || ic === "light") ? ic : "auto";
      if (c.overlay != null) p.overlay = bool(c.overlay); else if (av === 0) p.overlay = true; else p.overlay = false;
      if (c.anim != null) p.anim = Math.max(0, parseInt(c.anim, 10) || 0);
      p.dark = lumOf(pageBg()) < 0.5; p.follow = follow;
      return p;
    }
    function sync() {
      var p; try { p = build(); } catch (e) { p = null; }
      var j = p ? JSON.stringify(p) : "";
      if (j === last) return; last = j;
      try { if (p) SB.apply(j); else SB.reset(); } catch (e) {}
    }
    var t = 0; function sched() { if (t) return; t = setTimeout(function () { t = 0; sync(); }, 50); }
    try { new MutationObserver(sched).observe(document.documentElement, { subtree: true, childList: true, attributes: true }); } catch (e) {}
    setInterval(sync, 700); document.addEventListener("visibilitychange", sync);
    function state() { try { return JSON.parse(SB.getState()); } catch (e) { return {}; } }
    window.__rtSbUpd = function (j) {
      var s; try { s = JSON.parse(j); } catch (e) { return; }
      try { document.documentElement.style.setProperty("--rt-statusbar-height", (s.height || 0) + "px"); } catch (e) {}
      try { window.dispatchEvent(new CustomEvent("rtstatusbar", { detail: s })); } catch (e) {}
    };
    function setMan(o, v) { if (typeof o === "string") { var k = {}; k[o] = v; o = k; } for (var k2 in o) if (Object.prototype.hasOwnProperty.call(o, k2)) { var nk = ALIAS[norm(k2)] || norm(k2); if (o[k2] === null) delete man[nk]; else man[nk] = o[k2]; } last = null; sync(); }
    window.RosTrickStatusBar = {
      __v: 1,
      set: function (o) { setMan(o); return state(); },
      show: function (o) { var c = o || {}; c.mode = "visible"; setMan(c); return state(); },
      hide: function (o) { var c = o || {}; c.mode = "hidden"; setMan(c); return state(); },
      color: function (c, anim) { var o = { color: c }; if (anim != null) o.anim = anim; setMan(o); },
      icons: function (v) { setMan({ icons: v }); },
      overlay: function (b) { setMan({ overlay: !!b }); },
      peek: function (ms) { try { SB.peek(ms > 0 ? ms | 0 : 2500); } catch (e) {} },
      reset: function () { man = {}; last = null; sync(); },
      get: state,
      get height() { return state().height || 0; }
    };
    sync(); try { window.__rtSbUpd(SB.getState()); } catch (e) {}
  })();

  /* ================= WebView أصلي إضافي ================= */
  if (WV) (function () {
    var H = {}, pend = {}, cbSeq = 0, cache = {}, att = {}, tick = 0;
    try { WV.pageStart(PAGE); } catch (e) {}
    function call(fn) { try { return WV[fn].apply(WV, [].slice.call(arguments, 1)); } catch (e) { return null; } }
    function js(o) { return JSON.stringify(o == null ? {} : o); }
    function emitTo(k, id, type, d) { (H[k] || []).slice().forEach(function (h) { if (h.type === type || h.type === "*") { try { h.fn(d, id, type); } catch (e) { setTimeout(function () { throw e; }); } } }); }
    window.__rtWV = function (id, type, json) {
      var d; try { d = JSON.parse(json); } catch (e) { d = {}; }
      if (type === "eval") { var p = pend[d.cb]; if (p) { delete pend[d.cb]; var v = d.value; try { v = (v === "null" || v == null) ? null : JSON.parse(v); } catch (e) {} p(v); } return; }
      var c = cache[id] || (cache[id] = {});
      if (d.url != null) c.url = d.url; if (d.title != null) c.title = d.title; if (d.canGoBack != null) c.canGoBack = !!d.canGoBack; if (d.canGoForward != null) c.canGoForward = !!d.canGoForward;
      if (type === "progress") c.progress = d.progress;
      emitTo(id, id, type, d); emitTo("*", id, type, d);
      try { window.dispatchEvent(new CustomEvent("rtwebview", { detail: { id: id, type: type, data: d } })); } catch (e) {}
    };
    function rect(el) { var r = el.getBoundingClientRect(); return { x: r.left, y: r.top, w: r.width, h: r.height }; }
    function elVisible(el) { try { if (!el.isConnected || document.hidden) return false; var s = getComputedStyle(el); if (s.display === "none" || s.visibility === "hidden") return false; var r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; } catch (e) { return false; } }
    function tickAll() {
      Object.keys(att).forEach(function (id) {
        var a = att[id], el = a.el;
        if (!el.isConnected) { if (a.vis !== 0) { a.vis = 0; call("setVisible", id, false); } return; }
        var v = elVisible(el) ? 1 : 0;
        if (v) { var r = rect(el), k = [r.x, r.y, r.w, r.h].map(function (n) { return Math.round(n * 2) / 2; }).join(","); if (k !== a.k) { a.k = k; call("setBounds", id, r.x, r.y, r.w, r.h); } }
        if (v !== a.vis) { a.vis = v; if (a.manual !== 0) call("setVisible", id, !!v); }
      });
    }
    function ensureTick() {
      if (tick) return; tick = setInterval(tickAll, 100);
      window.addEventListener("scroll", tickAll, true); window.addEventListener("resize", tickAll);
      try { if (window.visualViewport) window.visualViewport.addEventListener("resize", tickAll); } catch (e) {}
    }
    function on(id, type, fn) { if (typeof type === "function") { fn = type; type = "*"; } (H[id] = H[id] || []).push({ type: type, fn: fn }); return function () { H[id] = (H[id] || []).filter(function (h) { return h.fn !== fn; }); }; }
    /* ألوان CSS -> ARGB رقمي (يقرؤه جانب جافا) */
    function colors(q) { ["barColor", "textColor", "background"].forEach(function (k) { if (q[k] == null || typeof q[k] === "number") return; var v = RT_TOARGB ? RT_TOARGB(q[k]) : undefined; if (v === undefined) delete q[k]; else q[k] = v; }); }
    var API = {
      __v: 1, available: true,
      create: function (o) {
        o = o || {}; var target = o.attach; var bounds = o.bounds || (o.x != null ? { x: o.x, y: o.y, w: o.w, h: o.h } : null);
        if (target) { var el = typeof target === "string" ? document.querySelector(target) : target; if (el) { bounds = rect(el); } }
        var q = {}; for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k) && k !== "attach") q[k] = o[k];
        q.owner = PAGE; colors(q); if (bounds) q.bounds = bounds;
        var id = call("create", js(q));
        if (!id) return Promise.reject(new Error("تعذّر إنشاء WebView (الحد الأقصى أو المعرّف مكرر)"));
        if (target) API.attach(id, target);
        return Promise.resolve(id);
      },
      attach: function (id, target) {
        var el = typeof target === "string" ? document.querySelector(target) : target; if (!el) return false;
        att[id] = { el: el, k: "", vis: -1 }; ensureTick(); try { if (window.ResizeObserver) new ResizeObserver(tickAll).observe(el); } catch (e) {} tickAll(); return true;
      },
      detach: function (id) { delete att[id]; },
      setBounds: function (id, b) { call("setBounds", id, +b.x || 0, +b.y || 0, +b.w || 0, +b.h || 0); },
      show: function (id) { if (att[id]) att[id].manual = 1; return call("setVisible", id, true); },
      hide: function (id) { if (att[id]) att[id].manual = 0; return call("setVisible", id, false); },
      front: function (id) { return call("bringToFront", id); },
      load: function (id, url, headers) { return call("load", id, String(url), headers ? js(headers) : ""); },
      loadHtml: function (id, html, base) { return call("loadHtml", id, String(html), base ? String(base) : ""); },
      reload: function (id) { return call("reload", id); }, stop: function (id) { return call("stop", id); },
      back: function (id) { return call("back", id); }, forward: function (id) { return call("forward", id); },
      canGoBack: function (id) { return !!(cache[id] && cache[id].canGoBack); }, canGoForward: function (id) { return !!(cache[id] && cache[id].canGoForward); },
      url: function (id) { return (cache[id] && cache[id].url) || ""; }, title: function (id) { return (cache[id] && cache[id].title) || ""; }, progress: function (id) { return (cache[id] && cache[id].progress) || 0; },
      evaluate: function (id, code) { return new Promise(function (res) { var cb = ++cbSeq; pend[cb] = res; if (call("evaluate", id, String(code), cb) === null) { delete pend[cb]; res(null); } setTimeout(function () { if (pend[cb]) { delete pend[cb]; res(null); } }, 15000); }); },
      setUserAgent: function (id, ua) { return call("setUserAgent", id, String(ua || "")); },
      desktopMode: function (id, b) { return call("setDesktopMode", id, !!b); },
      textZoom: function (id, pct) { return call("setTextZoom", id, pct | 0); },
      javascript: function (id, b) { return call("setJavaScript", id, !!b); },
      find: function (id, q) { return call("find", id, String(q || "")); }, findNext: function (id, fwd) { return call("findNext", id, fwd !== false); }, clearFind: function (id) { return call("clearFind", id); },
      clearCache: function (id) { return call("clearCache", id); }, clearHistory: function (id) { return call("clearHistory", id); }, clearCookies: function () { return call("clearCookies"); },
      destroy: function (id) { delete att[id]; delete cache[id]; return call("destroy", id); },
      list: function () { try { return JSON.parse(call("list") || "[]"); } catch (e) { return []; } },
      openFullscreen: function (url, o) { var q = {}; o = o || {}; for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) q[k] = o[k]; q.owner = PAGE; colors(q); return call("openFullscreen", String(url), js(q)) || ""; },
      closeFullscreen: function () { return call("closeFullscreen"); },
      on: function (a, b, c) { if (typeof a === "function") return on("*", "*", a); if (typeof a === "string" && (typeof b === "function")) return on("*", a, b); return on(a, b, c); }
    };
    window.RosTrickWebView = API;
    try { window.dispatchEvent(new CustomEvent("rtwebview-ready")); } catch (e) {}
  })();

  /* ================= سجل التنزيلات (RosTrickDownloads) ================= */
  if (window.RosTrickDownloadsBridge) (function () {
    var B = window.RosTrickDownloadsBridge, hs = [];
    function j(s, d) { try { return s ? JSON.parse(s) : d; } catch (e) { return d; } }
    function call(fn) { try { return B[fn].apply(B, [].slice.call(arguments, 1)); } catch (e) { return null; } }
    window.__rtDl = function (type, json) {
      var item = j(json, {});
      hs.slice().forEach(function (h) { if (h.t === "*" || h.t === type) { try { h.f(item, type); } catch (e) { setTimeout(function () { throw e; }); } } });
      try { window.dispatchEvent(new CustomEvent("rtdownload", { detail: { type: type, item: item } })); } catch (e) {}
    };
    var preq = {}, pn = 0;
    window.__rtDlPrep = function (req, json) {
      var r = preq[req]; if (!r) return; var d = j(json, {});
      if (!d.done) { try { r.p && r.p(d.bytes || 0, d.total || 0); } catch (e) {} return; }
      delete preq[req]; r.res(d);
    };
    window.RosTrickDownloads = {
      __v: 1, available: true,
      /* يجهّز الملف المكتمل للعرض داخل الصفحة: Promise ← {ok, url:'file://…', path, mime, name, size, copied} أو {ok:false, error:'notfound|notdone|missing|copy|error'}.
         قد ينسخ الملف إلى ذاكرة التطبيق المؤقتة إن تعذّرت قراءته بمساره؛ opts.onProgress(bytes,total) لنسبة النسخ. */
      localFile: function (id, opts) {
        return new Promise(function (res) {
          var n = ++pn; preq[n] = { res: res, p: opts && opts.onProgress };
          if (!call("prepare", String(id), n)) { delete preq[n]; res({ ok: false, error: "notfound", done: true }); }
        });
      },
      cacheSize: function () { return +call("cacheSize") || 0; },
      clearCache: function () { return !!call("clearCache"); },
      /* [{id,name,url,mime,state:'pending|running|paused|done|failed|removed',bytes,total,ts,path?}] الأحدث أولاً */
      list: function () { return j(call("list"), []); },
      get: function (id) { return j(call("get", String(id)), null); },
      summary: function () { return j(call("summary"), {}); },
      open: function (id) { return !!call("open", String(id)); },
      share: function (id) { return !!call("share", String(id)); },
      remove: function (id, deleteFile) { return !!call("remove", String(id), !!deleteFile); },
      cancel: function (id) { return !!call("cancel", String(id)); },
      clear: function () { return !!call("clear"); },
      openFolder: function () { return !!call("openFolder"); },
      /* الأنواع: start | progress | done | failed | removed ، والمعالج يستلم (item, type) */
      on: function (t, f) { if (typeof t === "function") { f = t; t = "*"; } var h = { t: t, f: f }; hs.push(h); return function () { hs = hs.filter(function (x) { return x !== h; }); }; }
    };
  })();

  /* ================= الجهاز: سطوع / صوت / كشاف / اهتزاز / اتجاه… (RosTrickDevice) ================= */
  if (window.RosTrickDeviceBridge) (function () {
    var D = window.RosTrickDeviceBridge, hs = [], watched = {};
    function j(s, d) { try { return s ? JSON.parse(s) : d; } catch (e) { return d; } }
    function call(fn) { try { return D[fn].apply(D, [].slice.call(arguments, 1)); } catch (e) { return null; } }
    window.__rtDev = function (type, json) {
      var d = j(json, {});
      hs.slice().forEach(function (h) { if (h.t === "*" || h.t === type) { try { h.f(d, type); } catch (e) { setTimeout(function () { throw e; }); } } });
      try { window.dispatchEvent(new CustomEvent("rtdevice", { detail: { type: type, data: d } })); } catch (e) {}
    };
    function clamp01(v) { v = +v; return isNaN(v) ? 0 : Math.max(0, Math.min(1, v)); }
    window.RosTrickDevice = {
      __v: 1, available: true,
      info: function () { return j(call("info"), {}); },
      /* سطوع نافذة التطبيق فقط (0..1) — لا يغيّر إعداد النظام ولا يحتاج إذنًا */
      brightness: {
        get: function () { return j(call("brightnessGet"), {}); },
        set: function (v) { return !!call("brightnessSet", clamp01(v)); },
        reset: function () { return !!call("brightnessSet", -1); }
      },
      /* القنوات: music | ring | alarm | notification | system | call ؛ القيم 0..1 */
      volume: {
        get: function (stream) { return j(call("volumeGet", stream || "music"), {}); },
        set: function (stream, v) { if (typeof stream === "number") { v = stream; stream = "music"; } return !!call("volumeSet", stream || "music", clamp01(v)); },
        setLevel: function (stream, n) { return !!call("volumeSetLevel", stream || "music", n | 0); },
        up: function (stream, ui) { return !!call("volumeAdjust", stream || "music", "up", !!ui); },
        down: function (stream, ui) { return !!call("volumeAdjust", stream || "music", "down", !!ui); },
        mute: function (stream) { return !!call("volumeAdjust", stream || "music", "mute", false); },
        unmute: function (stream) { return !!call("volumeAdjust", stream || "music", "unmute", false); },
        toggleMute: function (stream) { return !!call("volumeAdjust", stream || "music", "toggle", false); },
        /* أي قناة تتحكم بها أزرار الجهاز داخل التطبيق ("auto" = الافتراضي) */
        keys: function (stream) { return !!call("volumeKeys", stream || "music"); },
        ringer: function () { return call("ringerMode") || "normal"; },
        setRinger: function (mode) { return !!call("setRingerMode", String(mode)); }
      },
      torch: {
        available: function () { return !!call("torchAvailable"); },
        get: function () { return !!call("torchGet"); },
        set: function (on) { return !!call("torchSet", !!on); },
        toggle: function () { return !!call("torchSet", !call("torchGet")); }
      },
      /* tick | click | long | confirm | reject */
      haptic: function (kind) { return !!call("haptic", kind || "click"); },
      orientation: {
        get: function () { return call("orientationGet") || "portrait"; },
        /* portrait | landscape | auto | lock | unlock */
        set: function (m) { return !!call("orientationSet", String(m)); }
      },
      /* true = يمنع لقطات الشاشة وتسجيلها ويُخفي المحتوى في قائمة التطبيقات الأخيرة */
      secure: function (on) { if (on === undefined) return !!call("secureGet"); return !!call("secureSet", !!on); },
      network: { get: function () { return j(call("networkGet"), {}); } },
      /* الأنواع: volume | ringer | torch | network ؛ المعالج يستلم (data, type) */
      on: function (t, f) {
        if (typeof t === "function") { f = t; t = "*"; }
        var h = { t: t, f: f }; hs.push(h);
        var want = t === "*" ? ["volume", "ringer", "torch", "network"] : [t];
        var need = want.filter(function (x) { return !watched[x]; });
        if (need.length) { need.forEach(function (x) { watched[x] = 1; }); call("watch", need.join(",")); }
        return function () { hs = hs.filter(function (x) { return x !== h; }); };
      }
    };
    try { window.dispatchEvent(new CustomEvent("rtdevice-ready")); } catch (e) {}
  })();
  try { window.dispatchEvent(new CustomEvent("rtnative-ready")); } catch (e) {}
})();
