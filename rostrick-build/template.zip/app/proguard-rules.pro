-repackageclasses
-ignorewarnings
-dontwarn
-dontnote

# WebView JS interfaces — لازم تبقى أسماءها كما هي وإلا تنكسر الجسور بين JS وجافا
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keepattributes JavascriptInterface

# أسماء الـ anonymous/inner classes المرتبطة بالـ WebView تبقى سليمة البنية
-keepclassmembers class * extends android.webkit.WebViewClient { *; }
-keepclassmembers class * extends android.webkit.WebChromeClient { *; }

# نحتفظ بسطر الاستثناء وملف السطر للتتبع عند الأعطال (crash reports تبقى مقروءة)
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile
