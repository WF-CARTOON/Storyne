#!/usr/bin/env python3
"""
يطبّق إعدادات اللوحة (rostrick-build/config.json) على مشروع الأندرويد قبل البناء:
  - اسم التطبيق، applicationId، versionCode، versionName
  - ألوان الثيم
  - أيقونة التطبيق (تُولَّد منها كل الأحجام)
  - رابط الـ Worker داخل: final String ASSET_BASE_HOST = "";

الاستخدام:
  python3 tools/apply_config.py --config <config.json> --project <مجلد المشروع> [--icon <icon.png>]
"""
import argparse
import json
import os
import re
import sys

JAVA_KEYWORDS = {
    "abstract", "assert", "boolean", "break", "byte", "case", "catch", "char", "class", "const",
    "continue", "default", "do", "double", "else", "enum", "extends", "final", "finally", "float",
    "for", "goto", "if", "implements", "import", "instanceof", "int", "interface", "long", "native",
    "new", "package", "private", "protected", "public", "return", "short", "static", "strictfp",
    "super", "switch", "synchronized", "this", "throw", "throws", "transient", "try", "void",
    "volatile", "while", "true", "false", "null",
}

DEFAULT_COLORS = {
    "primary": "#000000",
    "primary_dark": "#000000",
    "accent": "#000090",
    "highlight": "#000090",
    "control_normal": "#000090",
}

ICON_SIZES = {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}


def fail(msg):
    print("::error::" + msg)
    sys.exit(1)


def read(path):
    with open(path, encoding="utf-8") as f:
        return f.read()


def write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)


def validate_package(pkg):
    if not isinstance(pkg, str) or not re.fullmatch(r"[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+", pkg):
        fail("اسم الحزمة غير صالح: %r (مثال صحيح: com.mycompany.myapp، أحرف إنجليزية صغيرة وأرقام و _ فقط، وجزءان على الأقل)" % (pkg,))
    for part in pkg.split("."):
        if part in JAVA_KEYWORDS:
            fail("اسم الحزمة يحتوي كلمة محجوزة في Java: " + part)
    if pkg.startswith("android.") or pkg.startswith("com.android."):
        fail("اسم الحزمة محجوز للنظام: " + pkg)
    if len(pkg) > 150:
        fail("اسم الحزمة طويل جداً")


def validate_color(name, value):
    if not isinstance(value, str) or not re.fullmatch(r"#([0-9a-fA-F]{6}|[0-9a-fA-F]{8})", value):
        fail("لون %s غير صالح: %r (استخدم #RRGGBB)" % (name, value))
    return value.upper()


def clean_host(raw):
    host = (raw or "").strip()
    host = re.sub(r"^https?://", "", host, flags=re.I).strip("/ ")
    host = host.split("/")[0]
    if host and not re.fullmatch(r"[A-Za-z0-9]([A-Za-z0-9.-]*[A-Za-z0-9])?", host):
        fail("رابط الـ Worker غير صالح: %r" % raw)
    return host


def xml_escape_text(s):
    s = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    s = s.replace("\\", "\\\\").replace("'", "\\'").replace('"', '\\"')
    s = s.replace("\n", " ")
    if s[:1] in ("@", "?"):
        s = "\\" + s
    return s


def apply_colors(project, colors):
    c = dict(DEFAULT_COLORS)
    c.update({k: v for k, v in (colors or {}).items() if k in DEFAULT_COLORS and v})
    c = {k: validate_color(k, v) for k, v in c.items()}
    xml = (
        "<resources>\n"
        '\t<color name="colorPrimary">%(primary)s</color>\n'
        '\t<color name="colorPrimaryDark">%(primary_dark)s</color>\n'
        '\t<color name="colorAccent">%(accent)s</color>\n'
        '\t<color name="colorControlHighlight">%(highlight)s</color>\n'
        '\t<color name="colorControlNormal">%(control_normal)s</color>\n'
        "</resources>\n"
    ) % c
    write(os.path.join(project, "app/src/main/res/values/colors.xml"), xml)


def apply_strings(project, app_name):
    name = (app_name or "").strip()
    if not name:
        fail("اسم التطبيق فارغ")
    if len(name) > 60:
        fail("اسم التطبيق طويل جداً (الحد 60 حرفاً)")
    xml = (
        "<resources>\n"
        '\t<string name="app_name" translatable="false">%s</string>\n'
        "</resources>\n"
    ) % xml_escape_text(name)
    write(os.path.join(project, "app/src/main/res/values/strings.xml"), xml)


def apply_gradle(project, pkg, version_code, version_name):
    path = os.path.join(project, "app/build.gradle")
    g = read(path)
    g, n1 = re.subn(r'applicationId\s+"[^"]*"', 'applicationId "%s"' % pkg, g, count=1)
    g, n2 = re.subn(r"versionCode\s+\d+", "versionCode %d" % version_code, g, count=1)
    g, n3 = re.subn(r'versionName\s+"[^"]*"', 'versionName "%s"' % version_name.replace('"', ""), g, count=1)
    if (n1, n2, n3) != (1, 1, 1):
        fail("تعذّر تعديل app/build.gradle (لم أجد applicationId/versionCode/versionName)")
    write(path, g)


def apply_worker_host(project, host):
    java_dir = os.path.join(project, "app/src/main/java")
    pattern = re.compile(r'final String ASSET_BASE_HOST = "[^"]*";')
    total = 0
    for root, _, files in os.walk(java_dir):
        for fn in files:
            if not fn.endswith(".java"):
                continue
            p = os.path.join(root, fn)
            src = read(p)
            new, n = pattern.subn('final String ASSET_BASE_HOST = "%s";' % host, src)
            if n:
                write(p, new)
                total += n
    if total != 1:
        fail("توقعت وجود تعريف ASSET_BASE_HOST مرة واحدة بالضبط، وجدت %d" % total)


def apply_icon(project, icon_path):
    if not icon_path or not os.path.isfile(icon_path):
        print("لا توجد أيقونة مخصصة، سيُستخدم الافتراضي.")
        return
    try:
        from PIL import Image
    except ImportError:
        fail("مكتبة Pillow غير مثبتة")
    try:
        img = Image.open(icon_path).convert("RGBA")
    except Exception as e:  # noqa: BLE001
        fail("تعذّر قراءة ملف الأيقونة: %s" % e)
    w, h = img.size
    side = max(w, h)
    if side < 96:
        fail("الأيقونة صغيرة جداً (%dx%d)، الحد الأدنى 96x96 والمستحسن 512x512" % (w, h))
    if w != h:  # نضعها في مربع شفاف بدل تشويهها
        square = Image.new("RGBA", (side, side), (0, 0, 0, 0))
        square.paste(img, ((side - w) // 2, (side - h) // 2))
        img = square
    res = os.path.join(project, "app/src/main/res")
    for d in os.listdir(res):
        if d.startswith("mipmap-"):
            old = os.path.join(res, d, "ic_launcher.png")
            if os.path.exists(old):
                os.remove(old)
    for density, px in ICON_SIZES.items():
        out = os.path.join(res, "mipmap-" + density, "ic_launcher.png")
        os.makedirs(os.path.dirname(out), exist_ok=True)
        img.resize((px, px), Image.LANCZOS).save(out, "PNG", optimize=True)
    print("تم توليد الأيقونة بالأحجام:", ", ".join(ICON_SIZES))


def resolve_icon(cfg, icon_path, project):
    """الأيقونة تُرسل داخل config.json نفسه (icon_b64) فلا يمكن أن تختلف عن بقية الإعدادات:
    - icon_b64 نص → تُفك وتُستخدم
    - icon_b64 = null → الأيقونة الافتراضية (يُتجاهل أي icon.png قديم)
    - لا يوجد المفتاح (إعدادات قديمة) → icon.png إن وُجد
    يرجع (مسار الأيقونة أو "", sha256 مختصر)."""
    import base64
    import hashlib
    if "icon_b64" in cfg:
        raw = cfg.get("icon_b64")
        if not raw:
            print("الإعدادات: لا توجد أيقونة مخصصة → الأيقونة الافتراضية")
            return "", ""
        try:
            data = base64.b64decode(raw, validate=False)
        except Exception as e:  # noqa: BLE001
            fail("icon_b64 في config.json تالف: %s" % e)
        path = os.path.join(project, "icon_custom.png")
        with open(path, "wb") as f:
            f.write(data)
        print("الأيقونة من config.json: %d بايت" % len(data))
        return path, hashlib.sha256(data).hexdigest()[:12]
    if icon_path and os.path.isfile(icon_path):
        with open(icon_path, "rb") as f:
            data = f.read()
        return icon_path, hashlib.sha256(data).hexdigest()[:12]
    return "", ""


# أذونات أُزيلت من القائمة (صارت أساسية أو غير لازمة): تُتجاهل بصمت في الإعدادات القديمة
LEGACY_PERMISSIONS = {"vibrate", "wake_lock", "bluetooth"}

PERMISSION_CATALOG = {
    "camera": {
        "perms": ["android.permission.CAMERA"],
        "features": [("android.hardware.camera", False), ("android.hardware.camera.autofocus", False)],
    },
    "microphone": {
        "perms": ["android.permission.RECORD_AUDIO", "android.permission.MODIFY_AUDIO_SETTINGS"],
        "features": [("android.hardware.microphone", False)],
    },
    "location": {
        "perms": ["android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION"],
        "features": [("android.hardware.location", False)],
    },
}


def apply_permissions(project, cfg):
    """يضيف الأذونات الاختيارية إلى AndroidManifest.xml (الأساسية موجودة أصلاً في القالب)."""
    chosen = cfg.get("permissions") or []
    if not isinstance(chosen, list):
        fail("حقل permissions في config.json يجب أن يكون قائمة")
    chosen = [c for c in chosen if c not in LEGACY_PERMISSIONS]
    unknown = [c for c in chosen if c not in PERMISSION_CATALOG]
    if unknown:
        fail("أذونات غير معروفة: " + ", ".join(map(str, unknown)))
    path = os.path.join(project, "app/src/main/AndroidManifest.xml")
    xml = read(path)
    xml = re.sub(r"[ \t]*<!-- RT-PERMS:START -->.*?<!-- RT-PERMS:END -->\n?", "", xml, flags=re.S)
    if not chosen:
        write(path, xml)
        print("الأذونات الاختيارية: لا شيء")
        return
    lines = ["\t<!-- RT-PERMS:START -->"]
    seen = set(re.findall(r'<uses-permission[^>]*android:name="([^"]+)"', xml))
    for key in sorted(set(chosen)):
        info = PERMISSION_CATALOG[key]
        for pm in info["perms"]:
            name, max_sdk = (pm, None) if isinstance(pm, str) else pm
            if name in seen:
                continue
            seen.add(name)
            extra = ' android:maxSdkVersion="%d"' % max_sdk if max_sdk else ""
            if name == "android.permission.BLUETOOTH_SCAN":
                extra = ' android:usesPermissionFlags="neverForLocation"'
            lines.append('\t<uses-permission android:name="%s"%s />' % (name, extra))
        for feat, req in info["features"]:
            lines.append('\t<uses-feature android:name="%s" android:required="%s" />' % (feat, "true" if req else "false"))
    lines.append("\t<!-- RT-PERMS:END -->")
    block = "\n".join(lines) + "\n"
    if "<application" not in xml:
        fail("لم أجد <application> في AndroidManifest.xml")
    xml = xml.replace("\t<application", block + "\t<application", 1)
    write(path, xml)
    print("الأذونات الاختيارية:", ", ".join(sorted(set(chosen))))


def resolve_output(cfg):
    out = cfg.get("output_format") or "apk"
    if out not in ("apk", "aab", "both"):
        fail("نوع المخرج غير صالح: %r (apk أو aab أو both)" % (out,))
    return out


def apply_home(project, cfg):
    """صفحة «جارٍ التحميل» الأولية داخل الـ APK (assets/home.html):
    - home_html_b64 نص → صفحة مخصصة يصممها المستخدم
    - غير موجود/null → تبقى الصفحة الافتراضية من القالب."""
    import base64
    raw = cfg.get("home_html_b64")
    if not raw:
        print("صفحة التحميل: الافتراضية")
        return
    try:
        html = base64.b64decode(raw, validate=False).decode("utf-8")
    except Exception as e:  # noqa: BLE001
        fail("home_html_b64 في config.json تالف: %s" % e)
    if not html.strip():
        fail("صفحة التحميل المخصصة فارغة")
    if len(html.encode("utf-8")) > 300 * 1024:
        fail("صفحة التحميل المخصصة أكبر من 300KB")
    # التطبيق يستدعي هاتين الدالتين لتحديث التقدم؛ نضيف نسخاً فارغة إن لم تعرّفهما الصفحة حتى لا تظهر أخطاء JS
    stubs = ""
    if "setSyncProgress" not in html:
        stubs += "window.setSyncProgress=window.setSyncProgress||function(){};"
    if "setSyncStatus" not in html:
        stubs += "window.setSyncStatus=window.setSyncStatus||function(){};"
    if stubs:
        tag = "<script>" + stubs + "</script>"
        idx = html.lower().rfind("</body>")
        html = (html[:idx] + tag + html[idx:]) if idx != -1 else (html + tag)
        print("أضفتُ دوال التقدم الفارغة تلقائياً (الصفحة لا تعرّفها).")
    write(os.path.join(project, "app/src/main/assets/home.html"), html)
    print("صفحة التحميل: مخصصة (%d بايت)" % len(html.encode("utf-8")))


def set_output(key, value):
    path = os.environ.get("GITHUB_OUTPUT")
    line = "%s=%s\n" % (key, value)
    if path:
        with open(path, "a", encoding="utf-8") as f:
            f.write(line)
    else:
        print("[output]", line.strip())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--project", required=True)
    ap.add_argument("--icon", default="")
    a = ap.parse_args()

    try:
        cfg = json.loads(read(a.config))
    except Exception as e:  # noqa: BLE001
        fail("ملف الإعدادات تالف: %s" % e)

    pkg = cfg.get("package_name")
    validate_package(pkg)

    try:
        version_code = int(cfg.get("version_code"))
    except (TypeError, ValueError):
        fail("رقم الإصدار (version_code) يجب أن يكون رقماً صحيحاً")
    if not (1 <= version_code <= 2100000000):
        fail("رقم الإصدار خارج النطاق المسموح")

    version_name = str(cfg.get("version_name") or "").strip()
    if not re.fullmatch(r"[A-Za-z0-9._+\- ]{1,40}", version_name):
        fail("اسم الإصدار (version_name) غير صالح: %r" % version_name)

    host = clean_host(cfg.get("asset_base_host"))
    if not host:
        fail("رابط الـ Worker فارغ: اضبطه في إعدادات اللوحة أولاً")

    apply_strings(a.project, cfg.get("app_name"))
    apply_colors(a.project, cfg.get("colors"))
    apply_gradle(a.project, pkg, version_code, version_name)
    apply_worker_host(a.project, host)
    icon_used, icon_sha = resolve_icon(cfg, a.icon, a.project)
    apply_icon(a.project, icon_used)
    apply_home(a.project, cfg)
    apply_permissions(a.project, cfg)
    out_fmt = resolve_output(cfg)
    set_output("build_apk", "1" if out_fmt in ("apk", "both") else "0")
    set_output("build_aab", "1" if out_fmt in ("aab", "both") else "0")
    set_output("output_format", out_fmt)
    set_output("icon_used", "1" if icon_used else "0")
    set_output("icon_sha", icon_sha)

    set_output("package_name", pkg)
    set_output("version_code", str(version_code))
    set_output("version_name", version_name.replace(" ", "-"))
    set_output("asset_host", host)
    print("تم تطبيق الإعدادات: %s | %s | v%s (%d) | %s" % (cfg.get("app_name"), pkg, version_name, version_code, host))


if __name__ == "__main__":
    main()
