#!/usr/bin/env python3
"""
يطبّق إعدادات اللوحة (rostrick-build/config.json) على مشروع الأندرويد قبل البناء:
  - اسم التطبيق، applicationId، versionCode، versionName
  - ألوان الثيم
  - أيقونة التطبيق (تُولَّد منها كل الأحجام)
  - رابط الـ Worker داخل: final String ASSET_BASE_HOST = ... (يُستبدل بثابت Base64)

الاستخدام:
  python3 tools/apply_config.py --config <config.json> --project <مجلد المشروع> [--icon <icon.png>]
"""
import argparse
import base64
import json
import os
import re
import sys

JAVA_KEYWORDS = {
    "abstract", "assert", "boolean", "break", "byte", "case", "catch", "char", "class", "const",
    "continue", "default", "do", "double", "else", "enum", "extends", "final", "finally", "float",
    "for", "goto", "if", "implements", "import", "instanceof", "int", "interface", "long", "native",
    "new", "package", "private", "protected", "public", "return", "short", "static", "strictfp",
    "super", "switch", "synchronized", "this", "throw", "throws", "transient", "try", "void",
    "volatile", "while", "true", "false", "null",
}

DEFAULT_COLORS = {
    "primary": "#000000",
    "primary_dark": "#000000",
    "accent": "#000090",
    "highlight": "#000090",
    "control_normal": "#000090",
}

ICON_SIZES = {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}


def fail(msg):
    print("::error::" + msg)
    sys.exit(1)


def read(path):
    with open(path, encoding="utf-8") as f:
        return f.read()


def write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)


def validate_package(pkg):
    if not isinstance(pkg, str) or not re.fullmatch(r"[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+", pkg):
        fail("اسم الحزمة غير صالح: %r (مثال صحيح: com.mycompany.myapp، أحرف إنجليزية صغيرة وأرقام و _ فقط، وجزءان على الأقل)" % (pkg,))
    for part in pkg.split("."):
        if part in JAVA_KEYWORDS:
            fail("اسم الحزمة يحتوي كلمة محجوزة في Java: " + part)
    if pkg.startswith("android.") or pkg.startswith("com.android."):
        fail("اسم الحزمة محجوز للنظام: " + pkg)
    if len(pkg) > 150:
        fail("اسم الحزمة طويل جداً")


def validate_color(name, value):
    if not isinstance(value, str) or not re.fullmatch(r"#([0-9a-fA-F]{6}|[0-9a-fA-F]{8})", value):
        fail("لون %s غير صالح: %r (استخدم #RRGGBB)" % (name, value))
    return value.upper()


def clean_host(raw):
    host = (raw or "").strip()
    host = re.sub(r"^https?://", "", host, flags=re.I).strip("/ ")
    host = host.split("/")[0]
    if host and not re.fullmatch(r"[A-Za-z0-9]([A-Za-z0-9.-]*[A-Za-z0-9])?", host):
        fail("رابط الـ Worker غير صالح: %r" % raw)
    return host


def xml_escape_text(s):
    s = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    s = s.replace("\\", "\\\\").replace("'", "\\'").replace('"', '\\"')
    s = s.replace("\n", " ")
    if s[:1] in ("@", "?"):
        s = "\\" + s
    return s


def apply_colors(project, colors):
    c = dict(DEFAULT_COLORS)
    c.update({k: v for k, v in (colors or {}).items() if k in DEFAULT_COLORS and v})
    c = {k: validate_color(k, v) for k, v in c.items()}
    xml = (
        "<resources>\n"
        '\t<color name="colorPrimary">%(primary)s</color>\n'
        '\t<color name="colorPrimaryDark">%(primary_dark)s</color>\n'
        '\t<color name="colorAccent">%(accent)s</color>\n'
        '\t<color name="colorControlHighlight">%(highlight)s</color>\n'
        '\t<color name="colorControlNormal">%(control_normal)s</color>\n'
        "</resources>\n"
    ) % c
    write(os.path.join(project, "app/src/main/res/values/colors.xml"), xml)


def apply_strings(project, app_name):
    name = (app_name or "").strip()
    if not name:
        fail("اسم التطبيق فارغ")
    if len(name) > 60:
        fail("اسم التطبيق طويل جداً (الحد 60 حرفاً)")
    xml = (
        "<resources>\n"
        '\t<string name="app_name" translatable="false">%s</string>\n'
        "</resources>\n"
    ) % xml_escape_text(name)
    write(os.path.join(project, "app/src/main/res/values/strings.xml"), xml)


MIN_SDK_RANGE = (21, 36)
TARGET_SDK_RANGE = (23, 36)   # أندرويد 14+ يرفض تثبيت تطبيقات تستهدف أقل من 23


def resolve_sdk(cfg):
    """min_sdk (أدنى إصدار أندرويد يعمل عليه التطبيق) و target_sdk (الإصدار المستهدف). الافتراضي 21 و 36."""
    out = []
    for key, default, (lo, hi), label in (("min_sdk", 21, MIN_SDK_RANGE, "الحد الأدنى"), ("target_sdk", 36, TARGET_SDK_RANGE, "المستهدف")):
        raw = cfg.get(key)
        if raw in (None, ""):
            out.append(default)
            continue
        try:
            v = int(raw)
        except (TypeError, ValueError):
            fail("%s (%s) يجب أن يكون رقماً صحيحاً" % (key, label))
        if not (lo <= v <= hi):
            fail("%s (%s) خارج النطاق المسموح %d – %d" % (key, label, lo, hi))
        out.append(v)
    if out[0] > out[1]:
        fail("الحد الأدنى لـ SDK (%d) أكبر من المستهدف (%d)" % (out[0], out[1]))
    return out[0], out[1]


def apply_gradle(project, pkg, version_code, version_name, min_sdk=21, target_sdk=36):
    path = os.path.join(project, "app/build.gradle")
    g = read(path)
    g, n4 = re.subn(r"minSdkVersion\s+\d+", "minSdkVersion %d" % min_sdk, g, count=1)
    g, n5 = re.subn(r"targetSdkVersion\s+\d+", "targetSdkVersion %d" % target_sdk, g, count=1)
    if (n4, n5) != (1, 1):
        fail("تعذّر تعديل minSdkVersion/targetSdkVersion في app/build.gradle")
    g, n1 = re.subn(r'applicationId\s+"[^"]*"', 'applicationId "%s"' % pkg, g, count=1)
    g, n2 = re.subn(r"versionCode\s+\d+", "versionCode %d" % version_code, g, count=1)
    g, n3 = re.subn(r'versionName\s+"[^"]*"', 'versionName "%s"' % version_name.replace('"', ""), g, count=1)
    if (n1, n2, n3) != (1, 1, 1):
        fail("تعذّر تعديل app/build.gradle (لم أجد applicationId/versionCode/versionName)")
    write(path, g)


def _java_obf(text):
    """يرمّز النص بـ Base64 كثابت واحد، يُفك وقت التشغيل (مع ProGuard/R8 هذا كافٍ)."""
    b64 = base64.b64encode(text.encode("utf-8")).decode("ascii")
    return ('new String(android.util.Base64.decode("%s", android.util.Base64.DEFAULT))'
             % b64)


def apply_worker_host(project, host):
    java_dir = os.path.join(project, "app/src/main/java")
    pattern = re.compile(r'final String ASSET_BASE_HOST = "[^"]*";')
    pages = re.compile(r'final String APP_PAGES_URL = ASSET_BASE_URL \+ "apppages\.json";')
    total = 0
    for root, _, files in os.walk(java_dir):
        for fn in files:
            if not fn.endswith(".java"):
                continue
            p = os.path.join(root, fn)
            src = read(p)
            new, n = pattern.subn(lambda m: "final String ASSET_BASE_HOST = %s;" % _java_obf(host), src)
            new, _ = pages.subn(lambda m: "final String APP_PAGES_URL = ASSET_BASE_URL + %s;" % _java_obf("apppages.json"), new)
            if n:
                write(p, new)
                total += n
    if total != 1:
        fail("توقعت وجود تعريف ASSET_BASE_HOST مرة واحدة بالضبط، وجدت %d" % total)


def apply_icon(project, icon_path):
    if not icon_path or not os.path.isfile(icon_path):
        print("لا توجد أيقونة مخصصة، سيُستخدم الافتراضي.")
        return
    try:
        from PIL import Image
    except ImportError:
        fail("مكتبة Pillow غير مثبتة")
    try:
        img = Image.open(icon_path).convert("RGBA")
    except Exception as e:  # noqa: BLE001
        fail("تعذّر قراءة ملف الأيقونة: %s" % e)
    w, h = img.size
    side = max(w, h)
    if side < 96:
        fail("الأيقونة صغيرة جداً (%dx%d)، الحد الأدنى 96x96 والمستحسن 512x512" % (w, h))
    if w != h:  # نضعها في مربع شفاف بدل تشويهها
        square = Image.new("RGBA", (side, side), (0, 0, 0, 0))
        square.paste(img, ((side - w) // 2, (side - h) // 2))
        img = square
    res = os.path.join(project, "app/src/main/res")
    for d in os.listdir(res):
        if d.startswith("mipmap-"):
            old = os.path.join(res, d, "ic_launcher.png")
            if os.path.exists(old):
                os.remove(old)
    for density, px in ICON_SIZES.items():
        out = os.path.join(res, "mipmap-" + density, "ic_launcher.png")
        os.makedirs(os.path.dirname(out), exist_ok=True)
        img.resize((px, px), Image.LANCZOS).save(out, "PNG", optimize=True)
    print("تم توليد الأيقونة بالأحجام:", ", ".join(ICON_SIZES))


ADAPTIVE_DENSITIES = {"mdpi": 1.0, "hdpi": 1.5, "xhdpi": 2.0, "xxhdpi": 3.0, "xxxhdpi": 4.0}
ADAPTIVE_CANVAS_DP = 108      # حجم طبقة الأيقونة التكيّفية
ADAPTIVE_ART_DP = 72          # المنطقة التي توضع فيها الصورة (المنطقة الآمنة 66dp تبقى كاملة الظهور)


def auto_icon_background(img):
    """لون خلفية تلقائي: متوسط ألوان حواف الصورة (مرجّحاً بالشفافية). إن كانت الحواف شفافة غالباً → أبيض."""
    w, h = img.size
    t = max(1, round(min(w, h) * 0.02))
    px = img.convert("RGBA").load()
    sr = sg = sb = sa = 0
    n = 0
    for y in range(h):
        edge_row = y < t or y >= h - t
        xs = range(w) if edge_row else list(range(0, t)) + list(range(w - t, w))
        for x in xs:
            r, g, b, a = px[x, y]
            n += 1
            sr += r * a
            sg += g * a
            sb += b * a
            sa += a
    if n == 0 or sa / (255.0 * n) < 0.5:
        return "#FFFFFF"
    return "#%02X%02X%02X" % (round(sr / sa), round(sg / sa), round(sb / sa))


def apply_adaptive_icon(project, icon_path, cfg):
    """أيقونة تكيّفية (أندرويد 8+): الصورة كطبقة أمامية ولون خلفية، فيقصّها قاذف الأجهزة بالشكل الذي يريده
    (دائرة/مربع مدوّر...) دون مربع أبيض. الإصدارات الأقدم تبقى على أيقونة PNG التقليدية المولَّدة سابقاً.
    cfg.icon_style: "adaptive" (الافتراضي) أو "plain". cfg.icon_bg: "#RRGGBB" أو فارغ = تلقائي.
    يرجع (الأسلوب المطبّق، لون الخلفية)."""
    style = cfg.get("icon_style") or "adaptive"
    if style not in ("adaptive", "plain"):
        fail("icon_style غير صالح: %r (adaptive أو plain)" % (style,))
    if not icon_path or not os.path.isfile(icon_path) or style == "plain":
        return "plain", ""
    from PIL import Image
    img = Image.open(icon_path).convert("RGBA")
    w, h = img.size
    side = max(w, h)
    if w != h:
        sq = Image.new("RGBA", (side, side), (0, 0, 0, 0))
        sq.paste(img, ((side - w) // 2, (side - h) // 2))
        img = sq
    bg = (cfg.get("icon_bg") or "").strip()
    if bg:
        if not re.fullmatch(r"#[0-9a-fA-F]{6}", bg):
            fail("لون خلفية الأيقونة غير صالح: %r (استخدم #RRGGBB)" % (bg,))
        bg = bg.upper()
    else:
        bg = auto_icon_background(img)
    res = os.path.join(project, "app/src/main/res")
    for density, scale in ADAPTIVE_DENSITIES.items():
        canvas_px = round(ADAPTIVE_CANVAS_DP * scale)
        art_px = round(ADAPTIVE_ART_DP * scale)
        canvas = Image.new("RGBA", (canvas_px, canvas_px), (0, 0, 0, 0))
        art = img.resize((art_px, art_px), Image.LANCZOS)
        off = (canvas_px - art_px) // 2
        canvas.paste(art, (off, off), art)
        out = os.path.join(res, "drawable-" + density, "ic_launcher_foreground.png")
        os.makedirs(os.path.dirname(out), exist_ok=True)
        canvas.save(out, "PNG", optimize=True)
    write(os.path.join(res, "values/ic_launcher_background.xml"),
          '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n\t<color name="ic_launcher_background">%s</color>\n</resources>\n' % bg)
    write(os.path.join(res, "mipmap-anydpi-v26/ic_launcher.xml"),
          '<?xml version="1.0" encoding="utf-8"?>\n'
          '<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n'
          '\t<background android:drawable="@color/ic_launcher_background" />\n'
          '\t<foreground android:drawable="@drawable/ic_launcher_foreground" />\n'
          '</adaptive-icon>\n')
    print("أيقونة تكيّفية: خلفية %s" % bg)
    return "adaptive", bg


def resolve_icon(cfg, icon_path, project):
    """الأيقونة تُرسل داخل config.json نفسه (icon_b64) فلا يمكن أن تختلف عن بقية الإعدادات:
    - icon_b64 نص → تُفك وتُستخدم
    - icon_b64 = null → الأيقونة الافتراضية (يُتجاهل أي icon.png قديم)
    - لا يوجد المفتاح (إعدادات قديمة) → icon.png إن وُجد
    يرجع (مسار الأيقونة أو "", sha256 مختصر)."""
    import base64
    import hashlib
    if "icon_b64" in cfg:
        raw = cfg.get("icon_b64")
        if not raw:
            print("الإعدادات: لا توجد أيقونة مخصصة → الأيقونة الافتراضية")
            return "", ""
        try:
            data = base64.b64decode(raw, validate=False)
        except Exception as e:  # noqa: BLE001
            fail("icon_b64 في config.json تالف: %s" % e)
        path = os.path.join(project, "icon_custom.png")
        with open(path, "wb") as f:
            f.write(data)
        print("الأيقونة من config.json: %d بايت" % len(data))
        return path, hashlib.sha256(data).hexdigest()[:12]
    if icon_path and os.path.isfile(icon_path):
        with open(icon_path, "rb") as f:
            data = f.read()
        return icon_path, hashlib.sha256(data).hexdigest()[:12]
    return "", ""


# أذونات أُزيلت من القائمة (صارت أساسية أو غير لازمة): تُتجاهل بصمت في الإعدادات القديمة
LEGACY_PERMISSIONS = {"vibrate", "wake_lock", "bluetooth"}

RT_BOOT_RECEIVER_XML = ('\t\t<receiver\n\t\t\tandroid:name=".RtBootReceiver"\n\t\t\tandroid:enabled="true"\n\t\t\tandroid:exported="true">\n'
                        '\t\t\t<intent-filter>\n\t\t\t\t<action android:name="android.intent.action.BOOT_COMPLETED" />\n'
                        '\t\t\t\t<action android:name="android.intent.action.MY_PACKAGE_REPLACED" />\n\t\t\t</intent-filter>\n\t\t</receiver>')

PERMISSION_CATALOG = {
    "camera": {
        "perms": ["android.permission.CAMERA"],
        "features": [("android.hardware.camera", False), ("android.hardware.camera.autofocus", False)],
    },
    "microphone": {
        "perms": ["android.permission.RECORD_AUDIO", "android.permission.MODIFY_AUDIO_SETTINGS"],
        "features": [("android.hardware.microphone", False)],
    },
    "location": {
        "perms": ["android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION"],
        "features": [("android.hardware.location", False)],
    },
    "media_download": {
        # تنزيل الوسائط (فيديو/صوت) للتشغيل دون اتصال — خدمة نظام تعمل في الخلفية (Foreground Service).
        # هذا الأذن حسّاس: Google Play تطلب عند النشر فيديو يوضّح استخدامه فعلياً، لذلك يبقى معطّلاً
        # افتراضياً (لا يوجد في AndroidManifest.xml الأساسي) ولا يُضاف إلا إذا اختاره المستخدم صراحةً.
        "perms": ["android.permission.FOREGROUND_SERVICE", "android.permission.FOREGROUND_SERVICE_DATA_SYNC"],
        "features": [],
        "service": '\t\t<service\n\t\t\tandroid:name=".MediaDownloadService"\n\t\t\tandroid:enabled="true"\n\t\t\tandroid:exported="false"\n\t\t\tandroid:foregroundServiceType="dataSync" />',
    },
    "bg_service": {
        # (أ) خدمة أمامية عامة تُبقي التطبيق يعمل في الخلفية بإشعار دائم (RtBackgroundService) + صفحة خلفية اختيارية.
        # حسّاس: Google Play تطلب إعلان Foreground service (النوع specialUse) مع شرح وفيديو يوضّح الاستخدام الفعلي،
        # لذلك يبقى معطّلاً افتراضياً ولا يُضاف للـ Manifest إلا إذا اختاره صاحب التطبيق صراحةً.
        "perms": ["android.permission.FOREGROUND_SERVICE", "android.permission.FOREGROUND_SERVICE_SPECIAL_USE", "android.permission.RECEIVE_BOOT_COMPLETED"],
        "features": [],
        "service": [
            '\t\t<service\n\t\t\tandroid:name=".RtBackgroundService"\n\t\t\tandroid:enabled="true"\n\t\t\tandroid:exported="false"\n\t\t\tandroid:foregroundServiceType="specialUse">\n'
            '\t\t\t<property\n\t\t\t\tandroid:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE"\n\t\t\t\tandroid:value="app-defined background task chosen by the app owner" />\n\t\t</service>',
            RT_BOOT_RECEIVER_XML,
        ],
    },
    "overlay": {
        # نوافذ عائمة فوق التطبيقات (RosTrickOverlay): إذن "العرض فوق التطبيقات" يمنحه المستخدم يدوياً من الإعدادات.
        # حسّاس: Google Play تراجع تطبيقات SYSTEM_ALERT_WINDOW؛ يبقى معطّلاً افتراضياً ولا يُضاف إلا إذا اختاره صاحب التطبيق صراحةً.
        "perms": ["android.permission.SYSTEM_ALERT_WINDOW"],
        "features": [],
    },
    "screen_capture": {
        # التقاط الشاشة وقراءة الألوان وتسجيل الشاشة (RosTrickScreen): خدمة أمامية من نوع mediaProjection،
        # وتظهر للمستخدم نافذة موافقة النظام "تسجيل الشاشة" (وعلى Android 14+ في كل جلسة). Google Play تطلب شرح الاستخدام.
        "perms": ["android.permission.FOREGROUND_SERVICE", "android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION"],
        "features": [],
        "service": '\t\t<service\n\t\t\tandroid:name=".RtScreenService"\n\t\t\tandroid:enabled="true"\n\t\t\tandroid:exported="false"\n\t\t\tandroid:foregroundServiceType="mediaProjection" />',
    },
    "bg_scheduler": {
        # (ب) مهام/تنبيهات مجدولة عبر AlarmManager (RtAlarmReceiver): تُطلق إشعاراً في وقت محدد دون خدمة دائمة.
        # SCHEDULE_EXACT_ALARM: على Android 14+ يمنحه المستخدم يدوياً من الإعدادات (RosTrickBackground.requestExactAlarms)،
        # وإن لم يُمنح يعمل المنبّه بدقة أقل (غير دقيق). Google Play تقيّد هذا الإذن لتطبيقات يعتمد عملها الأساسي على التوقيت الدقيق.
        "perms": ["android.permission.SCHEDULE_EXACT_ALARM", "android.permission.RECEIVE_BOOT_COMPLETED"],
        "features": [],
        "service": [
            '\t\t<receiver\n\t\t\tandroid:name=".RtAlarmReceiver"\n\t\t\tandroid:enabled="true"\n\t\t\tandroid:exported="false" />',
            RT_BOOT_RECEIVER_XML,
        ],
    },
}


NATIVE_ASSETS_RESERVED = {"home.html", "404.html", "rt-webapi.js", "rt-webapi-hw.js", "rt-native.js"}  # ملفات أساسية في جذر assets/ لا يجوز استبدالها


def apply_extra_assets(project, cfg):
    """يكتب الملفات الإضافية التي يرفعها المسؤول من قسم «ملفات إضافية داخل assets» في اللوحة
    (cfg.extra_assets = [{name, b64}, ...]) مباشرة داخل جذر app/src/main/assets/، فتُحقن في الـ APK
    الناتج وتكون متوفرة من أول تشغيل دون اتصال بالإنترنت. تُقرأ من كود الصفحة عبر:
    window.RosTrickAssets.read(name) / .exists(name)."""
    import base64

    items = cfg.get("extra_assets")
    if not items:
        print("ملفات إضافية داخل assets: لا شيء")
        return False
    if not isinstance(items, list):
        fail("extra_assets في config.json يجب أن تكون قائمة")

    target_dir = os.path.join(project, "app/src/main/assets")
    os.makedirs(target_dir, exist_ok=True)
    target_root = os.path.realpath(target_dir)
    count = 0
    for item in items:
        if not isinstance(item, dict):
            fail("عنصر غير صالح داخل extra_assets: %r" % (item,))
        name = str(item.get("name") or "").strip()
        b64 = item.get("b64")
        if not name or not b64:
            continue
        norm = os.path.normpath(name).replace("\\", "/")
        if norm.startswith("../") or norm.startswith("/") or norm == ".." or ":" in norm:
            fail("اسم ملف غير صالح داخل extra_assets: %r" % name)
        if norm.lower() in NATIVE_ASSETS_RESERVED:
            fail("لا يمكن استخدام الاسم %r في الملفات الإضافية — هذا اسم ملف أساسي محجوز في التطبيق" % name)
        dest = os.path.realpath(os.path.join(target_dir, norm))
        if os.path.commonpath([dest, target_root]) != target_root:
            fail("مسار غير صالح داخل extra_assets (خارج المجلد المسموح): %r" % name)
        try:
            data = base64.b64decode(b64, validate=False)
        except Exception as e:  # noqa: BLE001
            fail("محتوى الملف %r في extra_assets تالف: %s" % (name, e))
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        with open(dest, "wb") as f:
            f.write(data)
        count += 1

    print("ملفات إضافية داخل assets: %d ملف" % count)
    return count > 0


def apply_permissions(project, cfg):
    """يضيف الأذونات الاختيارية إلى AndroidManifest.xml (الأساسية موجودة أصلاً في القالب)."""
    chosen = cfg.get("permissions") or []
    if not isinstance(chosen, list):
        fail("حقل permissions في config.json يجب أن يكون قائمة")
    chosen = [c for c in chosen if c not in LEGACY_PERMISSIONS]
    unknown = [c for c in chosen if c not in PERMISSION_CATALOG]
    if unknown:
        fail("أذونات غير معروفة: " + ", ".join(map(str, unknown)))
    path = os.path.join(project, "app/src/main/AndroidManifest.xml")
    xml = read(path)
    xml = re.sub(r"[ \t]*<!-- RT-PERMS:START -->.*?<!-- RT-PERMS:END -->\n?", "", xml, flags=re.S)
    xml = re.sub(r"[ \t]*<!-- RT-SERVICES:START -->.*?<!-- RT-SERVICES:END -->\n?", "", xml, flags=re.S)
    if not chosen:
        write(path, xml)
        print("الأذونات الاختيارية: لا شيء")
        return
    lines = ["\t<!-- RT-PERMS:START -->"]
    service_lines = ["\t\t<!-- RT-SERVICES:START -->"]
    has_service = False
    seen = set(re.findall(r'<uses-permission[^>]*android:name="([^"]+)"', xml))
    for key in sorted(set(chosen)):
        info = PERMISSION_CATALOG[key]
        for pm in info["perms"]:
            name, max_sdk = (pm, None) if isinstance(pm, str) else pm
            if name in seen:
                continue
            seen.add(name)
            extra = ' android:maxSdkVersion="%d"' % max_sdk if max_sdk else ""
            if name == "android.permission.BLUETOOTH_SCAN":
                extra = ' android:usesPermissionFlags="neverForLocation"'
            lines.append('\t<uses-permission android:name="%s"%s />' % (name, extra))
        for feat, req in info["features"]:
            lines.append('\t<uses-feature android:name="%s" android:required="%s" />' % (feat, "true" if req else "false"))
        svc = info.get("service")
        if svc:
            for one in ([svc] if isinstance(svc, str) else svc):
                if one not in service_lines:   # لا نكرّر نفس المكوّن (مثل RtBootReceiver المشترك)
                    has_service = True
                    service_lines.append(one)
    lines.append("\t<!-- RT-PERMS:END -->")
    block = "\n".join(lines) + "\n"
    if "<application" not in xml:
        fail("لم أجد <application> في AndroidManifest.xml")
    xml = xml.replace("\t<application", block + "\t<application", 1)
    if has_service:
        service_lines.append("\t\t<!-- RT-SERVICES:END -->")
        service_block = "\n".join(service_lines) + "\n"
        if "\t</application>" not in xml:
            fail("لم أجد </application> في AndroidManifest.xml")
        xml = xml.replace("\t</application>", service_block + "\t</application>", 1)
    write(path, xml)
    print("الأذونات الاختيارية:", ", ".join(sorted(set(chosen))))


# معرّفات الاختبار الرسمية من Google (آمنة: النقر عليها لا يضرّ حسابك)
ADS_TEST = {
    "app": "ca-app-pub-3940256099942544~3347511713",
    "banner": "ca-app-pub-3940256099942544/6300978111",
    "interstitial": "ca-app-pub-3940256099942544/1033173712",
    "rewarded": "ca-app-pub-3940256099942544/5224354917",
}
ADS_MIN_SDK = 23   # مكتبة play-services-ads الحديثة تتطلب API 23 على الأقل


def ads_settings(cfg):
    """يقرأ ويتحقق من إعدادات الإعلانات. يرجع None إن كانت معطّلة."""
    ads = cfg.get("ads")
    if not isinstance(ads, dict) or not ads.get("enabled"):
        return None
    test = bool(ads.get("test_mode"))
    app_id = str(ads.get("app_id") or "").strip()
    ids = {k: str(ads.get(k + "_id") or "").strip() for k in ("banner", "interstitial", "rewarded")}
    if test:
        app_id = ADS_TEST["app"]
        ids = {k: ADS_TEST[k] for k in ids}
    else:
        if not re.fullmatch(r"ca-app-pub-\d{16}~\d{10}", app_id):
            fail("معرّف تطبيق AdMob غير صالح أو ناقص (الشكل: ca-app-pub-XXXXXXXXXXXXXXXX~XXXXXXXXXX)")
        for k, v in ids.items():
            if v and not re.fullmatch(r"ca-app-pub-\d{16}/\d{10}", v):
                fail("معرّف وحدة إعلانية (%s) غير صالح (الشكل: ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX)" % k)
        if not any(ids.values()):
            fail("الإعلانات مفعّلة لكن لا توجد أي وحدة إعلانية: أدخل واحدة على الأقل أو فعّل وضع الاختبار")
    return {"test": test, "app_id": app_id, "ids": ids}


def apply_ads(project, cfg):
    """يفعّل الإعلانات (AdMob) أو يتركها خارج التطبيق تماماً."""
    st = ads_settings(cfg)
    gradle_path = os.path.join(project, "app/build.gradle")
    manifest_path = os.path.join(project, "app/src/main/AndroidManifest.xml")
    java_path = os.path.join(project, "app/src/main/java/com/createdby/rostrick/RtAds.java")

    g = re.sub(r"[ \t]*// RT-ADS:START.*?// RT-ADS:END\n?", "", read(gradle_path), flags=re.S)
    m = re.sub(r"[ \t]*<!-- RT-ADS:START -->.*?<!-- RT-ADS:END -->\n?", "", read(manifest_path), flags=re.S)
    if st is None:
        write(gradle_path, g)
        write(manifest_path, m)
        print("الإعلانات: معطّلة (لا مكتبة إعلانات داخل التطبيق)")
        return False

    real = read(os.path.join(os.path.dirname(os.path.abspath(__file__)), "RtAdsReal.java.txt"))
    for key, ph in (("banner", "__RT_BANNER__"), ("interstitial", "__RT_INTERSTITIAL__"), ("rewarded", "__RT_REWARDED__")):
        real = real.replace(ph, st["ids"][key])
    if "__RT_" in real:
        fail("بقيت علامات غير مستبدلة في RtAdsReal.java.txt")
    write(java_path, real)

    dep = ('\t// RT-ADS:START\n'
           '\timplementation "com.google.android.gms:play-services-ads:${project.findProperty(\'adsVersion\') ?: \'24.4.0\'}"\n'
           '\t// RT-ADS:END\n')
    anchor = re.search(r'^.*rootbeer-lib.*\n', g, flags=re.M)
    if not anchor:
        fail("تعذّر إيجاد مكان إضافة مكتبة الإعلانات في app/build.gradle")
    g = g[:anchor.end()] + dep + g[anchor.end():]
    write(gradle_path, g)

    meta = ('\t\t<!-- RT-ADS:START -->\n'
            '\t\t<meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="%s" />\n'
            '\t\t<!-- RT-ADS:END -->\n') % st["app_id"]
    if "</application>" not in m:
        fail("لم أجد </application> في AndroidManifest.xml")
    m = m.replace("\t</application>", meta + "\t</application>", 1)
    write(manifest_path, m)
    print("الإعلانات (AdMob): مفعّلة (%s) | الوحدات: %s" % ("وضع الاختبار" if st["test"] else "حقيقية",
          ", ".join(k for k, v in st["ids"].items() if v)))
    return True


def unity_ads_settings(cfg):
    """يقرأ ويتحقق من إعدادات إعلانات Unity Ads. يرجع None إن كانت معطّلة.
    بخلاف AdMob: لا يوجد لدى Unity معرّف Placement تجريبي عام مضمون لكل الأنواع (البانر خاصة)،
    لذا تُطلب معرّفات حقيقية دائماً — وضع الاختبار هنا يمرَّر فقط كعلم testMode لتصنيف الإعلان غير فعلي."""
    ads = cfg.get("unity_ads")
    if not isinstance(ads, dict) or not ads.get("enabled"):
        return None
    test = bool(ads.get("test_mode"))
    game_id = str(ads.get("game_id") or "").strip()
    ids = {k: str(ads.get(k + "_id") or "").strip() for k in ("banner", "interstitial", "rewarded")}
    if not re.fullmatch(r"\d{3,12}", game_id):
        fail("معرّف لعبة Unity Ads (Game ID) غير صالح أو ناقص (أرقام فقط)")
    if not any(ids.values()):
        fail("إعلانات Unity مفعّلة لكن لا يوجد أي Placement ID: أدخل واحداً على الأقل (لا يوجد معرّف تجريبي عام مضمون لدى Unity)")
    return {"test": test, "game_id": game_id, "ids": ids}


def apply_unity_ads(project, cfg):
    """يفعّل إعلانات Unity Ads أو يتركها خارج التطبيق تماماً."""
    st = unity_ads_settings(cfg)
    gradle_path = os.path.join(project, "app/build.gradle")
    java_path = os.path.join(project, "app/src/main/java/com/createdby/rostrick/RtUnityAds.java")

    g = re.sub(r"[ \t]*// RT-UNITYADS:START.*?// RT-UNITYADS:END\n?", "", read(gradle_path), flags=re.S)
    if st is None:
        write(gradle_path, g)
        print("الإعلانات (Unity Ads): معطّلة (لا مكتبة إعلانات داخل التطبيق)")
        return False

    real = read(os.path.join(os.path.dirname(os.path.abspath(__file__)), "RtUnityAdsReal.java.txt"))
    real = real.replace("__RT_UNITY_GAMEID__", st["game_id"])
    real = real.replace("__RT_UNITY_TESTMODE__", "true" if st["test"] else "false")
    for key, ph in (("banner", "__RT_UNITY_BANNER__"), ("interstitial", "__RT_UNITY_INTERSTITIAL__"), ("rewarded", "__RT_UNITY_REWARDED__")):
        real = real.replace(ph, st["ids"][key])
    if "__RT_UNITY_" in real:
        fail("بقيت علامات غير مستبدلة في RtUnityAdsReal.java.txt")
    write(java_path, real)

    dep = ('\t// RT-UNITYADS:START\n'
           '\timplementation "com.unity3d.ads:unity-ads:${project.findProperty(\'unityAdsVersion\') ?: \'4.12.2\'}"\n'
           '\t// RT-UNITYADS:END\n')
    anchor = re.search(r'^.*rootbeer-lib.*\n', g, flags=re.M)
    if not anchor:
        fail("تعذّر إيجاد مكان إضافة مكتبة Unity Ads في app/build.gradle")
    g = g[:anchor.end()] + dep + g[anchor.end():]
    write(gradle_path, g)
    print("الإعلانات (Unity Ads): مفعّلة (%s) | الوحدات: %s" % ("وضع الاختبار" if st["test"] else "حقيقية",
          ", ".join(k for k, v in st["ids"].items() if v)))
    return True


def fb_ads_settings(cfg):
    """يقرأ ويتحقق من إعدادات إعلانات Meta Audience Network (فيسبوك). يرجع None إن كانت معطّلة."""
    ads = cfg.get("facebook_ads")
    if not isinstance(ads, dict) or not ads.get("enabled"):
        return None
    test = bool(ads.get("test_mode"))
    ids = {k: str(ads.get(k + "_id") or "").strip() for k in ("banner", "interstitial", "rewarded")}
    # لا توجد لدى فيسبوك معرّفات Placement تجريبية عامة كـ AdMob: لا بد من معرّف حقيقي حتى في وضع الاختبار
    for k, v in ids.items():
        if v and not re.fullmatch(r"\d+_\d+", v):
            fail("معرّف Placement فيسبوك (%s) غير صالح (الشكل المتوقع: أرقام_أرقام)" % k)
    if not any(ids.values()):
        fail("إعلانات فيسبوك مفعّلة لكن لا يوجد أي Placement ID: أدخل واحداً على الأقل (لا يوجد معرّف تجريبي عام لدى فيسبوك)")
    return {"test": test, "ids": ids}


def apply_fb_ads(project, cfg):
    """يفعّل إعلانات Meta Audience Network (فيسبوك) أو يتركها خارج التطبيق تماماً."""
    st = fb_ads_settings(cfg)
    gradle_path = os.path.join(project, "app/build.gradle")
    java_path = os.path.join(project, "app/src/main/java/com/createdby/rostrick/RtFbAds.java")

    g = re.sub(r"[ \t]*// RT-FBADS:START.*?// RT-FBADS:END\n?", "", read(gradle_path), flags=re.S)
    if st is None:
        write(gradle_path, g)
        print("الإعلانات (فيسبوك): معطّلة (لا مكتبة إعلانات داخل التطبيق)")
        return False

    real = read(os.path.join(os.path.dirname(os.path.abspath(__file__)), "RtFbAdsReal.java.txt"))
    real = real.replace("__RT_FB_TESTMODE__", "true" if st["test"] else "false")
    for key, ph in (("banner", "__RT_FB_BANNER__"), ("interstitial", "__RT_FB_INTERSTITIAL__"), ("rewarded", "__RT_FB_REWARDED__")):
        real = real.replace(ph, st["ids"][key])
    if "__RT_FB_" in real:
        fail("بقيت علامات غير مستبدلة في RtFbAdsReal.java.txt")
    write(java_path, real)

    dep = ('\t// RT-FBADS:START\n'
           '\timplementation "com.facebook.android:audience-network-sdk:${project.findProperty(\'fbAdsVersion\') ?: \'6.19.0\'}"\n'
           '\t// RT-FBADS:END\n')
    anchor = re.search(r'^.*rootbeer-lib.*\n', g, flags=re.M)
    if not anchor:
        fail("تعذّر إيجاد مكان إضافة مكتبة فيسبوك للإعلانات في app/build.gradle")
    g = g[:anchor.end()] + dep + g[anchor.end():]
    write(gradle_path, g)
    print("الإعلانات (فيسبوك): مفعّلة (%s) | الوحدات: %s" % ("وضع الاختبار" if st["test"] else "حقيقية",
          ", ".join(k for k, v in st["ids"].items() if v)))
    return True


JAVA_PKG_DIR = "app/src/main/java/com/createdby/rostrick"
STAT_ICON_XML = (
    '<?xml version="1.0" encoding="utf-8"?>\n'
    '<vector xmlns:android="http://schemas.android.com/apk/res/android"\n'
    '    android:width="24dp" android:height="24dp" android:viewportWidth="24" android:viewportHeight="24">\n'
    '    <path android:fillColor="#FFFFFFFF" android:pathData="M12,22c1.1,0 2,-0.9 2,-2h-4c0,1.1 0.89,2 2,2zM18,16v-5c0,-3.07 -1.64,-5.64 -4.5,-6.32V4c0,-0.83 -0.67,-1.5 -1.5,-1.5s-1.5,0.67 -1.5,1.5v0.68C7.63,5.36 6,7.92 6,11v5l-2,2v1h16v-1l-2,-2z"/>\n'
    '</vector>\n'
)


def firebase_settings(cfg, pkg):
    """يرجع نص google-services.json إن كان Firebase مفعّلاً (بعد التحقق)، وإلا None."""
    fb = cfg.get("firebase")
    if not isinstance(fb, dict) or not fb.get("enabled"):
        return None
    raw = str(fb.get("google_services_b64") or "").strip()
    if not raw:
        fail("Firebase مفعّل لكن ملف google-services.json غير مرفوع. ارفعه من قسم البناء أو أطفئ الخيار")
    try:
        text = base64.b64decode(raw).decode("utf-8")
        data = json.loads(text)
    except Exception:  # noqa: BLE001
        fail("ملف google-services.json تالف أو ليس JSON صالحاً")
    pkgs = []
    for c in data.get("client", []) if isinstance(data, dict) else []:
        try:
            pkgs.append(c["client_info"]["android_client_info"]["package_name"])
        except Exception:  # noqa: BLE001
            pass
    if pkg not in pkgs:
        fail("اسم الحزمة في RosTrick (%s) لا يطابق ملف google-services.json (الموجود: %s). أضف تطبيق أندرويد في Firebase بنفس اسم الحزمة ثم نزّل الملف من جديد"
             % (pkg, ", ".join(pkgs) or "لا شيء"))
    return text


def strip_marked(text, start, end):
    return re.sub(r"[ \t]*%s.*?%s\n?" % (re.escape(start), re.escape(end)), "", text, flags=re.S)


def apply_firebase(project, cfg, pkg):
    """يفعّل إشعارات Firebase (FCM) أو يتركها خارج التطبيق تماماً."""
    gs = firebase_settings(cfg, pkg)
    root_gradle = os.path.join(project, "build.gradle")
    app_gradle = os.path.join(project, "app/build.gradle")
    manifest = os.path.join(project, "app/src/main/AndroidManifest.xml")
    gs_path = os.path.join(project, "app/google-services.json")
    svc_path = os.path.join(project, JAVA_PKG_DIR, "RtMessagingService.java")
    icon_path = os.path.join(project, "app/src/main/res/drawable/ic_stat_rostrick.xml")

    rg = strip_marked(read(root_gradle), "// RT-FB:START", "// RT-FB:END")
    g = strip_marked(read(app_gradle), "// RT-FB:START", "// RT-FB:END")
    g = re.sub(r"\n[ \t]*id 'com\.google\.gms\.google-services'[^\n]*", "", g)
    m = strip_marked(read(manifest), "<!-- RT-FB:START -->", "<!-- RT-FB:END -->")
    for stale in (gs_path, svc_path, icon_path):
        if os.path.exists(stale):
            os.remove(stale)
    if gs is None:
        write(root_gradle, rg); write(app_gradle, g); write(manifest, m)
        print("Firebase: معطّل (لا مكتبة ولا خدمة إشعارات داخل التطبيق)")
        return False

    tools = os.path.dirname(os.path.abspath(__file__))
    write(os.path.join(project, JAVA_PKG_DIR, "RtPush.java"), read(os.path.join(tools, "RtPushReal.java.txt")))
    write(svc_path, read(os.path.join(tools, "RtMessagingService.java.txt")))
    os.makedirs(os.path.dirname(icon_path), exist_ok=True)
    write(icon_path, STAT_ICON_XML)
    write(gs_path, gs)

    anchor = re.search(r"^.*classpath 'com\.android\.tools\.build:gradle:[^']*'.*\n", rg, flags=re.M)
    if not anchor:
        fail("تعذّر إيجاد classpath لـ AGP في build.gradle الرئيسي")
    rg = rg[:anchor.end()] + "        // RT-FB:START\n        classpath 'com.google.gms:google-services:4.4.2'\n        // RT-FB:END\n" + rg[anchor.end():]
    write(root_gradle, rg)

    pl = re.search(r"^[ \t]*id 'com\.android\.application'.*\n", g, flags=re.M)
    if not pl:
        fail("تعذّر إيجاد plugins في app/build.gradle")
    g = g[:pl.end()] + "\tid 'com.google.gms.google-services'\n" + g[pl.end():]
    dep = ('\t// RT-FB:START\n'
           "\timplementation platform(\"com.google.firebase:firebase-bom:${project.findProperty('firebaseBomVersion') ?: '33.16.0'}\")\n"
           "\timplementation 'com.google.firebase:firebase-messaging'\n"
           '\t// RT-FB:END\n')
    anchor = re.search(r'^.*rootbeer-lib.*\n', g, flags=re.M)
    if not anchor:
        fail("تعذّر إيجاد مكان إضافة مكتبة Firebase في app/build.gradle")
    g = g[:anchor.end()] + dep + g[anchor.end():]
    write(app_gradle, g)

    block = ('\t\t<!-- RT-FB:START -->\n'
             '\t\t<service android:name=".RtMessagingService" android:exported="false">\n'
             '\t\t\t<intent-filter>\n'
             '\t\t\t\t<action android:name="com.google.firebase.MESSAGING_EVENT" />\n'
             '\t\t\t</intent-filter>\n'
             '\t\t</service>\n'
             '\t\t<meta-data android:name="com.google.firebase.messaging.default_notification_icon" android:resource="@drawable/ic_stat_rostrick" />\n'
             '\t\t<meta-data android:name="com.google.firebase.messaging.default_notification_channel_id" android:value="rostrick_default" />\n'
             '\t\t<!-- RT-FB:END -->\n')
    if "</application>" not in m:
        fail("لم أجد </application> في AndroidManifest.xml")
    m = m.replace("\t</application>", block + "\t</application>", 1)
    write(manifest, m)
    print("Firebase: مفعّل (إشعارات FCM)")
    return True


def analytics_settings(cfg, fb_on):
    """إعدادات التحليلات (GA4 بدون مكتبة و/أو Firebase Analytics). يرجع None إن كانت معطّلة."""
    a = cfg.get("analytics")
    if not isinstance(a, dict) or not a.get("enabled"):
        return None
    g = a.get("ga4") if isinstance(a.get("ga4"), dict) else {}
    use_ga4 = bool(g.get("enabled"))
    use_fa = bool(a.get("firebase"))
    mid = str(g.get("measurement_id") or "").strip()
    sec = str(g.get("api_secret") or "").strip()
    if not use_ga4 and not use_fa:
        fail("التحليلات مفعّلة لكن لم تختر GA4 ولا Firebase Analytics")
    if use_ga4:
        if not re.fullmatch(r"G-[A-Z0-9]{4,20}", mid):
            fail("معرّف قياس GA4 غير صالح (الشكل: G-XXXXXXXXXX)")
        if not re.fullmatch(r"[A-Za-z0-9_\-]{8,64}", sec):
            fail("مفتاح API الخاص بـ GA4 (Measurement Protocol API secret) غير صالح أو مفقود")
    if use_fa and not fb_on:
        fail("Firebase Analytics يحتاج تفعيل Firebase (ملف google-services.json) في نفس البناء")
    return {"ga4": use_ga4, "fa": use_fa, "mid": mid if use_ga4 else "", "sec": sec if use_ga4 else ""}


def apply_analytics(project, cfg, fb_on):
    """يفعّل التحليلات (اختياري) أو يتركها نسخة فارغة بلا أي اتصال."""
    app_gradle = os.path.join(project, "app/build.gradle")
    g = strip_marked(read(app_gradle), "// RT-FA:START", "// RT-FA:END")
    st = analytics_settings(cfg, fb_on)
    if st is None:
        write(app_gradle, g)
        print("التحليلات: معطّلة (لا اتصال ولا مكتبة)")
        return False
    tools = os.path.dirname(os.path.abspath(__file__))
    src = read(os.path.join(tools, "RtAnalyticsReal.java.txt"))
    if not st["fa"]:
        src = strip_marked(src, "//RT-FA:START", "//RT-FA:END")
    src = (src.replace("@@RT_GA4@@", "true" if st["ga4"] else "false")
              .replace("@@RT_FA@@", "true" if st["fa"] else "false")
              .replace("@@RT_GA4_ID@@", st["mid"])
              .replace("@@RT_GA4_SECRET@@", st["sec"]))
    write(os.path.join(project, JAVA_PKG_DIR, "RtAnalytics.java"), src)
    if st["fa"]:
        dep = ('\t// RT-FA:START\n'
               "\timplementation 'com.google.firebase:firebase-analytics'\n"
               '\t// RT-FA:END\n')
        anchor = re.search(r'^.*rootbeer-lib.*\n', g, flags=re.M)
        if not anchor:
            fail("تعذّر إيجاد مكان إضافة مكتبة Firebase Analytics في app/build.gradle")
        g = g[:anchor.end()] + dep + g[anchor.end():]
    write(app_gradle, g)
    print("التحليلات: مفعّلة" + (" — GA4 (بدون مكتبة)" if st["ga4"] else "") + (" — Firebase Analytics" if st["fa"] else ""))
    return True


def billing_enabled(cfg):
    b = cfg.get("billing")
    return isinstance(b, dict) and bool(b.get("enabled"))


def billing_public_key(cfg):
    """مفتاح الترخيص العام (Base64) من Play Console، اختياري. يُتحقق من شكله لأنه يُكتب داخل كود Java."""
    b = cfg.get("billing")
    raw = (b.get("public_key") if isinstance(b, dict) else "") or ""
    key = re.sub(r"\s+", "", str(raw))
    if not key:
        return ""
    if not re.fullmatch(r"[A-Za-z0-9+/]+={0,2}", key):
        fail("مفتاح الترخيص (billing.public_key) يحتوي رموزاً غير صالحة؛ يجب أن يكون Base64 فقط")
    if len(key) < 200 or len(key) > 2000:
        fail("طول مفتاح الترخيص غير منطقي (%d)؛ انسخه كاملاً من Play Console" % len(key))
    try:
        import base64 as _b64
        raw_bytes = _b64.b64decode(key, validate=True)
    except Exception:  # noqa: BLE001
        fail("مفتاح الترخيص ليس Base64 صحيحاً")
    if not raw_bytes.startswith(b"\x30\x82"):
        fail("مفتاح الترخيص لا يبدو مفتاح RSA عاماً (X.509)؛ يبدأ عادةً بـ MIIB")
    return key


def apply_billing(project, cfg):
    """يفعّل الشراء داخل التطبيق (Google Play Billing) أو يتركه خارج التطبيق تماماً."""
    app_gradle = os.path.join(project, "app/build.gradle")
    g = strip_marked(read(app_gradle), "// RT-BILL:START", "// RT-BILL:END")
    if not billing_enabled(cfg):
        write(app_gradle, g)
        print("الشراء داخل التطبيق: معطّل (لا مكتبة فوترة داخل التطبيق)")
        return False
    tools = os.path.dirname(os.path.abspath(__file__))
    src = read(os.path.join(tools, "RtBillingReal.java.txt"))
    key = billing_public_key(cfg)
    if "@@RT_BILLING_KEY@@" not in src:
        fail("قالب الشراء لا يحتوي موضع مفتاح الترخيص")
    src = src.replace("@@RT_BILLING_KEY@@", key)
    write(os.path.join(project, JAVA_PKG_DIR, "RtBilling.java"), src)
    dep = ('\t// RT-BILL:START\n'
           "\timplementation \"com.android.billingclient:billing:${project.findProperty('billingVersion') ?: '8.0.0'}\"\n"
           '\t// RT-BILL:END\n')
    anchor = re.search(r'^.*rootbeer-lib.*\n', g, flags=re.M)
    if not anchor:
        fail("تعذّر إيجاد مكان إضافة مكتبة الفوترة في app/build.gradle")
    g = g[:anchor.end()] + dep + g[anchor.end():]
    write(app_gradle, g)
    print("الشراء داخل التطبيق: مفعّل (Google Play Billing)" + (" — مع التحقق من توقيع الشراء" if key else ""))
    return True


def _insert_in_splash(m, block):
    """يُدخل block قبل </activity> الخاص بـ SplashActivity مهما أضافت الخطوات الأخرى للمانيفست."""
    i = m.find('android:name=".SplashActivity"')
    if i < 0:
        fail("تعذّر إيجاد SplashActivity في AndroidManifest.xml")
    j = m.find("</activity>", i)
    if j < 0:
        fail("تعذّر إيجاد نهاية SplashActivity في AndroidManifest.xml")
    ls = m.rfind("\n", 0, j) + 1
    return m[:ls] + block + m[ls:]


def deeplinks_settings(cfg):
    """إعدادات الروابط العميقة: scheme مخصص (مثل myapp://) و/أو نطاقات https. يُرجع None إن لم تُفعَّل."""
    d = cfg.get("deeplinks")
    if not isinstance(d, dict) or not d.get("enabled"):
        return None
    scheme = str(d.get("scheme") or "").strip().lower()
    if scheme:
        if not re.fullmatch(r"[a-z][a-z0-9+.-]{1,30}", scheme):
            fail("اسم الـ scheme للروابط العميقة غير صالح: %r (أحرف إنجليزية صغيرة وأرقام فقط، مثل myapp)" % scheme)
        if scheme in ("http", "https", "file", "content", "intent", "javascript", "data", "about", "market", "android-app"):
            fail("اسم الـ scheme محجوز للنظام: " + scheme)
    hosts_raw = d.get("hosts") or []
    if isinstance(hosts_raw, str):
        hosts_raw = [h for h in re.split(r"[\s,]+", hosts_raw) if h]
    if not isinstance(hosts_raw, list) or len(hosts_raw) > 10:
        fail("نطاقات الروابط العميقة (deeplinks.hosts) يجب أن تكون قائمة بحد أقصى 10")
    hosts = []
    for h in hosts_raw:
        h = clean_host(str(h))
        if h and h not in hosts:
            hosts.append(h)
    if not scheme and not hosts:
        fail("الروابط العميقة مفعّلة لكن بدون scheme ولا نطاقات؛ أضف واحداً على الأقل")
    fps_raw = d.get("extra_fingerprints") or []
    if isinstance(fps_raw, str):
        fps_raw = [f for f in re.split(r"[\s,]+", fps_raw) if f]
    fps = []
    for f in fps_raw[:5]:
        f = str(f).strip().upper()
        if not re.fullmatch(r"([0-9A-F]{2}:){31}[0-9A-F]{2}", f):
            fail("بصمة SHA-256 الإضافية غير صالحة (يجب 32 زوجاً سداسياً تفصلها نقطتان رأسيتان، مثل AA:BB:...): " + f)
        if f not in fps:
            fps.append(f)
    return {"scheme": scheme, "hosts": hosts, "verify": bool(d.get("verify")), "extra_fingerprints": fps}


def apply_deeplinks(project, cfg):
    """يضيف intent-filters للروابط العميقة داخل SplashActivity، ويجعل MainActivity singleTask لاستقبال الروابط أثناء تشغيل التطبيق."""
    manifest = os.path.join(project, "app/src/main/AndroidManifest.xml")
    m = strip_marked(read(manifest), "<!-- RT-DEEPLINK:START -->", "<!-- RT-DEEPLINK:END -->")
    m = m.replace('\t\t\tandroid:launchMode="singleTask"\n', "")
    st = deeplinks_settings(cfg)
    if not st:
        write(manifest, m)
        print("الروابط العميقة: معطّلة")
        return False
    lines = ['\t\t\t<!-- RT-DEEPLINK:START -->']
    if st["scheme"]:
        lines += ['\t\t\t<intent-filter>',
                  '\t\t\t\t<action android:name="android.intent.action.VIEW" />',
                  '\t\t\t\t<category android:name="android.intent.category.DEFAULT" />',
                  '\t\t\t\t<category android:name="android.intent.category.BROWSABLE" />',
                  '\t\t\t\t<data android:scheme="%s" />' % st["scheme"],
                  '\t\t\t</intent-filter>']
    if st["hosts"]:
        lines += ['\t\t\t<intent-filter%s>' % (' android:autoVerify="true"' if st["verify"] else ''),
                  '\t\t\t\t<action android:name="android.intent.action.VIEW" />',
                  '\t\t\t\t<category android:name="android.intent.category.DEFAULT" />',
                  '\t\t\t\t<category android:name="android.intent.category.BROWSABLE" />',
                  '\t\t\t\t<data android:scheme="https" />']
        lines += ['\t\t\t\t<data android:host="%s" />' % h for h in st["hosts"]]
        lines += ['\t\t\t</intent-filter>']
    lines.append('\t\t\t<!-- RT-DEEPLINK:END -->')
    block = "\n".join(lines) + "\n"
    m = _insert_in_splash(m, block)
    mk = '\t\t\tandroid:name=".MainActivity"\n'
    if mk not in m:
        fail("تعذّر إيجاد MainActivity في AndroidManifest.xml")
    m = m.replace(mk, mk + '\t\t\tandroid:launchMode="singleTask"\n', 1)
    write(manifest, m)
    print("الروابط العميقة: مفعّلة" + (" — scheme: %s://" % st["scheme"] if st["scheme"] else "") + (" — نطاقات: " + ", ".join(st["hosts"]) if st["hosts"] else ""))
    return True


def review_enabled(cfg):
    r = cfg.get("review")
    return isinstance(r, dict) and bool(r.get("enabled"))


def apply_review(project, cfg):
    """يفعّل طلب التقييم داخل التطبيق (Google Play In-App Review) أو يتركه خارج التطبيق تماماً."""
    app_gradle = os.path.join(project, "app/build.gradle")
    g = strip_marked(read(app_gradle), "// RT-REVIEW:START", "// RT-REVIEW:END")
    if not review_enabled(cfg):
        write(app_gradle, g)
        print("طلب التقييم داخل التطبيق: معطّل (لا مكتبة تقييم)")
        return False
    tools = os.path.dirname(os.path.abspath(__file__))
    src = read(os.path.join(tools, "RtReviewReal.java.txt"))
    write(os.path.join(project, JAVA_PKG_DIR, "RtReview.java"), src)
    dep = ('\t// RT-REVIEW:START\n'
           "\timplementation \"com.google.android.play:review:${project.findProperty('playReviewVersion') ?: '2.0.2'}\"\n"
           '\t// RT-REVIEW:END\n')
    anchor = re.search(r'^.*rootbeer-lib.*\n', g, flags=re.M)
    if not anchor:
        fail("تعذّر إيجاد مكان إضافة مكتبة التقييم في app/build.gradle")
    g = g[:anchor.end()] + dep + g[anchor.end():]
    write(app_gradle, g)
    print("طلب التقييم داخل التطبيق: مفعّل (Google Play In-App Review)")
    return True


def apply_webview_check(project, cfg):
    """فحص إصدار WebView عند التشغيل (اختياري): يكتب assets/rt_webview_check.json أو يحذفه."""
    import json
    path = os.path.join(project, "app/src/main/assets/rt_webview_check.json")
    w = cfg.get("webview_check")
    if not (isinstance(w, dict) and w.get("enabled")):
        if os.path.exists(path):
            os.remove(path)
        print("فحص إصدار WebView: معطّل")
        return False
    try:
        mv = int(w.get("min_version", 120))
        fv = int(w.get("force_version", 0))
    except (TypeError, ValueError):
        fail("حدود إصدار WebView يجب أن تكون أرقاماً")
    if mv != 0 and not (60 <= mv <= 400):
        fail("حد التنبيه الاختياري لإصدار WebView يجب أن يكون 0 (معطّل) أو بين 60 و400")
    if fv != 0 and not (60 <= fv <= 400):
        fail("حد الإلزام لإصدار WebView يجب أن يكون 0 (معطّل) أو بين 60 و400")
    if mv == 0 and fv == 0:
        if os.path.exists(path):
            os.remove(path)
        print("فحص إصدار WebView: معطّل (الحدّان 0)")
        return False
    write(path, json.dumps({"enabled": True, "min_version": mv, "force_version": fv}))
    print("فحص إصدار WebView: مفعّل (تنبيه اختياري إن كان أقل من %s، إلزامي إن كان أقل من %s)" % (mv or "—", fv or "—"))
    return True


# Tesseract4Android منشورة على JitPack فقط (ليست على Maven Central ولا Google Maven)؛ 4.9.0 هو الإصدار الموثّق هناك.
OCR_DEFAULT_LIBRARY = "cz.adaptech.tesseract4android:tesseract4android:4.9.0"
OCR_JITPACK_GROUPS = ("cz.adaptech.tesseract4android",)


def jitpack_group_rule(lib):
    """سطر content{} يحصر JitPack بمجموعة المكتبة فقط، أو None إن كانت المكتبة تُحلّ من Maven Central/Google."""
    group = lib.split(":", 1)[0]
    if group.startswith("com.github."):
        return "includeGroupByRegex 'com\\\\.github\\\\..*'"
    if group in OCR_JITPACK_GROUPS:
        return "includeGroup '%s'" % group
    return None


def ocr_settings(cfg):
    """إعدادات OCR (Tesseract): {"enabled": true, "languages": ["ara","eng"], "quality": "fast"|"best"}. يُرجع None إن لم تُفعَّل."""
    o = cfg.get("ocr")
    if not isinstance(o, dict) or not o.get("enabled"):
        return None
    raw = o.get("languages") or ["ara", "eng"]
    if isinstance(raw, str):
        raw = [x for x in re.split(r"[\s,+]+", raw) if x]
    if not isinstance(raw, list) or not raw or len(raw) > 6:
        fail("لغات OCR (ocr.languages) يجب أن تكون قائمة من 1 إلى 6 لغات مثل [\"ara\",\"eng\"]")
    langs = []
    for l in raw:
        l = str(l).strip().lower()
        if not re.fullmatch(r"[a-z]{3}(_[a-z]{3,8})?", l):
            fail("رمز لغة OCR غير صالح: %r (ثلاثة أحرف مثل ara وeng)" % l)
        if l not in langs:
            langs.append(l)
    quality = str(o.get("quality") or "fast").lower()
    if quality not in ("fast", "best"):
        fail("جودة OCR (ocr.quality) يجب أن تكون fast أو best")
    lib = str(o.get("library") or OCR_DEFAULT_LIBRARY).strip()
    if not re.fullmatch(r"[A-Za-z0-9_.\-]+:[A-Za-z0-9_.\-]+:[A-Za-z0-9_.\-+]+", lib):
        fail("مكتبة OCR (ocr.library) يجب أن تكون بصيغة group:artifact:version")
    return {"languages": langs, "quality": quality, "library": lib}


def _fetch_traineddata(tools, lang, quality, dest):
    """يجلب ملف لغة Tesseract: من tools/tessdata إن وُجد محلياً، وإلا من مستودع tesseract-ocr الرسمي على GitHub."""
    import shutil
    import time
    import urllib.request
    local = os.path.join(tools, "tessdata", lang + ".traineddata")
    if os.path.isfile(local):
        shutil.copyfile(local, dest)
        return "محلي"
    url = "https://raw.githubusercontent.com/tesseract-ocr/tessdata_%s/main/%s.traineddata" % (quality, lang)
    last = None
    for attempt in range(3):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "RosTrick-build"})
            with urllib.request.urlopen(req, timeout=60) as r:
                data = r.read()
            if len(data) < 50000 or data[:1] in (b"<", b"{"):
                raise ValueError("الملف المُنزَّل ليس ملف لغة صالحاً (%d بايت)" % len(data))
            with open(dest, "wb") as f:
                f.write(data)
            return "تنزيل"
        except Exception as e:  # noqa: BLE001
            last = e
            time.sleep(2 * (attempt + 1))
    fail("تعذّر جلب ملف لغة OCR (%s) من %s: %s" % (lang, url, last))


def apply_ocr(project, cfg):
    """يفعّل قراءة النص من الصور (Tesseract) اختيارياً: ينسخ RtOcr الحقيقي ويضيف المكتبة وملفات اللغات إلى assets/tessdata."""
    import shutil
    app_gradle = os.path.join(project, "app/build.gradle")
    root_gradle = os.path.join(project, "build.gradle")
    pro = os.path.join(project, "app/proguard-rules.pro")
    g = strip_marked(read(app_gradle), "// RT-OCR:START", "// RT-OCR:END")
    rg = strip_marked(read(root_gradle), "// RT-OCR:START", "// RT-OCR:END")
    pr = strip_marked(read(pro), "# RT-OCR:START", "# RT-OCR:END") if os.path.exists(pro) else None
    td = os.path.join(project, "app/src/main/assets/tessdata")
    if os.path.isdir(td):
        shutil.rmtree(td)
    st = ocr_settings(cfg)
    if not st:
        write(app_gradle, g)
        write(root_gradle, rg)
        if pr is not None:
            write(pro, pr)
        print("قراءة النص من الصور (OCR): معطّلة (لا مكتبة Tesseract ولا ملفات لغات)")
        return False
    tools = os.path.dirname(os.path.abspath(__file__))
    write(os.path.join(project, JAVA_PKG_DIR, "RtOcr.java"), read(os.path.join(tools, "RtOcrReal.java.txt")))
    os.makedirs(td, exist_ok=True)
    how = []
    for lang in st["languages"]:
        how.append("%s (%s)" % (lang, _fetch_traineddata(tools, lang, st["quality"], os.path.join(td, lang + ".traineddata"))))
    dep = ('\t// RT-OCR:START\n'
           "\timplementation \"${project.findProperty('tesseractCoordinate') ?: '%s'}\"\n"
           '\t// RT-OCR:END\n') % st["library"]
    anchor = re.search(r'^.*rootbeer-lib.*\n', g, flags=re.M)
    if not anchor:
        fail("تعذّر إيجاد مكان إضافة مكتبة OCR في app/build.gradle")
    g = g[:anchor.end()] + dep + g[anchor.end():]
    write(app_gradle, g)
    rule = jitpack_group_rule(st["library"])
    if rule:
        a = re.search(r"allprojects\s*\{\s*repositories\s*\{\n", rg)
        if not a:
            fail("تعذّر إيجاد repositories في build.gradle الجذر لإضافة JitPack")
        rg = rg[:a.end()] + ("        // RT-OCR:START\n"
                             "        maven {\n"
                             "            url 'https://jitpack.io'\n"
                             "            content { %s }\n"
                             "        }\n"
                             "        // RT-OCR:END\n") % rule + rg[a.end():]
    write(root_gradle, rg)
    if pr is not None:
        pr += "\n# RT-OCR:START\n-keep class com.googlecode.tesseract.android.** { *; }\n# RT-OCR:END\n"
        write(pro, pr)
    print("قراءة النص من الصور (OCR): مفعّلة — اللغات: %s — الجودة: %s — المكتبة: %s" % (", ".join(how), st["quality"], st["library"]))
    return True


MIME_RE = re.compile(r"(\*|[a-z0-9][a-z0-9.+-]*)/(\*|[A-Za-z0-9][A-Za-z0-9.+_-]*)")


def _mime_list(d, key):
    raw = d.get(key)
    if raw is None or raw is False:
        return []
    if raw is True:
        return ["*/*"]
    if isinstance(raw, str):
        raw = [x for x in re.split(r"[\s,]+", raw) if x]
    if not isinstance(raw, list) or len(raw) > 24:
        fail("intents.%s يجب أن تكون قائمة أنواع MIME (حد أقصى 24) مثل [\"image/*\",\"application/pdf\"]" % key)
    out = []
    for x in raw:
        x = str(x).strip().lower()
        if not MIME_RE.fullmatch(x):
            fail("نوع MIME غير صالح في intents.%s: %r" % (key, x))
        if x not in out:
            out.append(x)
    return out


def intents_settings(cfg):
    """استقبال الملفات/النصوص من تطبيقات أخرى: {"view": [mime…], "send": [mime…], "process_text": true}. يُرجع None إن لم يُحدَّد شيء."""
    d = cfg.get("intents")
    if not isinstance(d, dict):
        return None
    view = _mime_list(d, "view")
    send = _mime_list(d, "send")
    pt = bool(d.get("process_text"))
    if not (view or send or pt):
        return None
    return {"view": view, "send": send, "process_text": pt}


def apply_intents(project, cfg):
    """يضيف intent-filters (فتح بواسطة / مشاركة / تحديد نص) داخل SplashActivity ويجعل MainActivity singleTask. يجب استدعاؤه بعد apply_deeplinks."""
    manifest = os.path.join(project, "app/src/main/AndroidManifest.xml")
    m = strip_marked(read(manifest), "<!-- RT-INTENTS:START -->", "<!-- RT-INTENTS:END -->")
    st = intents_settings(cfg)
    if not st:
        write(manifest, m)
        print("استقبال الملفات من التطبيقات الأخرى (RosTrickIntent): معطّل")
        return False
    kinds = [k for k, on in (("view", st["view"]), ("send", st["send"]), ("process_text", st["process_text"])) if on]
    lines = ['\t\t\t<!-- RT-INTENTS:START -->',
             '\t\t\t<meta-data android:name="rt.intents" android:value="%s" />' % ",".join(kinds)]
    if st["view"]:
        lines += ['\t\t\t<intent-filter>',
                  '\t\t\t\t<action android:name="android.intent.action.VIEW" />',
                  '\t\t\t\t<category android:name="android.intent.category.DEFAULT" />']
        lines += ['\t\t\t\t<data android:mimeType="%s" />' % x for x in st["view"]]
        lines += ['\t\t\t</intent-filter>']
    if st["send"]:
        lines += ['\t\t\t<intent-filter>',
                  '\t\t\t\t<action android:name="android.intent.action.SEND" />',
                  '\t\t\t\t<action android:name="android.intent.action.SEND_MULTIPLE" />',
                  '\t\t\t\t<category android:name="android.intent.category.DEFAULT" />']
        lines += ['\t\t\t\t<data android:mimeType="%s" />' % x for x in st["send"]]
        lines += ['\t\t\t</intent-filter>']
    if st["process_text"]:
        lines += ['\t\t\t<intent-filter>',
                  '\t\t\t\t<action android:name="android.intent.action.PROCESS_TEXT" />',
                  '\t\t\t\t<category android:name="android.intent.category.DEFAULT" />',
                  '\t\t\t\t<data android:mimeType="text/plain" />',
                  '\t\t\t</intent-filter>']
    lines.append('\t\t\t<!-- RT-INTENTS:END -->')
    m = _insert_in_splash(m, "\n".join(lines) + "\n")
    mk = '\t\t\tandroid:name=".MainActivity"\n'
    if mk not in m:
        fail("تعذّر إيجاد MainActivity في AndroidManifest.xml")
    if 'android:launchMode="singleTask"' not in m:
        m = m.replace(mk, mk + '\t\t\tandroid:launchMode="singleTask"\n', 1)
    write(manifest, m)
    print("استقبال الملفات من التطبيقات الأخرى: مفعّل (%s)" % ", ".join(kinds))
    return True


def hardware_features(cfg):
    """واجهات العتاد المفعّلة: bluetooth (Web Bluetooth) وusb (WebUSB) وserial (Web Serial)."""
    h = cfg.get("hardware")
    if h is None:
        return []
    if not isinstance(h, dict):
        fail("حقل hardware في config.json يجب أن يكون كائناً مثل {\"bluetooth\": true}")
    unknown = [k for k in h if k not in ("bluetooth", "usb", "serial")]
    if unknown:
        fail("واجهات عتاد غير معروفة: " + ", ".join(map(str, unknown)))
    return [k for k in ("bluetooth", "usb", "serial") if h.get(k)]


def apply_hardware(project, cfg):
    """يفعّل Web Bluetooth/WebUSB/Web Serial (اختيارياً): ينسخ RtHw الحقيقي وملف JS ويضيف الأذونات اللازمة."""
    manifest = os.path.join(project, "app/src/main/AndroidManifest.xml")
    m = strip_marked(read(manifest), "<!-- RT-HW:START -->", "<!-- RT-HW:END -->")
    js_dest = os.path.join(project, "app/src/main/assets/rt-webapi-hw.js")
    feats = hardware_features(cfg)
    if not feats:
        write(manifest, m)
        if os.path.exists(js_dest):
            os.remove(js_dest)
        print("واجهات العتاد (بلوتوث/USB/Serial): معطّلة")
        return False
    tools = os.path.dirname(os.path.abspath(__file__))
    joined = ",".join(feats)
    java_src = read(os.path.join(tools, "RtHwReal.java.txt"))
    js_src = read(os.path.join(tools, "rt-webapi-hw.js.txt"))
    if "@@RT_HW_FEATURES@@" not in java_src or "@@RT_HW_FEATURES@@" not in js_src:
        fail("قالب واجهات العتاد لا يحتوي موضع قائمة الميزات")
    write(os.path.join(project, JAVA_PKG_DIR, "RtHw.java"), java_src.replace("@@RT_HW_FEATURES@@", joined))
    write(js_dest, js_src.replace("@@RT_HW_FEATURES@@", joined))
    seen = set(re.findall(r'<uses-permission[^>]*android:name="([^"]+)"', m))
    lines = ["\t<!-- RT-HW:START -->"]
    def add_perm(name, extra=""):
        if name in seen:
            return
        seen.add(name)
        lines.append('\t<uses-permission android:name="%s"%s />' % (name, extra))
    if "bluetooth" in feats:
        add_perm("android.permission.BLUETOOTH", ' android:maxSdkVersion="30"')
        add_perm("android.permission.BLUETOOTH_ADMIN", ' android:maxSdkVersion="30"')
        add_perm("android.permission.BLUETOOTH_SCAN", ' android:usesPermissionFlags="neverForLocation"')
        add_perm("android.permission.BLUETOOTH_CONNECT")
        add_perm("android.permission.ACCESS_FINE_LOCATION", ' android:maxSdkVersion="30"')
        lines.append('\t<uses-feature android:name="android.hardware.bluetooth_le" android:required="false" />')
    if "usb" in feats or "serial" in feats:
        lines.append('\t<uses-feature android:name="android.hardware.usb.host" android:required="false" />')
    lines.append("\t<!-- RT-HW:END -->")
    if "\t<application" not in m:
        fail("لم أجد <application> في AndroidManifest.xml")
    m = m.replace("\t<application", "\n".join(lines) + "\n\t<application", 1)
    write(manifest, m)
    print("واجهات العتاد: مفعّلة (%s)" % ", ".join(feats))
    return True


def resolve_output(cfg):
    out = cfg.get("output_format") or "apk"
    if out not in ("apk", "aab", "both"):
        fail("نوع المخرج غير صالح: %r (apk أو aab أو both)" % (out,))
    return out


def apply_home(project, cfg):
    """صفحة «جارٍ التحميل» الأولية داخل الـ APK (assets/home.html):
    - home_html_b64 نص → صفحة مخصصة يصممها المستخدم
    - غير موجود/null → تبقى الصفحة الافتراضية من القالب."""
    import base64
    raw = cfg.get("home_html_b64")
    if not raw:
        print("صفحة التحميل: الافتراضية")
        return
    try:
        html = base64.b64decode(raw, validate=False).decode("utf-8")
    except Exception as e:  # noqa: BLE001
        fail("home_html_b64 في config.json تالف: %s" % e)
    if not html.strip():
        fail("صفحة التحميل المخصصة فارغة")
    if len(html.encode("utf-8")) > 10 * 1024 * 1024:
        fail("صفحة التحميل المخصصة أكبر من 10MB")
    # التطبيق يستدعي هاتين الدالتين لتحديث التقدم؛ نضيف نسخاً فارغة إن لم تعرّفهما الصفحة حتى لا تظهر أخطاء JS
    stubs = ""
    if "setSyncProgress" not in html:
        stubs += "window.setSyncProgress=window.setSyncProgress||function(){};"
    if "setSyncStatus" not in html:
        stubs += "window.setSyncStatus=window.setSyncStatus||function(){};"
    if stubs:
        tag = "<script>" + stubs + "</script>"
        idx = html.lower().rfind("</body>")
        html = (html[:idx] + tag + html[idx:]) if idx != -1 else (html + tag)
        print("أضفتُ دوال التقدم الفارغة تلقائياً (الصفحة لا تعرّفها).")
    write(os.path.join(project, "app/src/main/assets/home.html"), html)
    print("صفحة التحميل: مخصصة (%d بايت)" % len(html.encode("utf-8")))


def set_output(key, value):
    path = os.environ.get("GITHUB_OUTPUT")
    line = "%s=%s\n" % (key, value)
    if path:
        with open(path, "a", encoding="utf-8") as f:
            f.write(line)
    else:
        print("[output]", line.strip())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--project", required=True)
    ap.add_argument("--icon", default="")
    a = ap.parse_args()

    try:
        cfg = json.loads(read(a.config))
    except Exception as e:  # noqa: BLE001
        fail("ملف الإعدادات تالف: %s" % e)

    pkg = cfg.get("package_name")
    validate_package(pkg)

    try:
        version_code = int(cfg.get("version_code"))
    except (TypeError, ValueError):
        fail("رقم الإصدار (version_code) يجب أن يكون رقماً صحيحاً")
    if not (1 <= version_code <= 2100000000):
        fail("رقم الإصدار خارج النطاق المسموح")

    version_name = str(cfg.get("version_name") or "").strip()
    if not re.fullmatch(r"[A-Za-z0-9._+\- ]{1,40}", version_name):
        fail("اسم الإصدار (version_name) غير صالح: %r" % version_name)

    host = clean_host(cfg.get("asset_base_host"))
    if not host:
        fail("رابط الـ Worker فارغ: اضبطه في إعدادات اللوحة أولاً")

    apply_strings(a.project, cfg.get("app_name"))
    apply_colors(a.project, cfg.get("colors"))
    min_sdk, target_sdk = resolve_sdk(cfg)
    ads_on = ads_settings(cfg) is not None
    unityads_on = unity_ads_settings(cfg) is not None
    fbads_on = fb_ads_settings(cfg) is not None
    bill_on = billing_enabled(cfg)
    if (ads_on or unityads_on or fbads_on or bill_on) and min_sdk < ADS_MIN_SDK:
        print("تنبيه: الإعلانات/الشراء يتطلبان Android 6 (API %d) كحد أدنى؛ رُفع الحد الأدنى من %d." % (ADS_MIN_SDK, min_sdk))
        min_sdk = ADS_MIN_SDK
    apply_gradle(a.project, pkg, version_code, version_name, min_sdk, target_sdk)
    set_output("min_sdk", str(min_sdk))
    set_output("target_sdk", str(target_sdk))
    apply_worker_host(a.project, host)
    icon_used, icon_sha = resolve_icon(cfg, a.icon, a.project)
    apply_icon(a.project, icon_used)
    icon_style, icon_bg = apply_adaptive_icon(a.project, icon_used, cfg)
    set_output("icon_style", icon_style)
    set_output("icon_bg", icon_bg)
    apply_home(a.project, cfg)
    extra_assets_on = apply_extra_assets(a.project, cfg)
    set_output("extra_assets_enabled", "1" if extra_assets_on else "0")
    apply_permissions(a.project, cfg)
    apply_ads(a.project, cfg)
    set_output("ads_enabled", "1" if ads_on else "0")
    apply_unity_ads(a.project, cfg)
    set_output("unity_ads_enabled", "1" if unityads_on else "0")
    apply_fb_ads(a.project, cfg)
    set_output("facebook_ads_enabled", "1" if fbads_on else "0")
    fb_on = apply_firebase(a.project, cfg, pkg)
    set_output("firebase_enabled", "1" if fb_on else "0")
    an_on = apply_analytics(a.project, cfg, fb_on)
    set_output("analytics_enabled", "1" if an_on else "0")
    apply_billing(a.project, cfg)
    set_output("billing_enabled", "1" if bill_on else "0")
    rv_on = apply_review(a.project, cfg)
    set_output("review_enabled", "1" if rv_on else "0")
    apply_webview_check(a.project, cfg)
    hw_on = apply_hardware(a.project, cfg)
    set_output("hardware_enabled", "1" if hw_on else "0")
    dl_on = apply_deeplinks(a.project, cfg)
    set_output("deeplinks_enabled", "1" if dl_on else "0")
    in_on = apply_intents(a.project, cfg)
    set_output("intents_enabled", "1" if in_on else "0")
    ocr_on = apply_ocr(a.project, cfg)
    set_output("ocr_enabled", "1" if ocr_on else "0")
    _dl = deeplinks_settings(cfg)
    al_on = bool(dl_on and _dl and _dl["verify"] and _dl["hosts"])
    set_output("assetlinks_enabled", "1" if al_on else "0")
    set_output("assetlinks_extra", ",".join(_dl["extra_fingerprints"]) if al_on else "")
    out_fmt = resolve_output(cfg)
    set_output("build_apk", "1" if out_fmt in ("apk", "both") else "0")
    set_output("build_aab", "1" if out_fmt in ("aab", "both") else "0")
    set_output("output_format", out_fmt)
    set_output("icon_used", "1" if icon_used else "0")
    set_output("icon_sha", icon_sha)

    set_output("package_name", pkg)
    set_output("version_code", str(version_code))
    set_output("version_name", version_name.replace(" ", "-"))
    set_output("asset_host", host)
    print("تم تطبيق الإعدادات: %s | %s | v%s (%d) | %s" % (cfg.get("app_name"), pkg, version_name, version_code, host))


if __name__ == "__main__":
    main()
