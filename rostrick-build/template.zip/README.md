# قالب تطبيق RosTrick (Android)

مشروع Android Studio جاهز يبنيه GitHub Actions. لا تُعدّل `app/build.gradle` أو الألوان أو الاسم يدوياً؛
`tools/apply_config.py` يطبّق إعدادات اللوحة (`rostrick-build/config.json`) وقت البناء.

- `user-repo-files/build-apk.yml` ← تنسخه اللوحة إلى `.github/workflows/` في مستودع المستخدم.
- يجب أن يكون هذا المستودع **عاماً** (الـ workflow في مستودع المستخدم يستنسخه).
- التوقيع: مفتاح PKCS12 لكل مستخدم في Secrets (`RT_KEYSTORE_B64`, `RT_KEYSTORE_PASSWORD`) تنشئه اللوحة.

## ميزات اختيارية/دائمة (واجهات الصفحات)
- `RosTrickShare` — مشاركة نص/رابط/ملف عبر قائمة النظام (دائماً، مع `RtShareProvider`).
- `RosTrickReview` — `config.review.enabled` لنافذة التقييم (`RtReviewReal.java.txt`)، و`openStore()` دائماً.
- `RosTrickLinks` — `config.deeplinks = {enabled, scheme, hosts[], verify}` يضيف intent-filters داخل `SplashActivity` ويجعل `MainActivity` singleTask.

### assetlinks.json (الروابط العميقة المتحقَّق منها)
عند تفعيل `deeplinks.verify` مع نطاق واحد على الأقل، يولّد الـ workflow ملف `assetlinks.json` (اسم الحزمة + بصمة SHA-256 لمفتاح التوقيع + `deeplinks.extra_fingerprints` الاختيارية) ويحفظه في `rostrick-build/assetlinks.json` ويرفقه بملفات الـ Release.
