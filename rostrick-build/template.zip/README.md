# قالب تطبيق RosTrick (Android)

مشروع Android Studio جاهز يبنيه GitHub Actions. لا تُعدّل `app/build.gradle` أو الألوان أو الاسم يدوياً؛
`tools/apply_config.py` يطبّق إعدادات اللوحة (`rostrick-build/config.json`) وقت البناء.

- `user-repo-files/build-apk.yml` ← تنسخه اللوحة إلى `.github/workflows/` في مستودع المستخدم.
- يجب أن يكون هذا المستودع **عاماً** (الـ workflow في مستودع المستخدم يستنسخه).
- التوقيع: مفتاح PKCS12 لكل مستخدم في Secrets (`RT_KEYSTORE_B64`, `RT_KEYSTORE_PASSWORD`) تنشئه اللوحة.

## ميزات اختيارية/دائمة (واجهات الصفحات)
- `RosTrickShare` — مشاركة نص/رابط/ملف عبر قائمة النظام (دائماً، مع `RtShareProvider`).
- `RosTrickReview` — `config.review.enabled` لنافذة التقييم (`RtReviewReal.java.txt`)، و`openStore()` دائماً.
- `RosTrickLinks` — `config.deeplinks = {enabled, scheme, hosts[], verify}` يضيف intent-filters داخل `SplashActivity` ويجعل `MainActivity` singleTask.
- `RosTrickStatusBar` — تحكم كامل بشريط الحالة (دائماً، `RtStatusBar` + `assets/rt-native.js`): إظهار/إخفاء، لون (شفاف/محدد/theme/page)، لون الأيقونات، الرسم خلف الشريط (overlay)، مدة انتقال اللون. عبر وسم `rostrick-statusbar`، أو عنصر `screen="rt_statusbar" statusbar="..."` (فعّال وهو ظاهر)، أو `window.RosTrickStatusBar`. يتولّى النافذة عند أول طلب فقط. الإخفاء قابل للكشف بالسحب دائماً (سلوك أندرويد) ولا يمكن تخصيص حركة النظام نفسها.
- `RosTrickWebView` — WebView أصلي إضافي تتحكم به الصفحة (دائماً، `RtWebViews`): `create({id,url,bounds})` يضعه في مستطيل تحدده الصفحة، مع load/back/forward/evaluate/find وأحداث (title, progress, finish, download…)، و`openFullscreen(url)` لنافذة جاهزة بشريط أصلي. بلا قيود CORS؛ لا تُحقن فيه جسور RosTrick؛ ملفات تعريف الارتباط مشتركة مع الـ WebView الرئيسي؛ يظهر فوق HTML الصفحة (قوائم HTML لا تغطيه)؛ حتى 10 نوافذ؛ ملء شاشة الفيديو غير مدعوم داخله حالياً.
- `RosTrickDownloads` — سجل التنزيلات (دائماً، `RtDownloads`، بلا أذونات): يتتبّع كل ما ينزّله التطبيق (روابط http/https عبر DownloadManager، وملفات data:/blob: المحفوظة في Downloads). `list()` حالة كل ملف (`state`: pending/running/paused/done/failed/removed، و`bytes`/`total`)، و`open(id)` يفتح الملف المكتمل بالتطبيق المناسب، و`share(id)`، و`remove(id, deleteFile)`، و`cancel(id)`، و`clear()`، و`openFolder()` يفتح تطبيق «التنزيلات»، و`summary()`. الأحداث: `RosTrickDownloads.on('done'|'progress'|'failed'|'start'|'removed', (item,type)=>…)` وحدث `rtdownload` على `window`. التتبّع يستمر في الخلفية ما دام التطبيق حيًّا، وبعد إعادة التشغيل تُحدَّث الحالة من النظام عند `list()`. **عرض الملف داخل الصفحة:** `await RosTrickDownloads.localFile(id, {onProgress})` يجهّز الملف المكتمل ويعيد `{ok, url:'file://…', path, mime, name, size, copied}` تضعه مباشرة في `<video src>` أو `<audio>` أو `<img>` (يدعم التقديم والسرعة لأنه ملف حقيقي)؛ إن تعذّرت قراءة الملف بمساره يُنسخ إلى ذاكرة التطبيق المؤقتة (`rt_open`) مع نسبة تقدّم. `cacheSize()` حجم هذه النسخ بالبايت، و`clearCache()` يمسحها (تُقلَّم تلقائيًا عند تجاوز حدّ معيّن).
- `RosTrickDevice` — جسر الجهاز (دائماً، `RtDevice`، بلا أذونات خطرة): `brightness.get/set(0..1)/reset()` سطوع **نافذة التطبيق فقط** (لا يغيّر إعداد النظام)، و`volume.get/set/up/down/mute/unmute/toggleMute(stream)` للقنوات music/ring/alarm/notification/system/call مع `volume.keys(stream)` و`volume.ringer()/setRinger()` (silent قد يحتاج صلاحية «عدم الإزعاج»)، و`torch.available/get/set/toggle` كشاف الفلاش، و`haptic('tick'|'click'|'long'|'confirm'|'reject')`، و`orientation.get/set('portrait'|'landscape'|'auto'|'lock'|'unlock')` (يبقى حتى تُحمَّل صفحة تعرّف `rostrick-orientation`)، و`secure(true)` لمنع لقطات الشاشة، و`network.get()`، و`info()`. الأحداث: `RosTrickDevice.on('volume'|'ringer'|'torch'|'network', (data,type)=>…)` وحدث `rtdevice` على `window` (وأحداث الصوت تعتمد على بثّ نظام غير موثّق فقد لا تصل على بعض الأجهزة؛ استعمل `volume.get` للتأكد).
- `RosTrickBack` — زر الرجوع (دائماً، `RtBack`، بلا أذونات): `canGoBack()` و`goBack()` (نفس منطق الرجوع الأصلي للتطبيق؛ يرجع true إن تنقّل، وfalse **بلا خروج** إن لم توجد صفحة سابقة)، و`exit()` و`minimize()` و`press()` (يحاكي ضغطة الرجوع كاملة؛ لا تستدعه من داخل معالج). **اعتراض الرجوع:** `const off = RosTrickBack.onBack(ev => {…})` — أرجع `true` (أو `ev.preventDefault()`) إن عالجتَ الضغط، وإلا يُنفَّذ الرجوع الافتراضي؛ الأحدث تسجيلاً يُستدعى أولاً، و`ev.canGoBack` يخبرك إن كانت هناك صفحة سابقة أصلية. إن لم ترد الصفحة خلال 400ms يُنفَّذ الافتراضي حتى لا يعلق الزر. `exitMode('exit'|'minimize'|'none')` يحدد ما يحدث عند الرجوع بلا صفحة سابقة ولا معالج. **الضغط مرتين للخروج بلا Toast أصلي:** `RosTrickBack.doubleBackToExit({timeout:2000, onFirst:()=>showMyToast('اضغط مرة أخرى للخروج'), onExit, always, mode})` — الرسالة تعرضها أنت في `onFirst`. ملاحظة: صفحات الـ SPA الداخلية (شاشات تبدّلها بـ JS) لا يعرفها النظام، فاعترض الرجوع بـ `onBack` وتنقّل أنت. المحتوى بملء الشاشة (فيديو) يُغلق أولاً قبل أي معالج.
- `RosTrickApp` — أدوات الإحساس الأصلي (دائماً، `RtApp`، بلا أذونات، **بلا أي Toast أو نافذة**؛ الحافظة وإبقاء الشاشة مضاءة تبقيان بأسمائهما القياسية `navigator.clipboard` و`navigator.wakeLock`): `nativeFeel({select,tapHighlight,callout,overscroll,focusRing,contextMenu,zoom})` يزيل علامات الويب (تحديد النص عدا الحقول، وميض اللمس، قائمة سحب الصور، overscroll، وبمنع `contextMenu:false` قائمة الضغط المطوّل، و`zoom:false` التكبير)؛ `keyboard.state()/isOpen()/height()/show()/hide()` مع متغيّر CSS `--rt-keyboard-height` والحدث `keyboard`؛ `info()` (الحزمة/الإصدار/اللغة/الوضع الداكن/RTL/تابلت…)؛ `openSettings()` إعدادات التطبيق في النظام؛ `openExternal(url)` (http/https/mailto/tel/sms/geo فقط)؛ `on('pause'|'resume'|'keyboard', fn)` وحدث `rtapp` على `window`. أحداث الجاهزية: `rtback-ready` و`rtapp-ready`.

### assetlinks.json (الروابط العميقة المتحقَّق منها)
عند تفعيل `deeplinks.verify` مع نطاق واحد على الأقل، يولّد الـ workflow ملف `assetlinks.json` (اسم الحزمة + بصمة SHA-256 لمفتاح التوقيع + `deeplinks.extra_fingerprints` الاختيارية) ويحفظه في `rostrick-build/assetlinks.json` ويرفقه بملفات الـ Release.

## الصفحات اليدوية والزر متعدد الملفات
- `RosTrickPages.download/isDownloaded/openPage` تعمل لأي مسار (html/css/js/json/zip).
- `<button onCreate="rostrickpages" rostrick="a.html,b.css,c.js,d.json" rtnd="تحميل" rtid="دخول" progress="true">`: عدّة ملفات مفصولة بفاصلة؛ يُنزَّل الناقص فقط والنسبة عامة، وعند الاكتمال يتحول لـ `rtid` ويفتح أول ملف html (أو أول ملف). الحدث `rtpages` يحمل `path` و`paths`.

## العمل في الخلفية (اختياري — يُفعَّل من اللوحة، غير موجود في الـ Manifest افتراضياً)
`config.permissions` يقبل المفتاحين `bg_service` و`bg_scheduler` (`tools/apply_config.py` → `PERMISSION_CATALOG`):
- `bg_service`: خدمة أمامية `RtBackgroundService` (النوع `specialUse`) بإشعار دائم + زر إيقاف، تُعاد بعد إعادة التشغيل. اختيارياً تشغّل صفحة خلفية مخفية (WebView بلا واجهة) من ملف في ملفات التطبيق (واجهتها `window.RosTrickBg.notify/schedule/cancel/stop`).
- `bg_scheduler`: منبّهات `AlarmManager` (`RtAlarmReceiver`) تعرض إشعاراً في وقت محدد وتُعاد جدولتها بعد الإقلاع (`RtBootReceiver`). الإذن `SCHEDULE_EXACT_ALARM` يمنحه المستخدم من الإعدادات على Android 14+، وبدونه تعمل غير دقيقة.
- الواجهة للصفحات: `RosTrickBackground.available() / service.start({title,text,page,open}) / service.stop() / service.isRunning() / schedule({id,at|in,repeat,title,text,page,exact}) / cancel(id) / cancelAll() / list() / requestNotifications() / requestExactAlarms()`.
- يخفي/يُظهر خياريهما في اللوحة `settings.json → background_features {service, scheduler}` من theme manager.

## التحليلات (Google Analytics) — اختيارية
- `analytics: {enabled, ga4: {enabled, measurement_id, api_secret}, firebase}` في config.json؛ المعطّل = نسخة فارغة `RtAnalytics.java` بلا اتصال ولا مكتبة.
- **GA4 بدون مكتبة**: `tools/RtAnalyticsReal.java.txt` يرسل الأحداث عبر Measurement Protocol (`https://www.google-analytics.com/mp/collect`)، بمعرّف `G-…` وسر API (يُدمج في التطبيق).
- **Firebase Analytics**: يتطلب `firebase.enabled` (نفس google-services.json) ويضيف `firebase-analytics` بين `// RT-FA:START/END` في app/build.gradle.
- الصفحات: `window.RosTrickAnalytics` (`logEvent/screen/setUserId/setUserProperty/setEnabled/isEnabled/enabled`)؛ التطبيق يرسل تلقائياً `app_open` و`screen_view`.
- يخفي/يُظهر خياريهما في اللوحة `settings.json → analytics_features {ga4, firebase}` من theme manager.

## تحديث الصفحات اليدوية المحمّلة
- المقارنة: `timestamp` الصفحة في `app_lazy_pages.json` (تحدّثه اللوحة مع كل حفظ) مقابل التاريخ المسجّل وقت تنزيلها (SharedPreferences `rt_lazy_pages`).
- الافتراضي: عند تشغيل التطبيق يحدّث الصفحات اليدوية المحمّلة القديمة صامتاً. الأزرار `rtupdate="نص"` تسأل: تتحول الحالة إلى `update` ويُعاد تنزيل كامل القائمة بالضغط.
- جسر JS: `RosTrickPages.isOutdated(p)` و`refresh()` و`setAsk(p, bool)`.
- جسر JS للتحديث: `await RosTrickPages.update(p, {confirm, yes, no, force, onProgress})` يحدّث السجل ثم يعيد تنزيل القديم فقط (أو الكل مع `force:true`) ويرجع `'updated'` أو `'uptodate'` أو `'cancelled'` أو `'failed'`؛ إن كُتب `confirm` يظهر صندوق تأكيد أولاً. و`RosTrickPages.rtupdate(p, true|false)` يعادل خاصية `rtupdate` (يجعل الصفحة تسأل ولا تُحدَّث صامتاً عند التشغيل).

## حذف الصفحات/الملفات المحمّلة
- الجسر هو الخصائص نفسها على **أي عنصر** (button أو div أو a أو span…): `onCreate="rostrickpages" remove="game.html" removetext="حذف اللعبة" removeconfirm="هل أنت واثق؟" recc="نعم احذف اللعبة" recf="لا لاتحذف اللعبة"`. `remove` اسم الملف (أو عدّة ملفات بفاصلة)، `removetext` نص الزر، `removeconfirm` اختيارية — إن لم تُكتب يُحذف الملف مباشرة دون سؤال، `recc`/`recf` نصّا زرّي التأكيد/الإلغاء.
- حالة العنصر `rostrick-state`: `removable` (الملف محمّل) أو `empty` (غير محمّل). الحدث `rtpages` يحمل `state` = `removed` أو `cancelled` أو `error`. وأزرار التحميل تتحدّث تلقائياً عبر حدث `rtpages-changed` على `window`.
- جسر JS: `await RosTrickPages.remove(p, {confirm, yes, no})` يرجع `true` عند الحذف و`false` عند الإلغاء/الفشل (بدون `confirm` يحذف مباشرة).

## الصفحة الرئيسية المخصّصة (homepage.json)
- ملف `homepage.json` في جذر المستودع: `{"page":"welcome.html"}`. تضبطه اللوحة من زر «اجعلها الصفحة الرئيسية» في قائمة الصفحات (ويُرفع رقم الإصدار تلقائياً).
- التحديث: يجلب التطبيق `homepage.json` أولاً (مع `version.txt`)، فإن كانت الصفحة المذكورة موجودة على الخادم تُنزَّل وتُحفظ **هي** كصفحة الدخول بدل `home.html` (تدعم الصفحات الكبيرة المقسّمة)، ويُحفظ `homepage.json` نسخة محلية في ملفات التطبيق بعد نجاح التحديث.
- الإقلاع المبكر: عند كل تشغيل يقرأ التطبيق النسخة **المحلية** فقط (بلا شبكة) ويفتح الصفحة المختارة مباشرة؛ وإن لم تكن موجودة محلياً أو كان الملف غير صالح يفتح `home.html`.
- غياب الملف أو عدم صلاحيته أو عدم وجود الصفحة على الخادم = `home.html` كالمعتاد.
- أي طلب إلى `home.html` (من splash/loader/404 أو روابط الصفحات) يُقدَّم من الصفحة الرئيسية المختارة عندما تكون مخصّصة. الأسماء المرفوضة: ما فيه `/` أو `..` أو لا ينتهي بـ `.html`، و`404.html` و`splash.html` و`loader.html` و`closed.html` و`maintenance.html`.

## أدوات النظام (اختيارية — تُفعَّل في إعدادات البناء)
واجهات للتطبيقات التي تعمل فوق التطبيقات الأخرى (قارئ شاشة، مسطرة، ملتقط ألوان…). كلها معطّلة افتراضياً ولا يدخل الـ Manifest ولا المكتبات شيء منها إلا إذا اختارها صاحب التطبيق. الجسور موجودة دائماً في `rt-native.js` وتعرف حالتها: `RosTrickOverlay.available` و`RosTrickScreen.available` و`RosTrickOcr.enabled` و`RosTrickIntent.enabled`.

### الأذونات (`config.permissions`) — `tools/apply_config.py → PERMISSION_CATALOG`
- `overlay`: إذن `SYSTEM_ALERT_WINDOW`؛ يمنحه المستخدم يدوياً من إعدادات «العرض فوق التطبيقات».
- `screen_capture`: خدمة أمامية `RtScreenService` (النوع `mediaProjection`) + `FOREGROUND_SERVICE_MEDIA_PROJECTION`. تظهر نافذة النظام «تسجيل الشاشة» (على Android 14+ في كل جلسة) وإشعار دائم فيه زر إيقاف.
- Google Play تراجع هذين الإذنين وتطلب شرح الاستخدام.

### `RosTrickOverlay` — نوافذ HTML عائمة فوق كل التطبيقات (`RtOverlay.java`)
- `available` / `canDraw()` / `await requestPermission()` (يتحقق عند عودة المستخدم للتطبيق).
- `await create({id, url|html, baseUrl, x, y, w, h (dp؛ "full" أو -1 = ملء الشاشة), gravity:'tl|tr|bl|br|center', fullscreen, touchable=true, focusable=false, alpha, bg, keep})` → id. الأخطاء `e.code`: `no_permission | not_declared | exists | too_many | bad_url | no_content` (حد 6 نوافذ).
- `update(id, {...}) / show / hide / destroy / destroyAll / exists / list() / screen()` (الحجم الحقيقي والكثافة) / `post(id, msg)` / `await evaluate(id, js)` / `onMessage(id, fn)` / `on('permission|ready|message|closed', fn)`.
- داخل صفحة النافذة كائن `RosTrickOverlay`: `post(msg)` `onMessage(fn)` `close()` `move(x,y)` `moveBy(dx,dy)` `resize(w,h)` `snap()` `touchable(b)` `info()` و`drag(el, {snap, onTap, onDrop})` لسحب النافذة من عنصر. الحدث `rtoverlay-ready`.
- النوافذ التي بلا `keep` تُزال عند إغلاق التطبيق؛ وللنوافذ الباقية استعمل `RosTrickBack.exitMode('minimize')` كي لا يُغلق التطبيق عند الرجوع.

### `RosTrickScreen` — التقاط الشاشة وقراءة الألوان وتسجيلها (`RtScreen.java` + `RtScreenService.java`)
- `available` / `status()` / `isActive()` / `await requestPermission()` (نافذة النظام ثم تبدأ الجلسة) / `stop()`.
- `await capture({region:{x,y,w,h}, unit:'px'|'dp', scale, format:'png'|'jpeg', quality, hideOverlays=true, dataUrl, save})` → `{path, url, width, height, size, savedUri?}`؛ `hideOverlays` يُخفي نوافذ `RosTrickOverlay` لحظة الالتقاط كي لا تظهر في اللقطة. الأخطاء: `not_active | recording | no_frame`.
- `pixel(x, y, radius)` → `{r,g,b,a,hex}` من آخر إطار (بكسل الشاشة الحقيقي).
- `await record.start({scale, fps, bitrate})` / `await record.stop({save})` → `{path, url, duration, size}` (فيديو MP4 بلا صوت؛ يتوقف الالتقاط أثناء التسجيل). `save:true` يحفظ في المعرض (Pictures/Movies › RosTrick).
- `on('permission|state|stopped', fn)`. محتوى `FLAG_SECURE` (تطبيقات البنوك…) يظهر أسود. على Android 14+ قد يختار المستخدم مشاركة تطبيق واحد فقط.

### `RosTrickOcr` — قراءة النص من الصور دون إنترنت (`config.ocr`، Tesseract)
- `ocr: {enabled: true, languages: ["ara","eng"], quality: "fast"|"best", library?: "group:artifact:version"}`. الافتراضي ara+eng وجودة fast (ملفات tessdata_fast).
- وقت البناء ينسخ `tools/RtOcrReal.java.txt` فوق `RtOcr.java`، يضيف المكتبة (`cz.adaptech.tesseract4android:tesseract4android:4.9.0`، تُستبدل بخاصية gradle `tesseractCoordinate` أو `ocr.library`) بين `// RT-OCR:START/END`، ويجلب ملفات اللغات إلى `assets/tessdata/` من مستودع tesseract-ocr على GitHub (أو من `tools/tessdata/<lang>.traineddata` إن وُجدت محلياً). تُنشر المكتبة على JitPack فقط، فيضيف مستودع JitPack تلقائياً (محصوراً بمجموعتها) في `build.gradle` الجذر؛ وكذلك إن بدأت `library` بـ `com.github.`.
- `enabled` / `languages()` / `await recognize(source, {lang, psm, region, invert:'auto'|true|false, scale, boxes})` حيث source مسار/رابط ملف أو dataUrl أو نتيجة `Screen.capture` → `{text, confidence, lines:[{text,confidence,box}], lang, ms}` / `await fromScreen({region, unit, lang, ...})` (التقاط ثم قراءة) / `release()`. المسارات المسموحة داخل مجلدات التطبيق فقط. تكبير تلقائي للصور الصغيرة وعكس تلقائي للوضع الداكن.
- ML Kit الجاهز لا يدعم العربية، لذلك اعتُمد Tesseract.

### `RosTrickIntent` — «فتح بواسطة» والمشاركة وتحديد النص (`config.intents`)
- `intents: {view: ["image/*","application/pdf"], send: ["image/*","text/plain"], process_text: true}` (حتى 24 نوع MIME لكل قائمة). تُولَّد فلاتر داخل `SplashActivity` بين `<!-- RT-INTENTS:START/END -->` مع `meta-data rt.intents`، وتصير `MainActivity` singleTask. `SplashActivity` يمرّر الـ Intent كما هو، ولا يعامل `content://` و`file://` رابطاً عميقاً.
- `RtIntent.java` ينسخ الملفات الواردة إلى `cache/rt_in/` (حد 200MB للملف و20 ملفاً) ويحذف ما مضى عليه أكثر من يوم.
- `enabled` (مثل `"view,send"`) / `await getInitial()` → `{action:'view|send|send_multiple|process_text', text, subject, mime, items:[{name,mime,size,path,url}]}` أو null / `clear()` / `remove(path)` / `on(fn)` والحدث `rostrick-intent` (بلا تكرار لنفس الـ Intent).
- `process_text` قراءة فقط (لا يُعيد نصاً معدّلاً للتطبيق المصدر).
- **ربط نوع الملف بصفحة (`fileopen.json`)**: ملف في جذر المستودع `{"rules":[{"type":"application/pdf","page":"pdf-viewer.html"}]}` (حتى 30 قاعدة). يجلبه التطبيق مع التحديث العادي (كـ `homepage.json`) ويحفظ نسخة في filesDir، فلا يحتاج إعادة بناء. عند وصول ملف (من الصفر أو والتطبيق يعمل) تُحدَّد الصفحة بنوع الملف الأول: تطابق تام ثم `type/*` ثم `*/*` (النص المشارك والمحدد `text/plain`)، فينتقل التطبيق إليها وتستلم الملف عبر `getInitial()`. غياب الربط أو عدم تنزيل الصفحة = السلوك المعتاد. المنطق في `RtFileOpen.java` (بلا اعتماد على أندرويد) واختباره `tests/template/java/run_java.sh`. تحرّره اللوحة من قسم «ربط الملفات بالصفحات» (Pro).

### أمثلة ومختبر
- `bridges-lab.html` فيه قسم لكل جسر من هذه. `ocr-app.html` تطبيق تجريبي كامل: زر عائم، تحديد منطقة بملء الشاشة، نافذة نتيجة قابلة للسحب (نسخ/مشاركة/تحديد جديد)، سجل، واستقبال صورة من مشاركة.
