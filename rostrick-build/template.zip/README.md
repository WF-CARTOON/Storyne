# قالب تطبيق RosTrick (Android)

مشروع Android Studio جاهز يبنيه GitHub Actions. لا تُعدّل `app/build.gradle` أو الألوان أو الاسم يدوياً؛
`tools/apply_config.py` يطبّق إعدادات اللوحة (`rostrick-build/config.json`) وقت البناء.

- `user-repo-files/build-apk.yml` ← تنسخه اللوحة إلى `.github/workflows/` في مستودع المستخدم.
- يجب أن يكون هذا المستودع **عاماً** (الـ workflow في مستودع المستخدم يستنسخه).
- التوقيع: مفتاح PKCS12 لكل مستخدم في Secrets (`RT_KEYSTORE_B64`, `RT_KEYSTORE_PASSWORD`) تنشئه اللوحة.

## ميزات اختيارية/دائمة (واجهات الصفحات)
- `RosTrickShare` — مشاركة نص/رابط/ملف عبر قائمة النظام (دائماً، مع `RtShareProvider`).
- `RosTrickReview` — `config.review.enabled` لنافذة التقييم (`RtReviewReal.java.txt`)، و`openStore()` دائماً.
- `RosTrickLinks` — `config.deeplinks = {enabled, scheme, hosts[], verify}` يضيف intent-filters داخل `SplashActivity` ويجعل `MainActivity` singleTask.
- `RosTrickStatusBar` — تحكم كامل بشريط الحالة (دائماً، `RtStatusBar` + `assets/rt-native.js`): إظهار/إخفاء، لون (شفاف/محدد/theme/page)، لون الأيقونات، الرسم خلف الشريط (overlay)، مدة انتقال اللون. عبر وسم `rostrick-statusbar`، أو عنصر `screen="rt_statusbar" statusbar="..."` (فعّال وهو ظاهر)، أو `window.RosTrickStatusBar`. يتولّى النافذة عند أول طلب فقط. الإخفاء قابل للكشف بالسحب دائماً (سلوك أندرويد) ولا يمكن تخصيص حركة النظام نفسها.
- `RosTrickWebView` — WebView أصلي إضافي تتحكم به الصفحة (دائماً، `RtWebViews`): `create({id,url,bounds})` يضعه في مستطيل تحدده الصفحة، مع load/back/forward/evaluate/find وأحداث (title, progress, finish, download…)، و`openFullscreen(url)` لنافذة جاهزة بشريط أصلي. بلا قيود CORS؛ لا تُحقن فيه جسور RosTrick؛ ملفات تعريف الارتباط مشتركة مع الـ WebView الرئيسي؛ يظهر فوق HTML الصفحة (قوائم HTML لا تغطيه)؛ حتى 10 نوافذ؛ ملء شاشة الفيديو غير مدعوم داخله حالياً.

### assetlinks.json (الروابط العميقة المتحقَّق منها)
عند تفعيل `deeplinks.verify` مع نطاق واحد على الأقل، يولّد الـ workflow ملف `assetlinks.json` (اسم الحزمة + بصمة SHA-256 لمفتاح التوقيع + `deeplinks.extra_fingerprints` الاختيارية) ويحفظه في `rostrick-build/assetlinks.json` ويرفقه بملفات الـ Release.

## الصفحات اليدوية والزر متعدد الملفات
- `RosTrickPages.download/isDownloaded/openPage` تعمل لأي مسار (html/css/js/json/zip).
- `<button onCreate="rostrickpages" rostrick="a.html,b.css,c.js,d.json" rtnd="تحميل" rtid="دخول" progress="true">`: عدّة ملفات مفصولة بفاصلة؛ يُنزَّل الناقص فقط والنسبة عامة، وعند الاكتمال يتحول لـ `rtid` ويفتح أول ملف html (أو أول ملف). الحدث `rtpages` يحمل `path` و`paths`.

## العمل في الخلفية (اختياري — يُفعَّل من اللوحة، غير موجود في الـ Manifest افتراضياً)
`config.permissions` يقبل المفتاحين `bg_service` و`bg_scheduler` (`tools/apply_config.py` → `PERMISSION_CATALOG`):
- `bg_service`: خدمة أمامية `RtBackgroundService` (النوع `specialUse`) بإشعار دائم + زر إيقاف، تُعاد بعد إعادة التشغيل. اختيارياً تشغّل صفحة خلفية مخفية (WebView بلا واجهة) من ملف في ملفات التطبيق (واجهتها `window.RosTrickBg.notify/schedule/cancel/stop`).
- `bg_scheduler`: منبّهات `AlarmManager` (`RtAlarmReceiver`) تعرض إشعاراً في وقت محدد وتُعاد جدولتها بعد الإقلاع (`RtBootReceiver`). الإذن `SCHEDULE_EXACT_ALARM` يمنحه المستخدم من الإعدادات على Android 14+، وبدونه تعمل غير دقيقة.
- الواجهة للصفحات: `RosTrickBackground.available() / service.start({title,text,page,open}) / service.stop() / service.isRunning() / schedule({id,at|in,repeat,title,text,page,exact}) / cancel(id) / cancelAll() / list() / requestNotifications() / requestExactAlarms()`.
- يخفي/يُظهر خياريهما في اللوحة `settings.json → background_features {service, scheduler}` من theme manager.

## التحليلات (Google Analytics) — اختيارية
- `analytics: {enabled, ga4: {enabled, measurement_id, api_secret}, firebase}` في config.json؛ المعطّل = نسخة فارغة `RtAnalytics.java` بلا اتصال ولا مكتبة.
- **GA4 بدون مكتبة**: `tools/RtAnalyticsReal.java.txt` يرسل الأحداث عبر Measurement Protocol (`https://www.google-analytics.com/mp/collect`)، بمعرّف `G-…` وسر API (يُدمج في التطبيق).
- **Firebase Analytics**: يتطلب `firebase.enabled` (نفس google-services.json) ويضيف `firebase-analytics` بين `// RT-FA:START/END` في app/build.gradle.
- الصفحات: `window.RosTrickAnalytics` (`logEvent/screen/setUserId/setUserProperty/setEnabled/isEnabled/enabled`)؛ التطبيق يرسل تلقائياً `app_open` و`screen_view`.
- يخفي/يُظهر خياريهما في اللوحة `settings.json → analytics_features {ga4, firebase}` من theme manager.

## تحديث الصفحات اليدوية المحمّلة
- المقارنة: `timestamp` الصفحة في `app_lazy_pages.json` (تحدّثه اللوحة مع كل حفظ) مقابل التاريخ المسجّل وقت تنزيلها (SharedPreferences `rt_lazy_pages`).
- الافتراضي: عند تشغيل التطبيق يحدّث الصفحات اليدوية المحمّلة القديمة صامتاً. الأزرار `rtupdate="نص"` تسأل: تتحول الحالة إلى `update` ويُعاد تنزيل كامل القائمة بالضغط.
- جسر JS: `RosTrickPages.isOutdated(p)` و`refresh()` و`setAsk(p, bool)`.
- جسر JS للتحديث: `await RosTrickPages.update(p, {confirm, yes, no, force, onProgress})` يحدّث السجل ثم يعيد تنزيل القديم فقط (أو الكل مع `force:true`) ويرجع `'updated'` أو `'uptodate'` أو `'cancelled'` أو `'failed'`؛ إن كُتب `confirm` يظهر صندوق تأكيد أولاً. و`RosTrickPages.rtupdate(p, true|false)` يعادل خاصية `rtupdate` (يجعل الصفحة تسأل ولا تُحدَّث صامتاً عند التشغيل).

## حذف الصفحات/الملفات المحمّلة
- الجسر هو الخصائص نفسها على **أي عنصر** (button أو div أو a أو span…): `onCreate="rostrickpages" remove="game.html" removetext="حذف اللعبة" removeconfirm="هل أنت واثق؟" recc="نعم احذف اللعبة" recf="لا لاتحذف اللعبة"`. `remove` اسم الملف (أو عدّة ملفات بفاصلة)، `removetext` نص الزر، `removeconfirm` اختيارية — إن لم تُكتب يُحذف الملف مباشرة دون سؤال، `recc`/`recf` نصّا زرّي التأكيد/الإلغاء.
- حالة العنصر `rostrick-state`: `removable` (الملف محمّل) أو `empty` (غير محمّل). الحدث `rtpages` يحمل `state` = `removed` أو `cancelled` أو `error`. وأزرار التحميل تتحدّث تلقائياً عبر حدث `rtpages-changed` على `window`.
- جسر JS: `await RosTrickPages.remove(p, {confirm, yes, no})` يرجع `true` عند الحذف و`false` عند الإلغاء/الفشل (بدون `confirm` يحذف مباشرة).

## الصفحة الرئيسية المخصّصة (homepage.json)
- ملف `homepage.json` في جذر المستودع: `{"page":"welcome.html"}`. تضبطه اللوحة من زر «اجعلها الصفحة الرئيسية» في قائمة الصفحات (ويُرفع رقم الإصدار تلقائياً).
- التحديث: يجلب التطبيق `homepage.json` أولاً (مع `version.txt`)، فإن كانت الصفحة المذكورة موجودة على الخادم تُنزَّل وتُحفظ **هي** كصفحة الدخول بدل `home.html` (تدعم الصفحات الكبيرة المقسّمة)، ويُحفظ `homepage.json` نسخة محلية في ملفات التطبيق بعد نجاح التحديث.
- الإقلاع المبكر: عند كل تشغيل يقرأ التطبيق النسخة **المحلية** فقط (بلا شبكة) ويفتح الصفحة المختارة مباشرة؛ وإن لم تكن موجودة محلياً أو كان الملف غير صالح يفتح `home.html`.
- غياب الملف أو عدم صلاحيته أو عدم وجود الصفحة على الخادم = `home.html` كالمعتاد.
- أي طلب إلى `home.html` (من splash/loader/404 أو روابط الصفحات) يُقدَّم من الصفحة الرئيسية المختارة عندما تكون مخصّصة. الأسماء المرفوضة: ما فيه `/` أو `..` أو لا ينتهي بـ `.html`، و`404.html` و`splash.html` و`loader.html` و`closed.html` و`maintenance.html`.
